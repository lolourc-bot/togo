import { useMemo, useState } from "react";
import { Calendar, ChevronDown, Search, Trophy, X, Zap } from "lucide-react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const GROUPS: { label: string; items: string[] }[] = [
  { label: "Fuerza", items: ["Sentadilla trasera", "Press banca", "Peso muerto", "Prensa de piernas"] },
  { label: "Accesorios", items: ["Curl de bíceps", "Extensión de tríceps", "Remo con mancuerna"] },
];
const BASE: Record<string, number> = {
  "Sentadilla trasera": 80,
  "Press banca": 60,
  "Peso muerto": 110,
  "Prensa de piernas": 140,
  "Curl de bíceps": 12,
  "Extensión de tríceps": 15,
  "Remo con mancuerna": 24,
};
const STEPS = [0, 2.5, 2.5, 5, 7.5, 7.5, 10];
const PERIODS = ["1 mes", "3 meses", "6 meses", "1 año"] as const;
const METRICS = ["Peso", "Reps", "Volumen"] as const;
type Metric = (typeof METRICS)[number];
const MONTHS = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];

type Rec = { date: Date; sets: number; reps: number; weight: number; note: string };

function records(ex: string, period: string): Rec[] {
  const n = period === "1 mes" ? 5 : period === "3 meses" ? 7 : period === "6 meses" ? 12 : 18;
  const base = BASE[ex] ?? 50;
  const end = new Date(2026, 8, 25);
  return Array.from({ length: n }, (_, i) => {
    const date = new Date(end);
    date.setDate(end.getDate() - 7 * (n - 1 - i));
    const stepIdx = Math.round((i / Math.max(1, n - 1)) * (STEPS.length - 1));
    const scale = base / 80;
    const extra = n > 7 ? -((n - 1 - i) > 6 ? (n - 1 - i - 6) * 1.25 * scale : 0) : 0;
    const weight = Math.round((base + STEPS[stepIdx]! * scale + extra) * 2) / 2;
    const reps = i >= n - 3 ? 6 : 8;
    return { date, sets: 4, reps, weight, note: i === n - 1 ? "Buena técnica, subir 2,5 kg" : i === n - 4 ? "Molestia leve en rodilla" : "" };
  });
}

const fmt = (d: Date) => `${d.getDate()} ${MONTHS[d.getMonth()]}`;
const num = (v: number) => v.toLocaleString("es-AR");
const value = (r: Rec, m: Metric) => (m === "Peso" ? r.weight : m === "Reps" ? r.reps : r.sets * r.reps * r.weight);
const unit = (m: Metric) => (m === "Peso" ? "kg" : m === "Reps" ? "reps" : "kg");

const chip = (on: boolean): React.CSSProperties => ({
  border: "1px solid",
  borderColor: on ? "#111827" : "#E2E8F0",
  borderRadius: 6,
  padding: "4px 10px",
  fontSize: 12,
  backgroundColor: on ? "#111827" : "#FFFFFF",
  color: on ? "#FFFFFF" : "#374151",
  cursor: "pointer",
});

function ExerciseSelect({
  value: sel,
  onChange,
  dashed,
  exclude,
}: {
  value: string | null;
  onChange: (v: string) => void;
  dashed?: boolean;
  exclude?: string | null;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const t = q.trim().toLowerCase();
  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => {
          setOpen((v) => !v);
          setQ("");
        }}
        className="flex items-center justify-between"
        style={{ gap: 8, border: `1px ${dashed ? "dashed" : "solid"} ${dashed ? "#3B82F6" : "#E2E8F0"}`, borderRadius: 10, height: 40, padding: "0 14px", backgroundColor: "#FFFFFF", cursor: "pointer", minWidth: 220 }}
      >
        <span style={{ fontSize: 13, fontWeight: sel ? 600 : 400, color: sel ? "#111827" : "#94A3B8" }}>{sel ?? "Seleccionar ejercicio…"}</span>
        <ChevronDown size={12} color="#CBD5E1" />
      </button>
      {open ? (
        <>
          <div className="fixed inset-0" style={{ zIndex: 29 }} onClick={() => setOpen(false)} />
          <div style={{ position: "absolute", top: 44, left: 0, zIndex: 30, minWidth: 280, backgroundColor: "#FFFFFF", borderRadius: 12, border: "1px solid #E2E8F0", boxShadow: "0 4px 16px rgba(0,0,0,0.10)", overflow: "hidden" }}>
            <div className="relative">
              <Search size={12} color="#CBD5E1" style={{ position: "absolute", left: 14, top: 12 }} />
              <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar ejercicio…" aria-label="Buscar ejercicio" style={{ width: "100%", height: 36, border: "none", borderBottom: "1px solid #E2E8F0", padding: "0 12px 0 36px", fontSize: 13, outline: "none" }} />
            </div>
            <div style={{ maxHeight: 200, overflowY: "auto", padding: "4px 0" }}>
              {GROUPS.map((g) => {
                const items = g.items.filter((i) => i !== exclude && (!t || i.toLowerCase().includes(t)));
                if (!items.length) return null;
                return (
                  <div key={g.label}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: "#94A3B8", textTransform: "uppercase", padding: "8px 12px 4px" }}>{g.label}</div>
                    {items.map((i) => (
                      <button key={i} type="button" onClick={() => { onChange(i); setOpen(false); }} className="block w-full text-left hover:bg-[#F8FAFC]" style={{ padding: "8px 12px", fontSize: 13, color: "#374151", background: i === sel ? "#F8FAFC" : undefined, border: "none", cursor: "pointer" }}>
                        {i}
                      </button>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}

function Stat({ icon, label, big, sub }: { icon: React.ReactNode; label: string; big: string; sub: string }) {
  return (
    <div className="flex flex-col" style={{ backgroundColor: "#FFFFFF", borderRadius: 12, border: "1px solid #E2E8F0", padding: 16, gap: 6 }}>
      <div className="flex items-center" style={{ gap: 8, fontSize: 12, color: "#374151", fontWeight: 500 }}>{icon}{label}</div>
      <div style={{ fontSize: 28, fontWeight: 800, color: "#111827", lineHeight: 1.1 }}>{big}</div>
      <div style={{ fontSize: 11, color: "#94A3B8" }}>{sub}</div>
    </div>
  );
}

export function AthleteProgress() {
  const [ex, setEx] = useState<string | null>(null);
  const [ex2, setEx2] = useState<string | null>(null);
  const [compare, setCompare] = useState(false);
  const [period, setPeriod] = useState<string>("3 meses");
  const [metric, setMetric] = useState<Metric>("Peso");

  const recs = useMemo(() => (ex ? records(ex, period) : []), [ex, period]);
  const recs2 = useMemo(() => (ex2 ? records(ex2, period) : []), [ex2, period]);
  const data = recs.map((r, i) => ({ label: fmt(r.date), a: value(r, metric), ...(recs2[i] ? { b: value(recs2[i]!, metric) } : {}) }));
  const allVals = data.flatMap((d) => [d.a, d.b ?? 0]);
  const yMax = allVals.length ? Math.ceil((Math.max(...allVals) * 1.1) / 4) * 4 : 100;
  const pr = recs.length ? Math.max(...recs.map((r) => r.weight)) : 0;
  const last5 = [...recs].reverse().slice(0, 5);

  return (
    <div className="flex flex-col" style={{ flex: 1, overflowY: "auto", padding: "24px 32px", gap: 20 }}>
      <div className="flex flex-wrap items-center" style={{ gap: 12 }}>
        <span style={{ fontSize: 13, fontWeight: 500, color: "#374151" }}>Ejercicio:</span>
        <ExerciseSelect value={ex} onChange={setEx} exclude={ex2} />
        {compare ? (
          <div className="flex items-center" style={{ gap: 6 }}>
            <ExerciseSelect value={ex2} onChange={setEx2} dashed exclude={ex} />
            <button type="button" aria-label="Quitar comparación" onClick={() => { setCompare(false); setEx2(null); }} style={{ background: "none", border: "none", cursor: "pointer" }}>
              <X size={14} color="#94A3B8" />
            </button>
          </div>
        ) : null}
        <span style={{ fontSize: 12, color: "#94A3B8", marginLeft: 8 }}>Período:</span>
        <div className="flex" style={{ gap: 6 }}>
          {PERIODS.map((p) => (
            <button key={p} type="button" onClick={() => setPeriod(p)} style={chip(period === p)}>{p}</button>
          ))}
        </div>
        {!compare ? (
          <button type="button" onClick={() => setCompare(true)} style={{ fontSize: 12, color: "#3B82F6", background: "none", border: "none", cursor: "pointer" }}>
            + Comparar con otro ejercicio
          </button>
        ) : null}
      </div>

      <div className="grid" style={{ gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        <Stat icon={<Calendar size={18} color="#94A3B8" />} label="Sesiones completadas" big="47" sub="Últimos 3 meses" />
        <Stat icon={<Zap size={18} color="#D97706" />} label="Racha actual" big="8 semanas" sub="sin faltar" />
        <Stat icon={<Trophy size={18} color="#D97706" />} label="Récords personales" big="3 este mes" sub="Squat · Peso muerto · Press" />
      </div>

      {ex ? (
        <>
          <div style={{ backgroundColor: "#FFFFFF", borderRadius: 12, border: "1px solid #E2E8F0", padding: 20, position: "relative" }}>
            <div className="flex items-center" style={{ marginBottom: 16, paddingRight: 110 }}>
              <div className="min-w-0 flex-1">
                <span style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>{ex}</span>
                {ex2 ? <span style={{ fontSize: 14, fontWeight: 700, color: "#3B82F6" }}>{` vs ${ex2}`}</span> : null}
                <span style={{ fontSize: 12, color: "#94A3B8", marginLeft: 8 }}>{`· Progresión de ${metric === "Peso" ? "peso (kg)" : metric === "Reps" ? "repeticiones" : "volumen (kg)"}`}</span>
              </div>
              <div className="flex" style={{ gap: 6 }}>
                {METRICS.map((m) => (
                  <button key={m} type="button" onClick={() => setMetric(m)} style={chip(metric === m)}>{m}</button>
                ))}
              </div>
            </div>
            <span style={{ position: "absolute", top: 16, right: 16, backgroundColor: "#FFFBEB", borderRadius: 8, border: "1px solid #FDE68A", padding: "4px 10px", fontSize: 11, fontWeight: 600, color: "#92400E" }}>
              {`🏆 PR: ${num(pr)} kg`}
            </span>
            <div style={{ height: 220 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="#F1F5F9" strokeDasharray="4 4" />
                  <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, yMax]} tickCount={5} width={36} tick={{ fontSize: 10, fill: "#94A3B8" }} axisLine={false} tickLine={false} tickFormatter={(v: number) => num(v)} />
                  <Tooltip
                    content={({ active, payload, label }) =>
                      active && payload?.length ? (
                        <div style={{ backgroundColor: "#FFFFFF", borderRadius: 8, border: "1px solid #E2E8F0", padding: "8px 12px", fontSize: 11 }}>
                          <div style={{ color: "#94A3B8", marginBottom: 2 }}>{label}</div>
                          {payload.map((p) => (
                            <div key={String(p.dataKey)} style={{ color: p.dataKey === "b" ? "#3B82F6" : "#111827", fontWeight: 600 }}>
                              {`${p.dataKey === "b" ? ex2 : ex}: ${num(Number(p.value))} ${unit(metric)}`}
                            </div>
                          ))}
                        </div>
                      ) : null
                    }
                  />
                  <Line type="monotone" dataKey="a" stroke="#111827" strokeWidth={2} dot={{ r: 3, fill: "#FFFFFF", stroke: "#111827", strokeWidth: 2 }} activeDot={{ r: 4 }} />
                  {ex2 ? <Line type="monotone" dataKey="b" stroke="#3B82F6" strokeWidth={2} dot={{ r: 3, fill: "#FFFFFF", stroke: "#3B82F6", strokeWidth: 2 }} activeDot={{ r: 4 }} /> : null}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={{ backgroundColor: "#FFFFFF", borderRadius: 12, border: "1px solid #E2E8F0", overflow: "hidden" }}>
            <table className="w-full" style={{ borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ backgroundColor: "#F8FAFC", borderBottom: "1px solid #E2E8F0" }}>
                  {["Fecha", "Sets × Reps", "Peso (kg)", "Vol. total", "Notas"].map((h) => (
                    <th key={h} style={{ padding: "10px 16px", fontSize: 11, fontWeight: 600, color: "#94A3B8", textAlign: "left" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {last5.map((r, i) => (
                  <tr key={r.date.toISOString()} style={{ backgroundColor: i % 2 ? "#FAFAFA" : "#FFFFFF", borderBottom: "1px solid #F1F5F9", fontSize: 12, color: "#374151" }}>
                    <td style={{ padding: "10px 16px", fontWeight: 500, color: "#111827" }}>{`${fmt(r.date)} ${r.date.getFullYear()}`}</td>
                    <td style={{ padding: "10px 16px" }}>{`${r.sets} × ${r.reps}`}</td>
                    <td style={{ padding: "10px 16px" }}>
                      <span className="inline-flex items-center" style={{ gap: 4 }}>
                        {`${num(r.weight)} kg`}
                        {r.weight === pr && i === last5.findIndex((x) => x.weight === pr) ? <Trophy size={11} color="#D97706" /> : null}
                      </span>
                    </td>
                    <td style={{ padding: "10px 16px" }}>{`${num(r.sets * r.reps * r.weight)} kg`}</td>
                    <td style={{ padding: "10px 16px", color: r.note ? "#374151" : "#94A3B8" }}>{r.note || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button type="button" onClick={() => setPeriod("1 año")} className="block w-full" style={{ fontSize: 12, color: "#3B82F6", textAlign: "center", padding: "10px 0", background: "none", border: "none", cursor: "pointer" }}>
              Ver historial completo
            </button>
          </div>
        </>
      ) : (
        <div style={{ border: "1.5px dashed #E2E8F0", borderRadius: 12, padding: 32, textAlign: "center", fontSize: 13, color: "#94A3B8" }}>
          Elegí un ejercicio para ver su progresión.
        </div>
      )}
    </div>
  );
}
