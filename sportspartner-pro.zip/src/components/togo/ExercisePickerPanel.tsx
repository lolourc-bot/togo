import { useState } from "react";
import { Check, Play, Plus, Search, X } from "lucide-react";
import { toast } from "sonner";
import { LIBRARY_EXERCISES, PICKER_PATTERN_CHIPS, type LibraryExercise, type MovementPattern } from "@/lib/exercise-data";
import { VideoField } from "@/components/togo/VideoField";

const GROUPS: [string, MovementPattern][] = [
  ["Pecho", "Empuje horizontal"], ["Espalda", "Tracción horizontal"], ["Hombros", "Empuje vertical"],
  ["Bíceps", "Tracción horizontal"], ["Tríceps", "Empuje vertical"], ["Piernas", "Sentadilla"],
  ["Glúteos", "Bisagra"], ["Core", "Core"], ["Full body", "DLO"],
];
const TYPES = ["Fuerza", "Cardio", "Movilidad", "Técnica"];

function chip(label: string, selected: boolean, onClick: () => void) {
  return (
    <button key={label} type="button" onClick={onClick} style={{
      height: 28, flexShrink: 0, borderRadius: 20, padding: "0 12px", fontSize: 12, fontWeight: 500, cursor: "pointer",
      whiteSpace: "nowrap", transition: "all .2s",
      background: selected ? "var(--color-primary)" : "var(--bg-surface-2)",
      color: selected ? "#FFFFFF" : "var(--text-secondary)",
      border: `1px solid ${selected ? "var(--color-primary)" : "var(--border-default)"}`,
    }}>{label}</button>
  );
}

export function ExercisePickerPanel({
  open,
  onClose,
  onAdd,
}: {
  open: boolean;
  onClose: () => void;
  onAdd: (exercise: LibraryExercise) => void;
}) {
  const [query, setQuery] = useState("");
  const [pattern, setPattern] = useState("Todos");
  const [added, setAdded] = useState<string | null>(null);
  const [quick, setQuick] = useState(false);
  const [qName, setQName] = useState("");
  const [qGroup, setQGroup] = useState("Pecho");
  const [qType, setQType] = useState("Fuerza");
  const [qYt, setQYt] = useState("");
  const [qHover, setQHover] = useState(false);

  if (!open) return null;

  const results = LIBRARY_EXERCISES.filter((e) => {
    if (pattern !== "Todos" && e.pattern !== pattern) return false;
    if (query.trim() && !e.name.toLowerCase().includes(query.trim().toLowerCase())) return false;
    return true;
  });

  const handleAdd = (e: LibraryExercise) => {
    onAdd(e);
    setAdded(e.name);
    setTimeout(() => setAdded(null), 200);
  };

  return (
    <>
      <div
        role="presentation"
        onClick={onClose}
        style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.2)", zIndex: 59 }}
      />
      <div
        className="togo-panel-slide flex flex-col"
        style={{
          position: "fixed",
          right: 0,
          top: 0,
          height: "100vh",
          width: 400,
          backgroundColor: "#FFFFFF",
          borderLeft: "1px solid #E2E8F0",
          zIndex: 60,
        }}
      >
        {/* HEADER */}
        <div
          className="flex items-center justify-between"
          style={{ padding: "20px 20px 16px", borderBottom: "1px solid #E2E8F0" }}
        >
          <span style={{ fontSize: 15, fontWeight: 600, color: "#111827" }}>Agregar ejercicio</span>
          <button type="button" aria-label="Cerrar" onClick={onClose} style={{ cursor: "pointer" }}>
            <X size={18} color="#94A3B8" />
          </button>
        </div>

        {/* SEARCH */}
        <div style={{ padding: "12px 16px" }}>
          <div
            className="flex items-center"
            style={{
              height: 38,
              width: "100%",
              border: "1px solid #E2E8F0",
              borderRadius: 10,
              backgroundColor: "#F8FAFC",
              padding: "0 12px",
              gap: 8,
            }}
          >
            <Search size={14} color="#CBD5E1" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar ejercicio..."
              aria-label="Buscar ejercicio"
              className="togo-search"
              style={{
                flex: 1,
                border: "none",
                outline: "none",
                background: "transparent",
                fontSize: 13,
                color: "#111827",
              }}
            />
          </div>
        </div>

        {/* CHIPS */}
        <div
          className="flex"
          style={{ padding: "0 16px 12px", gap: 8, overflowX: "auto", scrollbarWidth: "none" }}
        >
          {PICKER_PATTERN_CHIPS.map((c) => {
            const selected = c === pattern;
            return (
              <button
                key={c}
                type="button"
                onClick={() => setPattern(c)}
                style={{
                  height: 28,
                  flexShrink: 0,
                  borderRadius: 20,
                  padding: "0 12px",
                  fontSize: 12,
                  fontWeight: 500,
                  cursor: "pointer",
                  backgroundColor: selected ? "#111827" : "#FFFFFF",
                  border: `1px solid ${selected ? "#111827" : "#E2E8F0"}`,
                  color: selected ? "#FFFFFF" : "#64748B",
                  whiteSpace: "nowrap",
                }}
              >
                {c}
              </button>
            );
          })}
        </div>

        {/* LIST */}
        <div
          className="flex flex-1 flex-col overflow-y-auto"
          style={{ padding: "0 16px 16px", gap: 8 }}
        >
          {results.map((e) => (
            <div
              key={e.name}
              role="button"
              tabIndex={0}
              onClick={() => handleAdd(e)}
              onKeyDown={(ev) => {
                if (ev.key === "Enter") handleAdd(e);
              }}
              className="togo-picker-row flex items-center"
              style={{
                backgroundColor: "#FFFFFF",
                border: "1px solid #E2E8F0",
                borderRadius: 10,
                padding: "10px 12px",
                gap: 10,
                cursor: "pointer",
              }}
            >
              <span
                className="flex items-center justify-center"
                style={{ width: 44, height: 32, backgroundColor: "#F1F5F9", borderRadius: 6 }}
              >
                <Play size={12} color="#CBD5E1" />
              </span>
              <span className="flex-1" style={{ minWidth: 0 }}>
                <span
                  className="block truncate"
                  style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}
                >
                  {e.name}
                </span>
                <span className="block" style={{ fontSize: 11, color: "#94A3B8", marginTop: 2 }}>
                  {e.pattern} · {e.equipment}
                </span>
              </span>
              {added === e.name ? (
                <Check size={18} color="#16A34A" />
              ) : (
                <Plus size={18} color="#CBD5E1" />
              )}
            </div>
          ))}
          {results.length === 0 && !query.trim() && (
            <p style={{ fontSize: 12, color: "#94A3B8" }}>No hay ejercicios con estos filtros.</p>
          )}
          {results.length === 0 && query.trim() && (
            <div className="flex flex-col items-center" style={{ padding: "20px 16px", gap: 12, textAlign: "center" }}>
              <Search size={24} color="var(--text-muted)" />
              <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text-primary)" }}>No encontramos '{query.trim()}'</span>
              <span style={{ fontSize: 12, color: "var(--text-muted)" }}>¿Querés agregarlo como ejercicio nuevo?</span>
              <div role="button" tabIndex={0}
                onClick={() => { setQName(query.trim()); setQGroup("Pecho"); setQType("Fuerza"); setQYt(""); setQuick(true); }}
                onKeyDown={(ev) => { if (ev.key === "Enter") { setQName(query.trim()); setQuick(true); } }}
                onMouseEnter={() => setQHover(true)} onMouseLeave={() => setQHover(false)}
                className="flex items-center"
                style={{ width: "100%", gap: 10, padding: "14px 16px", cursor: "pointer", textAlign: "left", transition: "all .2s",
                  border: `1px dashed ${qHover ? "var(--color-primary)" : "var(--border-default)"}`, borderRadius: "var(--radius-md)",
                  background: qHover ? "var(--color-primary-light)" : "transparent" }}>
                <Plus size={16} color="var(--color-primary)" />
                <span className="flex flex-col">
                  <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text-primary)" }}>Agregar '{query.trim()}'</span>
                  <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Se guardará en tu biblioteca del Lab.</span>
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
      {quick && (
        <div role="presentation" onClick={() => setQuick(false)} className="flex items-end justify-center sm:items-center"
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.35)", zIndex: 70 }}>
          <div role="dialog" aria-label="Nuevo ejercicio" onClick={(e) => e.stopPropagation()}
            style={{ width: "min(420px, 100%)", maxHeight: "90vh", overflowY: "auto", background: "#FFFFFF", borderRadius: "var(--radius-lg)" }}>
            <div className="flex items-center justify-between" style={{ background: "#011726", borderRadius: "var(--radius-lg) var(--radius-lg) 0 0", padding: "16px 20px" }}>
              <span style={{ fontSize: 15, fontWeight: 700, color: "#FFFFFF" }}>Nuevo ejercicio</span>
              <button type="button" aria-label="Cerrar" onClick={() => setQuick(false)} style={{ cursor: "pointer" }}><X size={18} color="#FFFFFF" /></button>
            </div>
            <div className="flex flex-col" style={{ padding: 20, gap: 12 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-secondary)" }}>Nombre</label>
              <input value={qName} onChange={(e) => setQName(e.target.value)} aria-label="Nombre"
                style={{ height: 38, padding: "0 12px", fontSize: 13, border: "1.5px solid var(--border-default)", borderRadius: "var(--radius-sm)", color: "var(--text-primary)" }} />
              <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-secondary)" }}>Grupo muscular</label>
              <div className="flex" style={{ gap: 8, overflowX: "auto", scrollbarWidth: "none" }}>
                {GROUPS.map(([g]) => chip(g, qGroup === g, () => setQGroup(g)))}
              </div>
              <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-secondary)" }}>Tipo</label>
              <div className="flex flex-wrap" style={{ gap: 8 }}>
                {TYPES.map((t) => chip(t, qType === t, () => setQType(t)))}
              </div>
              <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-secondary)" }}>Video (opcional)</label>
              <VideoField>
                <input value={qYt} onChange={(e) => setQYt(e.target.value)} placeholder="https://youtube.com/..." aria-label="Link de YouTube"
                  style={{ width: "100%", height: 38, padding: "0 12px", fontSize: 13, border: "1.5px solid var(--border-default)", borderRadius: "var(--radius-sm)" }} />
              </VideoField>
            </div>
            <div className="flex" style={{ padding: "14px 20px", borderTop: "1px solid var(--border-default)", gap: 10 }}>
              <button type="button" onClick={() => setQuick(false)} className="flex-1"
                style={{ height: 40, borderRadius: "var(--radius-lg)", border: "1.5px solid var(--border-default)", color: "#111827", fontSize: 13, fontWeight: 600, background: "transparent" }}>Cancelar</button>
              <button type="button" disabled={!qName.trim()} className="flex-1"
                onClick={() => {
                  const ex: LibraryExercise = { name: qName.trim(), pattern: GROUPS.find(([g]) => g === qGroup)?.[1] ?? "Core",
                    equipment: qType, laterality: "Bilateral", source: "Coach" };
                  LIBRARY_EXERCISES.push(ex);
                  onAdd(ex);
                  setQuick(false);
                  setQuery("");
                  toast.success("Ejercicio creado y agregado ✓");
                }}
                style={{ height: 40, borderRadius: "var(--radius-lg)", background: "var(--color-primary)", color: "#FFFFFF", fontSize: 13, fontWeight: 600, opacity: qName.trim() ? 1 : 0.4 }}>Crear y agregar</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
