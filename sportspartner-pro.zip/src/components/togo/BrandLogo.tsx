import logo from "@/assets/togo-logo.png.asset.json";

/** Official uploaded mark; never recolor or crop the artwork. */
export function BrandLogo({ className = "h-10 w-10" }: { className?: string }) {
  return <img src={logo.url} alt="TOGO" width={512} height={512} className={`shrink-0 object-contain ${className}`} />;
}