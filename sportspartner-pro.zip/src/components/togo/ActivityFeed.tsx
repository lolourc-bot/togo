import { MessageSquare, Clock, Zap } from "lucide-react";
import { Link } from "@tanstack/react-router";

type Session = {
  name: string;
  session: string;
  time: string;
  blocks: string;
  duration: string;
  rpe: number;
  comment?: string;
};

const sessions: Session[] = [
  {
    name: "Lucía Torres",
    session: "Fuerza — Lunes",
    time: "hace 2h",
    blocks: "6/6",
    duration: "58 min",
    rpe: 8,
    comment: "Muy buena sesión, sentí que mejoré en el peso muerto",
  },
  {
    name: "Santiago Pérez",
    session: "Hipertrofia — Martes",
    time: "hace 4h",
    blocks: "5/6",
    duration: "72 min",
    rpe: 9,
  },
  {
    name: "Camila Sánchez",
    session: "Movilidad — Miércoles",
    time: "ayer",
    blocks: "4/4",
    duration: "45 min",
    rpe: 4,
    comment: "Me costó un poco la parte de cadena posterior",
  },
  {
    name: "Federico Díaz",
    session: "Fuerza — Lunes",
    time: "ayer",
    blocks: "6/6",
    duration: "61 min",
    rpe: 7,
  },
  {
    name: "Valentina García",
    session: "Cardio — Jueves",
    time: "hace 2 días",
    blocks: "3/5",
    duration: "38 min",
    rpe: 6,
    comment: "Tuve que saltear los últimos dos porque llegué tarde",
  },
  {
    name: "Agustina Ruiz",
    session: "Hipertrofia — Martes",
    time: "hace 2 días",
    blocks: "6/6",
    duration: "67 min",
    rpe: 10,
  },
  {
    name: "Tomás Fernández",
    session: "Fuerza — Viernes",
    time: "hace 5 días",
    blocks: "4/6",
    duration: "54 min",
    rpe: 8,
    comment: "Me dolía el hombro derecho en press",
  },
  {
    name: "Matías López",
    session: "Movilidad — Lunes",
    time: "hace 6 días",
    blocks: "5/5",
    duration: "42 min",
    rpe: 3,
  },
];

function slugify(name: string) {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-");
}

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

function truncate(text: string, max = 60) {
  return text.length > max ? `${text.slice(0, max)}…` : text;
}

function parseBlocks(value: string) {
  const parts = value.split("/");
  const completed = Number(parts[0] ?? 0);
  const total = Number(parts[1] ?? 0);
  return { completed: Number.isNaN(completed) ? 0 : completed, total: Number.isNaN(total) ? 0 : total };
}

function BlockDots({ blocks }: { blocks: string }) {
  const { completed, total } = parseBlocks(blocks);
  return (
    <span className="flex items-center gap-1">
      {Array.from({ length: total }).map((_, i) => (
        <span
          key={i}
          className="inline-block h-[10px] w-[10px] rounded-full"
          style={{
            backgroundColor: i < completed ? "#111827" : "transparent",
            border: "1.5px solid #111827",
          }}
        />
      ))}
    </span>
  );
}

export function ActivityFeed() {
  return (
    <section>
      <h2 className="mb-3 text-[0.9375rem] font-semibold text-foreground">Actividad reciente</h2>

      <div className="flex flex-col gap-2">
        {sessions.map((s) => (
          <Link
            key={`${s.name}-${s.session}`}
            to="/atletas/$athleteId"
            params={{ athleteId: slugify(s.name) }}
            className="card-surface block w-full px-4 py-3.5 transition-colors hover:bg-surface-hover"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex h-[38px] w-[38px] items-center justify-center rounded-full bg-border text-[0.8125rem] font-semibold text-foreground">
                  {initials(s.name)}
                </div>
                <div>
                  <p className="text-[0.875rem] font-semibold text-foreground">{s.name}</p>
                  <p className="text-[0.75rem] text-subtle">{s.session}</p>
                </div>
              </div>
              <span className="text-[0.75rem] text-subtle">{s.time}</span>
            </div>

            <div
              className="mt-2.5 grid items-center overflow-hidden"
              style={{ gridTemplateColumns: "140px 70px 64px 1fr", gap: 8 }}
            >
              <span className="flex w-[140px] min-w-[140px] max-w-[140px] flex-nowrap items-center justify-start gap-1.5 whitespace-nowrap">
                <span className="text-[11px]" style={{ color: "#94A3B8" }}>
                  Bloques
                </span>
                <BlockDots blocks={s.blocks} />
              </span>

              <span className="flex items-center whitespace-nowrap">
                <span
                  className="inline-flex items-center gap-1 rounded-full px-2 py-[3px] text-[11px] font-medium"
                  style={{ backgroundColor: "#FEF3C7", color: "#D97706" }}
                >
                  <Zap size={12} color="#D97706" />
                  RPE {s.rpe}
                </span>
              </span>

              <span
                className="flex items-center justify-end gap-1 whitespace-nowrap text-[11px]"
                style={{ color: "#94A3B8" }}
              >
                <Clock size={12} />
                {s.duration}
              </span>

              {s.comment ? (
                <span className="flex min-w-0 items-center gap-1.5 overflow-hidden">
                  <MessageSquare size={12} className="shrink-0" style={{ color: "#94A3B8" }} />
                  <span className="truncate text-[11px] italic" style={{ color: "#64748B" }}>
                    {truncate(s.comment)}
                  </span>
                </span>
              ) : (
                <span />
              )}
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
