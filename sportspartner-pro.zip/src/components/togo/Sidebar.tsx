import { useNavigate } from "@tanstack/react-router";
import { BrandLogo } from "./BrandLogo";
import {
  Home,
  Users,
  BookOpen,
  ShoppingBag,
  MessageCircle,
  Activity,
  FlaskConical,
  Receipt,
  Settings,
  type LucideIcon,
} from "lucide-react";

const navItems: {
  icon: LucideIcon;
  label: string;
  badge?: string;
  to?: "/" | "/atletas" | "/equipos" | "/biblioteca" | "/bienestar" | "/mensajes" | "/marketplace-coach" | "/facturacion" | "/configuracion" | "/lab";
}[] = [
  { icon: Home, label: "Inicio", to: "/" },
  { icon: Users, label: "Atletas", to: "/atletas" },
  { icon: Users, label: "Equipos", to: "/equipos" },
  { icon: BookOpen, label: "Biblioteca", to: "/biblioteca" },
  { icon: ShoppingBag, label: "Marketplace", to: "/marketplace-coach" },
  { icon: Receipt, label: "Facturación", to: "/facturacion" },
  { icon: MessageCircle, label: "Mensajes", badge: "2", to: "/mensajes" },
  { icon: Activity, label: "Bienestar", to: "/bienestar" },
  { icon: FlaskConical, label: "Lab", to: "/lab" },
];


export function Sidebar({ active = "Inicio" }: { active?: string }) {
  const navigate = useNavigate();
  return (
    <aside
      className="flex w-[240px] shrink-0 flex-col border-r border-border bg-surface"
      style={{ height: "100vh", position: "sticky", top: 0, overflowY: "auto" }}
    >
      <div className="flex items-center gap-3 p-5">
        <BrandLogo className="h-8 w-8" />
        <span className="text-[1rem] font-bold text-foreground">TOGO</span>
      </div>

      <nav className="mt-8 flex flex-col gap-1 px-3">
        {navItems.map(({ icon: Icon, label, badge, to }) => {
          const isActive = active === label;
          return (
            <button
              key={label}
              type="button"
              onClick={() => {
                if (to) navigate({ to });
              }}
              className="flex h-10 items-center gap-3 rounded-sm px-3 text-left text-[0.875rem] transition-colors"
              style={
                isActive
                  ? { backgroundColor: "var(--color-primary-light)", color: "var(--color-primary)", fontWeight: 600 }
                  : undefined
              }
            >
              <Icon size={16} strokeWidth={2} className={isActive ? "" : "text-muted-foreground"} />
              <span className={`flex-1 ${isActive ? "" : "text-muted-foreground"}`}>{label}</span>
              {badge ? (
                <span
                  className="inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 py-0.5 text-[11px] font-semibold leading-none"
                  style={{ backgroundColor: "#DC2626", color: "#FFFFFF" }}
                >
                  {badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </nav>

      <div className="mt-auto flex items-center gap-3 border-t border-border p-4">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-border text-[0.75rem] font-semibold text-foreground">
          PR
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[0.8125rem] font-medium text-foreground">Pablo Rodríguez</p>
          <p className="truncate text-[0.6875rem] text-subtle">Pro · 12 atletas</p>
        </div>
        <button type="button" onClick={() => navigate({ to: "/configuracion" })} aria-label="Configuración">
          <Settings size={16} className="text-subtle" />
        </button>
      </div>
    </aside>
  );
}
