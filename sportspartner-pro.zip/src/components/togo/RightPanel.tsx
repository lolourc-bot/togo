import { AlertTriangle, CheckCircle, MessageCircle, CreditCard } from "lucide-react";

const urgent = [
  { name: "Tomás Fernández", daysLeft: 3, chip: "Urgente", tone: "danger" },
  { name: "Matías López", daysLeft: 8, chip: "Esta semana", tone: "warning" },
].sort((a, b) => a.daysLeft - b.daysLeft);

const feed = [
  {
    icon: CheckCircle,
    color: "text-success",
    text: "Lucía Torres completó Fuerza — Lunes",
    time: "hace 2h",
  },
  {
    icon: MessageCircle,
    color: "text-muted-foreground",
    text: "Santiago Pérez envió un mensaje",
    time: "hace 3h",
  },
  {
    icon: AlertTriangle,
    color: "text-danger",
    text: "Agustina Ruiz reportó fatiga alta",
    time: "hace 5h",
    alert: true,
  },
  {
    icon: CheckCircle,
    color: "text-success",
    text: "Camila Sánchez completó Movilidad — Miércoles",
    time: "ayer",
  },
  {
    icon: CreditCard,
    color: "text-muted-foreground",
    text: "Federico Díaz renovó su plan",
    time: "ayer",
  },
] as const;

export function UrgentCard() {
  return (
    <section className="card-surface p-4">
      <div className="flex items-center gap-2">
        <AlertTriangle size={14} className="text-danger" />
        <h2 className="text-[0.875rem] font-semibold text-foreground">Planificación urgente</h2>
      </div>

      <div className="mt-2">
        {urgent.map((item) => (
          <div
            key={item.name}
            className="flex items-center justify-between border-b border-surface-hover py-2.5 last:border-b-0"
          >
            <div className="flex min-w-0 items-center gap-3">
              <p className="max-w-[100px] truncate text-[0.8125rem] font-medium text-foreground">{item.name}</p>
              <p className="whitespace-nowrap text-[0.6875rem] text-[#94A3B8]">Vence en {item.daysLeft} días</p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <span
                className={`chip py-1 text-[0.6875rem] ${
                  item.tone === "danger"
                    ? "bg-danger-soft text-danger"
                    : "bg-warning-soft text-warning"
                }`}
              >
                {item.chip}
              </span>
              <button
                type="button"
                className="rounded-sm bg-primary px-2.5 py-1 text-[0.6875rem] font-medium text-primary-foreground transition-colors hover:opacity-90"
              >
                Planificar
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function ActivityCard() {
  return (
    <section className="card-surface p-4">
      <h2 className="text-[0.875rem] font-semibold text-foreground">Actividad reciente</h2>

      <div className="mt-2">
        {feed.map(({ icon: Icon, color, text, time, ...rest }) => {
          const alert = "alert" in rest && rest.alert;
          return (
            <div
              key={text}
              className={`flex items-start gap-2.5 border-b border-background py-2 last:border-b-0 ${
                alert ? "rounded-sm bg-danger-softer px-2 py-1.5" : ""
              }`}
            >
              <Icon size={15} className={`mt-0.5 shrink-0 ${color}`} />
              <p className="flex-1 text-[0.8125rem] text-foreground">{text}</p>
              <span className="shrink-0 text-[0.6875rem] text-subtle">{time}</span>
              {alert ? (
                <button
                  type="button"
                  className="shrink-0 text-[0.6875rem] text-muted-foreground underline-offset-2 hover:underline"
                >
                  Ver
                </button>
              ) : null}
            </div>
          );
        })}
      </div>
    </section>
  );
}
