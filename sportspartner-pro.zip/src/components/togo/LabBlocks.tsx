import { forwardRef, useImperativeHandle, useMemo, useState } from "react";
import { Search, MoreHorizontal, Plus } from "lucide-react";
import {
  CircuitModal,
  circuitTimerLabel,
  emptyCircuitConfig,
  type CircuitConfig,
} from "@/components/togo/CircuitModal";

export type LabBlocksHandle = { newCircuit: () => void };

const mk = (
  name: string,
  type: CircuitConfig["type"],
  exercises: { name: string; reps: string }[],
  extra?: Partial<CircuitConfig>,
): CircuitConfig => ({
  ...emptyCircuitConfig(),
  name,
  type,
  exercises: exercises.map((e) => ({ name: e.name, reps: e.reps, weight: "", unit: "kg" })),
  ...extra,
});

const INITIAL: CircuitConfig[] = [
  mk("Finisher metabólico", "AMRAP", [
    { name: "Swing con pesa rusa", reps: "15" },
    { name: "Box jump", reps: "10" },
  ]),
  mk(
    "Core EMOM 10'",
    "EMOM",
    [
      { name: "Hollow hold", reps: "30s" },
      { name: "Plancha lateral", reps: "20s" },
    ],
    { emomInterval: 60, emomRounds: 10 },
  ),
  mk("Tabata piernas", "TABATA", [
    { name: "Sentadilla con salto", reps: "12" },
    { name: "Estocada alternada", reps: "10" },
  ]),
  mk("Full body ASAP", "ASAP", [
    { name: "Thruster", reps: "21" },
    { name: "Pull-up", reps: "15" },
    { name: "Burpee", reps: "9" },
  ]),
];

const MENU = ["Editar", "Duplicar", "Agregar a sesión", "Eliminar"];

export const LabBlocks = forwardRef<LabBlocksHandle>(function LabBlocks(_props, ref) {
  const [query, setQuery] = useState("");
  const [circuits, setCircuits] = useState<CircuitConfig[]>(INITIAL);
  const [openMenu, setOpenMenu] = useState<number | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editIndex, setEditIndex] = useState<number | null>(null);

  useImperativeHandle(ref, () => ({
    newCircuit: () => {
      setEditIndex(null);
      setModalOpen(true);
    },
  }));

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return circuits.map((c, i) => ({ c, i }));
    return circuits
      .map((c, i) => ({ c, i }))
      .filter(
        ({ c }) =>
          c.name.toLowerCase().includes(q) ||
          c.type.toLowerCase().includes(q) ||
          c.exercises.some((e) => e.name.toLowerCase().includes(q)),
      );
  }, [circuits, query]);

  const submit = (cfg: CircuitConfig) => {
    setCircuits((prev) => {
      if (editIndex === null) return [...prev, cfg];
      return prev.map((c, i) => (i === editIndex ? cfg : c));
    });
    setModalOpen(false);
    setEditIndex(null);
  };

  return (
    <div>
      <div className="flex flex-row items-center gap-3" style={{ marginBottom: 20 }}>
        <div className="relative" style={{ maxWidth: 280, flex: 1 }}>
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#CBD5E1" }} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar circuito..."
            aria-label="Buscar circuito"
            className="w-full rounded-[10px] border bg-white pl-9 pr-3 text-[13px] outline-none"
            style={{ height: 38, borderColor: "#E2E8F0", color: "#111827" }}
          />
        </div>
        <span className="text-[12px]" style={{ color: "#94A3B8" }}>
          Todos los circuitos
        </span>
      </div>

      <div className="grid gap-3" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
        {list.map(({ c, i }) => (
          <div
            key={`${c.name}-${i}`}
            className="flex flex-col gap-2.5 rounded-[14px] bg-white"
            style={{
              borderLeft: "3px solid #D97706",
              borderTop: "1px solid #E2E8F0",
              borderRight: "1px solid #E2E8F0",
              borderBottom: "1px solid #E2E8F0",
              padding: "16px 18px",
            }}
          >
            <div className="flex flex-row items-center gap-2">
              <span className="text-[10px] font-bold" style={{ color: "#D97706", width: 18 }}>
                {`C${i + 1}`}
              </span>
              <span
                className="rounded-[4px] text-[9px] font-bold"
                style={{ backgroundColor: "#FFFBEB", color: "#D97706", padding: "2px 6px" }}
              >
                {c.type}
              </span>
              <span className="min-w-0 flex-1 truncate text-[13px] font-semibold" style={{ color: "#111827" }}>
                {c.name || "Circuito sin nombre"}
              </span>
              {circuitTimerLabel(c) ? (
                <span
                  className="whitespace-nowrap rounded-[6px] text-[11px]"
                  style={{ backgroundColor: "#FFFBEB", color: "#D97706", padding: "2px 8px" }}
                >
                  {circuitTimerLabel(c)}
                </span>
              ) : null}

              <div className="relative">
                <button
                  type="button"
                  onClick={() => setOpenMenu(openMenu === i ? null : i)}
                  aria-label={`Más opciones circuito ${i + 1}`}
                >
                  <MoreHorizontal size={15} style={{ color: "#CBD5E1" }} />
                </button>
                {openMenu === i ? (
                  <>
                    <div className="fixed inset-0" style={{ zIndex: 5 }} onClick={() => setOpenMenu(null)} />
                    <div
                      className="absolute rounded-[10px] border bg-white"
                      style={{
                        right: 0,
                        top: 22,
                        zIndex: 10,
                        minWidth: 180,
                        padding: 4,
                        borderColor: "#E2E8F0",
                        boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
                      }}
                    >
                      {MENU.map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => {
                            setOpenMenu(null);
                            if (m === "Editar") {
                              setEditIndex(i);
                              setModalOpen(true);
                            }
                            if (m === "Duplicar")
                              setCircuits((prev) => [...prev, { ...c, name: `${c.name} (copia)` }]);
                            if (m === "Eliminar")
                              setCircuits((prev) => prev.filter((_x, idx) => idx !== i));
                          }}
                          className="flex w-full whitespace-nowrap rounded-[6px] text-left text-[12px] hover:bg-[#F8FAFC]"
                          style={{ padding: "8px 12px", color: "#374151" }}
                        >
                          {m}
                        </button>
                      ))}
                    </div>
                  </>
                ) : null}
              </div>
            </div>

            <div className="flex flex-col gap-1">
              {c.exercises.map((e, ei) => (
                <div key={`${e.name}-${ei}`} className="flex flex-row items-center gap-2">
                  <span className="text-[10px] font-bold" style={{ color: "#D97706" }}>
                    {`E${ei + 1}`}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-[12px]" style={{ color: "#374151" }}>
                    {e.name}
                  </span>
                  {e.reps ? (
                    <span
                      className="rounded-[4px] text-[10px]"
                      style={{ backgroundColor: "#F8FAFC", color: "#94A3B8", padding: "1px 6px" }}
                    >
                      {e.reps}
                    </span>
                  ) : null}
                </div>
              ))}
            </div>

            <div
              className="flex flex-row gap-2"
              style={{ marginTop: "auto", paddingTop: 10, borderTop: "1px solid #F8FAFC" }}
            >
              <button
                type="button"
                className="flex flex-1 items-center justify-center rounded-[8px] border text-[12px] hover:bg-[#F8FAFC]"
                style={{ height: 32, borderColor: "#E2E8F0", color: "#374151" }}
              >
                Agregar a sesión
              </button>
              <button
                type="button"
                onClick={() => {
                  setEditIndex(i);
                  setModalOpen(true);
                }}
                className="flex flex-1 items-center justify-center rounded-[8px] border text-[12px] hover:bg-[#F8FAFC]"
                style={{ height: 32, borderColor: "#E2E8F0", color: "#374151" }}
              >
                Editar circuito
              </button>
            </div>
          </div>
        ))}

        <button
          type="button"
          onClick={() => {
            setEditIndex(null);
            setModalOpen(true);
          }}
          className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-[14px]"
          style={{ border: "1.5px dashed #E2E8F0", backgroundColor: "#FFFFFF", minHeight: 150 }}
        >
          <Plus size={20} style={{ color: "#CBD5E1" }} />
          <span className="text-[13px]" style={{ color: "#94A3B8" }}>
            Nuevo circuito
          </span>
        </button>
      </div>

      <CircuitModal
        open={modalOpen}
        mode={editIndex === null ? "create" : "edit"}
        initial={editIndex === null ? null : (circuits[editIndex] ?? null)}
        onClose={() => {
          setModalOpen(false);
          setEditIndex(null);
        }}
        onSubmit={submit}
      />
    </div>
  );
});
