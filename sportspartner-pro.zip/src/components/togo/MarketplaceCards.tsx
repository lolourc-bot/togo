import { Dumbbell, Star } from "lucide-react";
import type { Coach, Program } from "@/lib/marketplace-data";

export function Rating({ value }: { value: string }) {
  return (
    <span className="flex items-center" style={{ gap: 3 }}>
      <Star size={11} color="#D97706" fill="#D97706" />
      <span style={{ fontSize: 11, color: "#64748B" }}>{value}</span>
    </span>
  );
}

export function ProgramCard({ program }: { program: Program }) {
  return (
    <div
      className="flex"
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 14,
        border: "1px solid #E2E8F0",
        padding: 14,
        gap: 12,
      }}
    >
      <div
        className="flex items-center justify-center"
        style={{
          width: 64,
          height: 64,
          backgroundColor: "#F1F5F9",
          borderRadius: 10,
          flexShrink: 0,
        }}
      >
        <Dumbbell size={24} color="#CBD5E1" />
      </div>
      <div className="flex" style={{ flex: 1, flexDirection: "column", gap: 4 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>
          {program.name}
        </span>
        <span style={{ fontSize: 11, color: "#94A3B8" }}>{program.meta}</span>
        <div className="flex" style={{ gap: 6 }}>
          {program.tags.map((tag) => (
            <span
              key={tag}
              style={{
                fontSize: 10,
                color: "#64748B",
                backgroundColor: "#F1F5F9",
                borderRadius: 6,
                padding: "2px 7px",
              }}
            >
              {tag}
            </span>
          ))}
        </div>
        <div className="flex items-center justify-between">
          <span style={{ fontSize: 13, fontWeight: 700, color: "#111827" }}>
            {program.price}
          </span>
          <Rating value={program.rating} />
        </div>
      </div>
    </div>
  );
}

export function CoachCard({
  coach,
  onContact,
}: {
  coach: Coach;
  onContact: () => void;
}) {
  return (
    <div
      className="flex items-center"
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 14,
        border: "1px solid #E2E8F0",
        padding: 14,
        gap: 12,
      }}
    >
      <div
        className="flex items-center justify-center"
        style={{
          width: 52,
          height: 52,
          borderRadius: "50%",
          backgroundColor: "#E2E8F0",
          flexShrink: 0,
        }}
      >
        <span style={{ fontSize: 16, fontWeight: 600, color: "#94A3B8" }}>
          {coach.initials}
        </span>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>
          {coach.name}
        </div>
        <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 2 }}>
          {coach.specialty}
        </div>
        <div className="flex items-center" style={{ gap: 4, marginTop: 4 }}>
          <Star size={11} color="#D97706" fill="#D97706" />
          <span style={{ fontSize: 11, color: "#64748B" }}>{coach.rating}</span>
          <span style={{ fontSize: 11, color: "#CBD5E1" }}>
            · {coach.reviews} reseñas
          </span>
        </div>
      </div>
      <button
        type="button"
        onClick={onContact}
        style={{
          border: "1px solid #111827",
          borderRadius: 8,
          padding: "6px 12px",
          fontSize: 12,
          fontWeight: 500,
          color: "#111827",
          backgroundColor: "#FFFFFF",
          cursor: "pointer",
          flexShrink: 0,
        }}
      >
        Contactar
      </button>
    </div>
  );
}
