import { createFileRoute } from "@tanstack/react-router";
import { ExploreView, PhoneFrame } from "@/components/togo/Entrenamiento";
import { AthleteBottomNav } from "@/components/togo/AthleteBottomNav";

export const Route = createFileRoute("/explorar")({
  head: () => ({
    meta: [
      { title: "Explorar coaches y programas · TOGO" },
      { name: "description", content: "Encontrá tu coach o programa ideal en TOGO." },
      { property: "og:title", content: "Explorar coaches y programas · TOGO" },
      { property: "og:description", content: "Encontrá tu coach o programa ideal en TOGO." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <PhoneFrame>
      <ExploreView />
      <AthleteBottomNav active="Marketplace" />
    </PhoneFrame>
  ),
});
