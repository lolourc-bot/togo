import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowDownLeft,
  Clock,
  ArrowUpFromLine,
  Building2,
  Calendar,
  Download,
  RotateCcw,
  TrendingUp,
  Users,
  Wallet,
  type LucideIcon,
} from "lucide-react";
import { Sidebar } from "@/components/togo/Sidebar";

export const Route = createFileRoute("/facturacion")({
  head: () => ({
    meta: [
      { title: "Facturación del coach — TOGO" },
      {
        name: "description",
        content:
          "Controlá ingresos, retiros, próximos cobros y suscripciones activas de tus programas en TOGO.",
      },
      { property: "og:title", content: "Facturación del coach — TOGO" },
      {
        property: "og:description",
        content: "Ingresos, pagos y estado de tus suscripciones en un solo lugar.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FacturacionPage,
});

const STATS: { label: string; value: string; sub: string; subColor: string; icon: LucideIcon; iconColor: string }[] = [
  {
    label: "Balance disponible",
    value: "$3.840",
    sub: "Listo para retirar",
    subColor: "#16A34A",
    icon: Wallet,
    iconColor: "#94A3B8",
  },
  {
    label: "Ingresos del mes",
    value: "$1.240",
    sub: "+12% vs mes anterior",
    subColor: "#16A34A",
    icon: TrendingUp,
    iconColor: "#16A34A",
  },
  {
    label: "Próximo cobro estimado",
    value: "$1.360",
    sub: "En 18 días",
    subColor: "#94A3B8",
    icon: Calendar,
    iconColor: "#94A3B8",
  },
  {
    label: "Suscripciones activas",
    value: "38",
    sub: "3 nuevas este mes",
    subColor: "#94A3B8",
    icon: Users,
    iconColor: "#94A3B8",
  },
];

type Bar = { m: string; v: number; current?: boolean };

const BARS_12: Bar[] = [
  { m: "Oct", v: 520 },
  { m: "Nov", v: 480 },
  { m: "Dic", v: 610 },
  { m: "Ene", v: 540 },
  { m: "Feb", v: 590 },
  { m: "Mar", v: 650 },
  { m: "Abr", v: 680 },
  { m: "May", v: 820 },
  { m: "Jun", v: 990 },
  { m: "Jul", v: 1100 },
  { m: "Ago", v: 1240 },
  { m: "Sep", v: 360, current: true },
];

const BARS_BY_PERIOD: Record<string, Bar[]> = {
  "3M": BARS_12.slice(-4),
  "6M": BARS_12.slice(-6),
  "1A": BARS_12,
};

type Tx = {
  kind: "Ingreso" | "Retiro" | "Reembolso";
  desc: string;
  sub: string;
  amount: string;
  date: string;
  processing?: boolean;
};

const TX: Tx[] = [
  { kind: "Ingreso", desc: "Suscripción — Martina González", sub: "Fuerza Total", amount: "19.99", date: "Hoy 09:14" },
  { kind: "Ingreso", desc: "Suscripción — Lucas Rodríguez", sub: "Fuerza Total", amount: "19.99", date: "Hoy 08:51" },
  { kind: "Ingreso", desc: "Suscripción — Sofía Pérez", sub: "Definición Verano", amount: "14.99", date: "Ayer 18:30" },
  { kind: "Retiro", desc: "Transferencia a cuenta bancaria", sub: "Banco Galicia ···· 4242", amount: "800.00", date: "5 sep" },
  { kind: "Ingreso", desc: "Suscripción — Tomás Fernández", sub: "Movilidad", amount: "9.99", date: "4 sep" },
  { kind: "Ingreso", desc: "Pago único — Camila Ramírez", sub: "Fuerza Total", amount: "59.99", date: "3 sep" },
  { kind: "Ingreso", desc: "Suscripción — Julián Martínez", sub: "Definición Verano", amount: "14.99", date: "2 sep" },
  { kind: "Reembolso", desc: "Cancelación — Rodrigo Blanco", sub: "Fuerza Total", amount: "19.99", date: "1 sep" },
  { kind: "Ingreso", desc: "Suscripción — Valentina Muñoz", sub: "Fuerza Total", amount: "19.99", date: "31 ago" },
  { kind: "Ingreso", desc: "Suscripción — Agustín Ibáñez", sub: "Movilidad", amount: "9.99", date: "30 ago" },
];

const UPCOMING = [
  { date: "15 oct", name: "Martina González", program: "Fuerza Total", amount: "$19.99" },
  { date: "15 oct", name: "Lucas Rodríguez", program: "Fuerza Total", amount: "$19.99" },
  { date: "15 oct", name: "Sofía Pérez", program: "Definición Verano", amount: "$14.99" },
  { date: "15 oct", name: "Tomás Fernández", program: "Movilidad", amount: "$9.99" },
  { date: "15 oct", name: "Valentina Muñoz", program: "Fuerza Total", amount: "$19.99" },
];

const BY_PROGRAM = [
  { name: "Fuerza Total 12 Semanas", subs: "18", total: "$359/mes", draft: false },
  { name: "Definición Verano", subs: "12", total: "$179/mes", draft: false },
  { name: "Movilidad y Flexibilidad", subs: "8", total: "$79/mes", draft: false },
  { name: "Hipertrofia Avanzada", subs: "0", total: "$0/mes", draft: true },
];

const FILTERS = ["Todas", "Ingresos", "Retiros", "Reembolsos"] as const;
const PERIODS = ["3M", "6M", "1A"] as const;

const card = {
  background: "#FFFFFF",
  borderRadius: 14,
  border: "1px solid #E2E8F0",
} as const;

const chip = (active: boolean) => ({
  height: 28,
  borderRadius: 6,
  padding: "0 10px",
  fontSize: 12,
  fontWeight: 500,
  background: active ? "#111827" : "#F1F5F9",
  color: active ? "#FFFFFF" : "#64748B",
  cursor: "pointer",
});

const headerBtn = {
  display: "inline-flex",
  alignItems: "center",
  gap: 8,
  border: "1px solid #E2E8F0",
  borderRadius: 10,
  padding: "8px 16px",
  fontSize: 13,
  fontWeight: 500,
  color: "#374151",
  background: "#FFFFFF",
  cursor: "pointer",
} as const;

function txStyle(kind: Tx["kind"]) {
  if (kind === "Ingreso")
    return { bg: "#F0FDF4", icon: ArrowDownLeft, color: "#16A34A", amountColor: "#16A34A", prefix: "+$" };
  if (kind === "Retiro")
    return { bg: "#F1F5F9", icon: ArrowUpFromLine, color: "#94A3B8", amountColor: "#374151", prefix: "-$" };
  return { bg: "#FEF2F2", icon: RotateCcw, color: "#EF4444", amountColor: "#EF4444", prefix: "-$" };
}

const BALANCE = 3840;

function FacturacionPage() {
  const [period, setPeriod] = useState<string>("6M");
  const [filter, setFilter] = useState<string>("Todas");
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [extraTx, setExtraTx] = useState<Tx[]>([]);

  const bars = BARS_BY_PERIOD[period] ?? BARS_BY_PERIOD["6M"]!;
  const barWidth = `${Math.min(10, 60 / bars.length)}%`;
  const amountNum = Number(amount.replace(",", ".")) || 0;
  const overBalance = amountNum > BALANCE;
  const canConfirm = amountNum > 0 && !overBalance;

  const confirmWithdraw = () => {
    setExtraTx((prev) => [
      {
        kind: "Retiro",
        desc: "Transferencia a cuenta bancaria",
        sub: "Banco Galicia ···· 4242",
        amount: amountNum.toFixed(2),
        date: "Procesando…",
        processing: true,
      },
      ...prev,
    ]);
    setWithdrawOpen(false);
    setAmount("");
  };

  const rows = [...extraTx, ...TX].filter((t) =>
    filter === "Todas"
      ? true
      : filter === "Ingresos"
        ? t.kind === "Ingreso"
        : filter === "Retiros"
          ? t.kind === "Retiro"
          : t.kind === "Reembolso",
  );

  const maxY = 1500;

  return (
    <div style={{ display: "flex", background: "#F8FAFC", minHeight: "100vh" }}>
      <style>{`
        .fa-bar:hover{background:#374151 !important}
        .fa-link:hover{color:#111827 !important}
      `}</style>
      <Sidebar active="Facturación" />

      <main style={{ flex: 1, minWidth: 0, padding: "32px 40px" }}>
        <div style={{ display: "flex", alignItems: "center", marginBottom: 8 }}>
          <h1 style={{ flex: 1, fontSize: 22, fontWeight: 700, color: "#111827" }}>Facturación</h1>
          <div style={{ display: "flex", gap: 10 }}>
            <button type="button" style={headerBtn} onClick={() => setWithdrawOpen(true)}>
              <ArrowUpFromLine size={14} color="#374151" /> Retirar fondos
            </button>
            <button type="button" style={headerBtn}>
              <Download size={14} color="#374151" /> Exportar
            </button>
          </div>
        </div>
        <p style={{ fontSize: 13, color: "#94A3B8", marginBottom: 24 }}>
          Ingresos, pagos y estado de tus suscripciones.
        </p>

        <div style={{ display: "flex", gap: 16, marginBottom: 28 }}>
          {STATS.map((s) => (
            <div key={s.label} style={{ ...card, padding: "18px 20px", flex: 1, position: "relative" }}>
              <s.icon size={20} color={s.iconColor} style={{ position: "absolute", top: 18, right: 20 }} />
              <p style={{ fontSize: 12, color: "#94A3B8", marginBottom: 6 }}>{s.label}</p>
              <p style={{ fontSize: 24, fontWeight: 700, color: "#111827" }}>{s.value}</p>
              <p style={{ fontSize: 12, color: s.subColor, marginTop: 4 }}>{s.sub}</p>
            </div>
          ))}
        </div>

        <div style={{ ...card, padding: 20, marginBottom: 24 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <span style={{ fontSize: 14, fontWeight: 600, color: "#111827" }}>Ingresos mensuales</span>
            <div style={{ display: "flex", gap: 8 }}>
              {PERIODS.map((p) => (
                <button key={p} type="button" onClick={() => setPeriod(p)} style={chip(period === p)}>
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <div
              style={{
                width: 44,
                height: 140,
                display: "flex",
                flexDirection: "column-reverse",
                justifyContent: "space-between",
              }}
            >
              {["$0", "$500", "$1000", "$1500"].map((y) => (
                <span key={y} style={{ fontSize: 10, color: "#CBD5E1" }}>
                  {y}
                </span>
              ))}
            </div>
            <div style={{ flex: 1, position: "relative", height: 140 }}>
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  style={{
                    position: "absolute",
                    left: 0,
                    right: 0,
                    bottom: (i / 3) * 140,
                    borderTop: "1px dashed #F1F5F9",
                  }}
                />
              ))}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  display: "flex",
                  alignItems: "flex-end",
                  justifyContent: "space-around",
                }}
              >
                {bars.map((b) => (
                  <div key={b.m} style={{ width: barWidth, textAlign: "center" }}>
                    {b.current ? (
                      <span style={{ display: "block", fontSize: 10, color: "#94A3B8", marginBottom: 4 }}>
                        mes en curso
                      </span>
                    ) : null}
                    <div
                      className="fa-bar"
                      style={{
                        height: (b.v / maxY) * 130,
                        background: "#111827",
                        borderRadius: "4px 4px 0 0",
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "space-around", marginTop: 8, paddingLeft: 54 }}>
            {bars.map((b) => (
              <span key={b.m} style={{ width: barWidth, textAlign: "center", fontSize: 11, color: "#94A3B8" }}>
                {b.m}
              </span>
            ))}
          </div>
        </div>

        <div style={{ display: "flex", gap: 20, alignItems: "flex-start" }}>
          <section style={{ ...card, flex: 1, minWidth: 0, overflow: "hidden" }}>
            <div
              style={{
                padding: "16px 20px",
                borderBottom: "1px solid #E2E8F0",
                display: "flex",
                alignItems: "center",
              }}
            >
              <h2 style={{ flex: 1, fontSize: 14, fontWeight: 600, color: "#111827" }}>
                Últimas transacciones
              </h2>
              <button type="button" className="fa-link" style={{ fontSize: 12, color: "#94A3B8", cursor: "pointer" }}>
                Ver todas
              </button>
            </div>
            <div
              style={{
                padding: "10px 20px",
                borderBottom: "1px solid #F8FAFC",
                display: "flex",
                gap: 8,
              }}
            >
              {FILTERS.map((f) => (
                <button key={f} type="button" onClick={() => setFilter(f)} style={chip(filter === f)}>
                  {f}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", flexDirection: "column" }}>
              {rows.map((t, i) => {
                const st = txStyle(t.kind);
                const Icon = st.icon;
                return (
                  <div
                    key={`${t.desc}-${i}`}
                    style={{
                      padding: "14px 20px",
                      borderBottom: "1px solid #F8FAFC",
                      display: "flex",
                      alignItems: "center",
                      gap: 12,
                    }}
                  >
                    <span
                      style={{
                        width: 36,
                        height: 36,
                        borderRadius: "50%",
                        background: st.bg,
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                    >
                      <Icon size={16} color={st.color} />
                    </span>
                    <span style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ display: "block", fontSize: 13, fontWeight: 500, color: "#111827" }}>
                        {t.desc}
                      </span>
                      <span style={{ display: "block", fontSize: 12, color: "#94A3B8", marginTop: 2 }}>
                        {t.sub}
                      </span>
                    </span>
                    <span style={{ textAlign: "right" }}>
                      <span style={{ display: "block", fontSize: 14, fontWeight: 600, color: st.amountColor }}>
                        {st.prefix}
                        {t.amount}
                      </span>
                      <span
                        style={{
                          display: "block",
                          fontSize: 11,
                          color: t.processing ? "#D97706" : "#CBD5E1",
                        }}
                      >
                        {t.date}
                      </span>
                    </span>
                  </div>
                );
              })}
            </div>
          </section>

          <aside style={{ width: 300, flexShrink: 0, display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ ...card, padding: 20 }}>
              <h3 style={{ fontSize: 13, fontWeight: 600, color: "#111827", marginBottom: 14 }}>
                Método de cobro
              </h3>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <Building2 size={20} color="#94A3B8" />
                <span style={{ flex: 1, fontSize: 13, color: "#374151" }}>Banco Galicia ···· 4242</span>
                <span
                  style={{
                    background: "#F1F5F9",
                    color: "#64748B",
                    fontSize: 10,
                    borderRadius: 10,
                    padding: "2px 8px",
                  }}
                >
                  Principal
                </span>
              </div>
              <button
                type="button"
                className="fa-link"
                style={{ fontSize: 12, color: "#94A3B8", marginTop: 12, cursor: "pointer" }}
              >
                Cambiar método
              </button>
            </div>

            <div style={{ ...card, padding: 20 }}>
              <h3 style={{ fontSize: 13, fontWeight: 600, color: "#111827", marginBottom: 14 }}>
                Próximos cobros
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {UPCOMING.map((u) => (
                  <div key={u.name} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span
                      style={{
                        fontSize: 10,
                        fontWeight: 600,
                        color: "#94A3B8",
                        background: "#F1F5F9",
                        borderRadius: 6,
                        padding: "2px 7px",
                        width: 44,
                        textAlign: "center",
                        flexShrink: 0,
                      }}
                    >
                      {u.date}
                    </span>
                    <span style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ display: "block", fontSize: 12, color: "#374151" }}>{u.name}</span>
                      <span style={{ display: "block", fontSize: 11, color: "#94A3B8" }}>{u.program}</span>
                    </span>
                    <span style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>{u.amount}</span>
                  </div>
                ))}
              </div>
              <button
                type="button"
                className="fa-link"
                style={{ fontSize: 12, color: "#94A3B8", marginTop: 12, cursor: "pointer" }}
              >
                +33 más
              </button>
            </div>

            <div style={{ ...card, padding: 20 }}>
              <h3 style={{ fontSize: 13, fontWeight: 600, color: "#111827", marginBottom: 14 }}>
                Por programa
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {BY_PROGRAM.map((p) => (
                  <div key={p.name} style={{ display: "flex", alignItems: "center", gap: 10, opacity: p.draft ? 0.5 : 1 }}>
                    <span style={{ flex: 1, minWidth: 0, fontSize: 12, color: "#374151" }}>{p.name}</span>
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 600,
                        color: "#111827",
                        background: "#F1F5F9",
                        borderRadius: 6,
                        padding: "2px 8px",
                      }}
                    >
                      {p.subs}
                    </span>
                    <span style={{ fontSize: 12, fontWeight: 600, color: "#16A34A" }}>{p.total}</span>
                  </div>
                ))}
              </div>
              <div
                style={{
                  borderTop: "1px solid #F1F5F9",
                  marginTop: 8,
                  paddingTop: 8,
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <span style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>Total</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>$617/mes</span>
              </div>
            </div>
          </aside>
        </div>
      </main>

      {withdrawOpen ? (
        <div
          onClick={() => setWithdrawOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.35)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 50,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 480,
              background: "#FFFFFF",
              borderRadius: 16,
              padding: 28,
              boxShadow: "0 8px 32px rgba(0,0,0,0.12)",
            }}
          >
            <div style={{ marginBottom: 20 }}>
              <h2 style={{ fontSize: 16, fontWeight: 700, color: "#111827" }}>Retirar fondos</h2>
              <p style={{ fontSize: 13, color: "#94A3B8", marginTop: 4 }}>
                El dinero llegará a tu cuenta en 2–5 días hábiles.
              </p>
            </div>

            <div
              style={{
                background: "#F8FAFC",
                borderRadius: 12,
                padding: "14px 16px",
                marginBottom: 20,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <span>
                <span style={{ display: "block", fontSize: 12, color: "#94A3B8" }}>Balance disponible</span>
                <span style={{ display: "block", fontSize: 20, fontWeight: 700, color: "#111827" }}>$3.840</span>
              </span>
              <button
                type="button"
                className="fa-link"
                onClick={() => setAmount(String(BALANCE))}
                style={{ fontSize: 12, color: "#94A3B8", cursor: "pointer" }}
              >
                Retirar todo
              </button>
            </div>

            <div style={{ marginBottom: 16 }}>
              <label
                htmlFor="fa-amount"
                style={{ display: "block", fontSize: 12, fontWeight: 500, color: "#374151", marginBottom: 6 }}
              >
                ¿Cuánto querés retirar?
              </label>
              <div style={{ position: "relative" }}>
                <span
                  style={{
                    position: "absolute",
                    left: 14,
                    top: "50%",
                    transform: "translateY(-50%)",
                    fontSize: 14,
                    color: "#94A3B8",
                  }}
                >
                  $
                </span>
                <input
                  id="fa-amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0"
                  inputMode="decimal"
                  style={{
                    width: "100%",
                    height: 48,
                    border: `1px solid ${overBalance ? "#EF4444" : "#E2E8F0"}`,
                    borderRadius: 10,
                    padding: "0 14px 0 28px",
                    fontSize: 20,
                    fontWeight: 600,
                    color: "#111827",
                    outline: "none",
                  }}
                />
              </div>
              {overBalance ? (
                <p style={{ fontSize: 11, color: "#EF4444", marginTop: 6 }}>
                  El monto supera tu balance disponible.
                </p>
              ) : null}
            </div>

            <div style={{ marginBottom: 20 }}>
              <span style={{ display: "block", fontSize: 12, fontWeight: 500, color: "#374151", marginBottom: 8 }}>
                Destino
              </span>
              <div
                style={{
                  background: "#FFFFFF",
                  border: "1px solid #E2E8F0",
                  borderRadius: 10,
                  padding: "12px 14px",
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                }}
              >
                <Building2 size={18} color="#94A3B8" />
                <span style={{ flex: 1, fontSize: 13, color: "#374151" }}>Banco Galicia ···· 4242</span>
                <button type="button" className="fa-link" style={{ fontSize: 12, color: "#94A3B8", cursor: "pointer" }}>
                  Cambiar
                </button>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 24 }}>
              <Clock size={14} color="#CBD5E1" />
              <span style={{ fontSize: 12, color: "#94A3B8" }}>
                Procesamiento: 2–5 días hábiles. Sin comisiones.
              </span>
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button
                type="button"
                onClick={() => setWithdrawOpen(false)}
                style={{
                  flex: 1,
                  border: "1px solid #E2E8F0",
                  borderRadius: 10,
                  padding: "10px 20px",
                  fontSize: 13,
                  color: "#374151",
                  background: "#FFFFFF",
                  cursor: "pointer",
                }}
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={!canConfirm}
                onClick={confirmWithdraw}
                style={{
                  flex: 1,
                  background: "#111827",
                  color: "#FFFFFF",
                  borderRadius: 10,
                  padding: "10px 20px",
                  fontSize: 13,
                  fontWeight: 500,
                  opacity: canConfirm ? 1 : 0.4,
                  cursor: canConfirm ? "pointer" : "not-allowed",
                }}
              >
                Confirmar retiro
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
