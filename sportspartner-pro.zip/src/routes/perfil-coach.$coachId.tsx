import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle, ChevronLeft, Share2, MapPin, MessageCircle, Star } from "lucide-react";
import { toast } from "sonner";
import { ensureChat } from "@/lib/athlete-chats";
import { PhoneFrame } from "@/components/togo/Entrenamiento";

type Mod = "Online" | "Presencial" | "Ambas";
type Level = "Principiante" | "Intermedio" | "Avanzado";
type Coach = {
  name: string; spec: string; rating: number; reviews: number; mod: Mod; modText: string;
  athletes: number; years: number; chips: string[]; bio: string; days: boolean[];
  programs: { name: string; dur: string; level: Level; price: string }[];
};

const BASE_PROGRAMS: Coach["programs"] = [
  { name: "Fuerza base", dur: "8 semanas · 3 días/sem", level: "Principiante", price: "$6.500 / mes" },
  { name: "Hipertrofia total", dur: "12 semanas · 4 días/sem", level: "Intermedio", price: "$8.500 / mes" },
  { name: "Potencia atlética", dur: "10 semanas · 5 días/sem", level: "Avanzado", price: "$11.000 / mes" },
  { name: "Movilidad express", dur: "4 semanas · 2 días/sem", level: "Principiante", price: "Gratis" },
];

const COACHES: Record<string, Coach> = {
  "pablo-rodriguez": { name: "Pablo Rodríguez", spec: "Fuerza y potencia · Running", rating: 4.9, reviews: 34, mod: "Online", modText: "Online vía videollamada", athletes: 47, years: 3, chips: ["Fuerza", "Hipertrofia", "Running", "Pérdida de peso"], bio: "Soy entrenador de fuerza y acondicionamiento con foco en atletas amateurs que quieren rendir más sin lesionarse. Trabajo con planificación por bloques, seguimiento semanal y ajustes según tu feedback. Combino fuerza con running para que ganes potencia y resistencia al mismo tiempo. Me formé en el ENEF y certifiqué en NSCA. Mis atletas entrenan desde casa, en el gimnasio o en la pista, siempre con un plan claro y medible.", days: [true, true, false, true, true, false, false], programs: BASE_PROGRAMS },
  "laura-mendez": { name: "Laura Méndez", spec: "Running y resistencia", rating: 4.8, reviews: 52, mod: "Ambas", modText: "Online y presencial", athletes: 52, years: 6, chips: ["Running", "Maratón", "Nutrición"], bio: "Corredora y coach de running. Te acompaño desde tus primeros 5K hasta la maratón, con planes adaptados a tu ritmo y tu agenda.", days: [true, false, true, false, true, true, false], programs: BASE_PROGRAMS.slice(0, 3) },
  "diego-romero": { name: "Diego Romero", spec: "Natación y triatlón", rating: 4.7, reviews: 21, mod: "Presencial", modText: "Presencial — Palermo, CABA", athletes: 21, years: 8, chips: ["Natación", "Triatlón", "Running"], bio: "Entrenador de natación y triatlón. Técnica, volumen y planificación para que llegues a tu competencia en tu mejor forma.", days: [false, true, true, true, false, true, false], programs: BASE_PROGRAMS.slice(1) },
  "camila-sosa": { name: "Camila Sosa", spec: "Yoga y movilidad", rating: 4.9, reviews: 40, mod: "Online", modText: "Online vía videollamada", athletes: 40, years: 5, chips: ["Yoga", "Movilidad", "Respiración"], bio: "Profesora de yoga y movilidad. Clases para mejorar tu flexibilidad, postura y recuperación entre entrenamientos.", days: [true, true, true, true, true, false, false], programs: BASE_PROGRAMS.slice(0, 2) },
};

const REVIEWS = [
  { name: "Sofía L.", stars: 5, date: "hace 2 sem.", text: "Excelente coach. Mejoré mis marcas en sentadilla y peso muerto en solo dos meses, y siempre responde rápido." },
  { name: "Martín G.", stars: 4, date: "hace 1 mes", text: "Muy buena planificación y seguimiento. Me ayudó a volver a correr sin dolores después de una lesión." },
];

const MOD_COLOR: Record<Mod, string> = { Online: "#22C55E", Presencial: "#3B82F6", Ambas: "#7C3AED" };
const LEVEL: Record<Level, [string, string]> = { Principiante: ["#F0FDF4", "#16A34A"], Intermedio: ["#FFFBEB", "#D97706"], Avanzado: ["#FEF2F2", "#EF4444"] };
const DAYS = ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"];

export const Route = createFileRoute("/perfil-coach/$coachId")({
  head: () => ({
    meta: [
      { title: "Perfil de coach · TOGO" },
      { name: "description", content: "Conocé al coach, sus programas, disponibilidad y reseñas en TOGO." },
      { property: "og:title", content: "Perfil de coach · TOGO" },
      { property: "og:description", content: "Conocé al coach, sus programas, disponibilidad y reseñas en TOGO." },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CoachProfile,
});

const card = { background: "#FFF", padding: 16, marginBottom: 8 } as const;
const h = { fontSize: 13, fontWeight: 700, color: "#111827" } as const;

function Stars({ n, size }: { n: number; size: number }) {
  return <span className="flex" style={{ gap: 2 }}>{[1, 2, 3, 4, 5].map((i) => <Star key={i} size={size} fill={i <= Math.round(n) ? "#D97706" : "#E2E8F0"} color={i <= Math.round(n) ? "#D97706" : "#E2E8F0"} />)}</span>;
}

function CoachProfile() {
  const { coachId } = Route.useParams();
  const c: Coach = COACHES[coachId] ?? COACHES["pablo-rodriguez"]!;
  const [more, setMore] = useState(false);
  const [sheet, setSheet] = useState(false);
  const [sel, setSel] = useState(0);
  const [msg, setMsg] = useState("");
  const [done, setDone] = useState(false);
  const initials = c.name.split(" ").map((p) => p[0]).join("");
  const long = c.bio.length > 200;

  const share = () => {
    navigator.clipboard?.writeText(window.location.href).catch(() => {});
    toast.success("Link del perfil copiado");
  };

  if (done) return (
    <PhoneFrame>
      <div className="flex flex-1 flex-col overflow-y-auto" style={{ background: "#FFF" }}>
        <div className="flex flex-col items-center" style={{ padding: "60px 32px 0" }}>
          <span className="flex items-center justify-center" style={{ width: 80, height: 80, borderRadius: "50%", background: "#F0FDF4", marginBottom: 24 }}><CheckCircle size={36} color="#22C55E" /></span>
          <div style={{ fontSize: 24, fontWeight: 800, color: "#111827", textAlign: "center", marginBottom: 8 }}>¡Solicitud enviada!</div>
          <div style={{ fontSize: 14, color: "#94A3B8", textAlign: "center", lineHeight: 1.6, maxWidth: 280 }}>Le avisamos a {c.name}. Te va a confirmar en las próximas 24–48 hs.</div>
        </div>
        <div className="flex" style={{ background: "#FFF", borderRadius: 14, border: "1px solid #E2E8F0", padding: 16, gap: 12, margin: "32px 20px" }}>
          <span className="flex items-center justify-center" style={{ width: 48, height: 48, borderRadius: 12, background: "#F1F5F9", fontSize: 16, fontWeight: 700, color: "#94A3B8", flexShrink: 0 }}>{initials}</span>
          <div className="flex flex-col">
            <span style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>{c.name}</span>
            <span style={{ fontSize: 12, color: "#94A3B8" }}>{c.spec}</span>
            <span style={{ fontSize: 11, color: "#374151", marginTop: 4 }}>{c.programs[sel]?.name}</span>
          </div>
        </div>
        <div className="flex flex-col" style={{ gap: 10, padding: "0 20px" }}>
          <Link to="/chat/$coachId" params={{ coachId }} search={{ nombre: c.name }} onClick={() => ensureChat(coachId, c.name)} className="flex items-center justify-center" style={{ background: "#111827", color: "#FFF", borderRadius: 12, height: 48, fontSize: 14, fontWeight: 600 }}>Ir a Mensajes</Link>
          <Link to="/explorar" className="flex items-center justify-center" style={{ border: "1px solid #E2E8F0", borderRadius: 12, height: 48, fontSize: 14, color: "#374151" }}>Volver al Marketplace</Link>
        </div>
      </div>
    </PhoneFrame>
  );

  return (
    <PhoneFrame>
      <div className="flex flex-1 flex-col overflow-y-auto" style={{ paddingBottom: 80 }}>
        <div className="flex items-center" style={{ position: "sticky", top: 0, background: "#FFF", borderBottom: "1px solid #E2E8F0", padding: "12px 16px", zIndex: 10 }}>
          <Link to="/explorar" aria-label="Volver"><ChevronLeft size={22} color="#111827" /></Link>
          <span style={{ flex: 1, textAlign: "center", fontSize: 16, fontWeight: 700, color: "#111827" }}>Perfil</span>
          <button onClick={share} aria-label="Compartir perfil"><Share2 size={18} color="#CBD5E1" /></button>
        </div>

        <div style={{ background: "#FFF", padding: "24px 16px 20px", marginBottom: 8 }}>
          <div className="flex items-start" style={{ gap: 14, marginBottom: 16 }}>
            <span className="flex items-center justify-center" style={{ width: 72, height: 72, borderRadius: 16, background: "#F1F5F9", fontSize: 24, fontWeight: 700, color: "#94A3B8", flexShrink: 0 }}>{initials}</span>
            <div className="flex flex-col" style={{ flex: 1, gap: 6 }}>
              <div style={{ fontSize: 20, fontWeight: 800, color: "#111827" }}>{c.name}</div>
              <div style={{ fontSize: 13, color: "#94A3B8" }}>{c.spec}</div>
              <div className="flex items-center" style={{ gap: 6 }}>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#D97706" }}>★ {c.rating}</span>
                <span style={{ fontSize: 12, color: "#94A3B8" }}>· {c.reviews} reseñas</span>
                <span style={{ fontSize: 12, color: MOD_COLOR[c.mod] }}>· {c.mod}</span>
              </div>
            </div>
          </div>
          <div className="flex" style={{ borderTop: "1px solid #F1F5F9", borderBottom: "1px solid #F1F5F9", marginBottom: 16 }}>
            {[[c.athletes, "atletas"], [c.years, "años exp."], [c.programs.length, "programas"]].map(([v, l], i, a) => (
              <div key={l} style={{ flex: 1, padding: "12px 0", textAlign: "center", borderRight: i < a.length - 1 ? "1px solid #F1F5F9" : 0 }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#111827" }}>{v}</div>
                <div style={{ fontSize: 9, color: "#94A3B8", marginTop: 3 }}>{l}</div>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap" style={{ gap: 6 }}>
            {c.chips.map((t) => <span key={t} style={{ border: "1px solid #E2E8F0", borderRadius: 20, padding: "5px 12px", fontSize: 11, color: "#374151" }}>{t}</span>)}
          </div>
        </div>

        <div style={card}>
          <div style={{ ...h, marginBottom: 8 }}>Sobre mí</div>
          <p style={{ fontSize: 13, color: "#374151", lineHeight: 1.6, ...(long && !more ? { display: "-webkit-box", WebkitLineClamp: 4, WebkitBoxOrient: "vertical", overflow: "hidden" } : {}) }}>{c.bio}</p>
          {long && <button onClick={() => setMore(!more)} style={{ fontSize: 12, color: "#3B82F6", marginTop: 4 }}>{more ? "Ver menos" : "Ver más"}</button>}
        </div>

        <div style={card}>
          <div style={{ ...h, marginBottom: 12 }}>Programas</div>
          <div className="flex" style={{ gap: 10, overflowX: "auto", paddingBottom: 4 }}>
            {c.programs.map((p, i) => (
              <div key={p.name} className="flex flex-col" style={{ background: "#FFF", borderRadius: 12, border: "1px solid #E2E8F0", padding: 14, width: 200, flexShrink: 0, gap: 6 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#111827" }}>{p.name}</div>
                <div style={{ fontSize: 11, color: "#94A3B8" }}>{p.dur}</div>
                <span style={{ alignSelf: "flex-start", fontSize: 10, borderRadius: 20, padding: "2px 8px", background: LEVEL[p.level][0], color: LEVEL[p.level][1] }}>{p.level}</span>
                <div style={{ fontSize: 14, fontWeight: 800, color: "#111827", marginTop: 4 }}>{p.price}</div>
                <button onClick={() => { setSel(i); setSheet(true); }} style={{ fontSize: 11, color: "#3B82F6", textAlign: "left" }}>Ver programa</button>
              </div>
            ))}
          </div>
        </div>

        <div style={card}>
          <div style={{ ...h, marginBottom: 12 }}>Disponibilidad</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 6 }}>
            {DAYS.map((d, i) => (
              <div key={d} className="flex flex-col items-center" style={{ gap: 4 }}>
                <span style={{ fontSize: 9, color: "#94A3B8" }}>{d}</span>
                <span className="flex items-center justify-center" style={{ width: 32, height: 32, borderRadius: 16, fontSize: 11, fontWeight: 600, background: c.days[i] ? "#111827" : "#F1F5F9", color: c.days[i] ? "#FFF" : "#CBD5E1" }}>{d[0]}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center" style={{ gap: 8, marginTop: 12 }}>
            <MapPin size={13} color="#94A3B8" /><span style={{ fontSize: 12, color: "#374151" }}>{c.modText}</span>
          </div>
        </div>

        <div style={card}>
          <div className="flex items-center" style={{ marginBottom: 12 }}>
            <span style={{ ...h, flex: 1 }}>Reseñas</span>
            <button style={{ fontSize: 11, color: "#3B82F6" }}>Ver todas</button>
          </div>
          <div className="flex items-center" style={{ gap: 16, marginBottom: 14 }}>
            <span style={{ fontSize: 32, fontWeight: 800, color: "#111827" }}>{c.rating}</span>
            <Stars n={c.rating} size={16} />
            <span style={{ fontSize: 11, color: "#94A3B8" }}>{c.reviews} reseñas</span>
          </div>
          <div className="flex flex-col" style={{ gap: 10 }}>
            {REVIEWS.map((r) => (
              <div key={r.name} style={{ background: "#F8FAFC", borderRadius: 12, padding: 12 }}>
                <div className="flex items-center" style={{ gap: 8 }}>
                  <span className="flex items-center justify-center" style={{ width: 28, height: 28, borderRadius: 14, background: "#E2E8F0", fontSize: 10, fontWeight: 600, color: "#64748B" }}>{r.name[0]}</span>
                  <span style={{ fontSize: 12, fontWeight: 600, color: "#111827" }}>{r.name}</span>
                  <Stars n={r.stars} size={12} />
                  <span style={{ fontSize: 10, color: "#94A3B8", marginLeft: "auto" }}>{r.date}</span>
                </div>
                <p style={{ fontSize: 12, color: "#374151", lineHeight: 1.5, marginTop: 6 }}>{r.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex" style={{ position: "absolute", bottom: 0, left: 0, right: 0, background: "#FFF", borderTop: "1px solid #E2E8F0", padding: "12px 16px calc(12px + env(safe-area-inset-bottom))", gap: 10, zIndex: 20 }}>
        <Link to="/chat/$coachId" params={{ coachId }} search={{ nombre: c.name }} onClick={() => ensureChat(coachId, c.name)} className="flex items-center justify-center" style={{ flex: 1, border: "1px solid #E2E8F0", borderRadius: 12, height: 48, fontSize: 14, fontWeight: 600, color: "#374151", gap: 6 }}>
          <MessageCircle size={16} color="#94A3B8" /> Enviar mensaje
        </Link>
        <button onClick={() => setSheet(true)} style={{ flex: 1, background: "#111827", color: "#FFF", borderRadius: 12, height: 48, fontSize: 14, fontWeight: 700 }}>Contratar</button>
      </div>

      <div onClick={() => setSheet(false)} style={{ position: "absolute", inset: 0, background: "rgba(15,23,42,0.4)", opacity: sheet ? 1 : 0, pointerEvents: sheet ? "auto" : "none", transition: "opacity .25s", zIndex: 30 }} />
      <div className="flex flex-col" style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: "70%", background: "#FFF", borderRadius: "20px 20px 0 0", transform: sheet ? "translateY(0)" : "translateY(100%)", transition: "transform .3s ease", zIndex: 40 }}>
        <div style={{ width: 36, height: 4, background: "#E2E8F0", borderRadius: 2, margin: "12px auto" }} />
        <div style={{ padding: "16px 20px", borderBottom: "1px solid #F1F5F9", fontSize: 16, fontWeight: 700, color: "#111827" }}>Contratar a {c.name}</div>
        <div className="flex flex-col" style={{ padding: 20, gap: 16, flex: 1, overflowY: "auto" }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#374151" }}>Seleccioná un programa</div>
          <div className="flex flex-col" style={{ gap: 8 }}>
            {c.programs.map((p, i) => (
              <button key={p.name} onClick={() => setSel(i)} className="flex items-center" style={{ border: `1px solid ${sel === i ? "#111827" : "#E2E8F0"}`, borderRadius: 12, padding: 14, gap: 12, textAlign: "left" }}>
                <span className="flex items-center justify-center" style={{ width: 18, height: 18, borderRadius: 9, border: `1.5px solid ${sel === i ? "#111827" : "#CBD5E1"}`, flexShrink: 0 }}>
                  {sel === i && <span style={{ width: 8, height: 8, borderRadius: 4, background: "#111827" }} />}
                </span>
                <span style={{ flex: 1 }}>
                  <span style={{ display: "block", fontSize: 13, fontWeight: 600, color: "#111827" }}>{p.name}</span>
                  <span style={{ display: "block", fontSize: 11, color: "#94A3B8" }}>{p.dur}</span>
                </span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#111827" }}>{p.price}</span>
              </button>
            ))}
          </div>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#374151" }}>¿Tenés algún objetivo o consulta?</div>
          <textarea value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Contale brevemente qué estás buscando…" style={{ border: "1px solid #E2E8F0", borderRadius: 10, padding: "10px 12px", fontSize: 13, color: "#374151", minHeight: 80, outline: "none", resize: "none" }} />
        </div>
        <div style={{ padding: "16px 20px", borderTop: "1px solid #F1F5F9" }}>
          <button onClick={() => { setSheet(false); setMsg(""); setDone(true); }} style={{ width: "100%", background: "#111827", color: "#FFF", borderRadius: 12, height: 50, fontSize: 15, fontWeight: 700 }}>Enviar solicitud</button>
          <div style={{ fontSize: 11, color: "#94A3B8", textAlign: "center", marginTop: 8 }}>El coach recibirá tu solicitud y te confirmará en 24–48 hs.</div>
        </div>
      </div>
    </PhoneFrame>
  );
}
