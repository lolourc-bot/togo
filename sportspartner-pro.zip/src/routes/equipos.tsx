import { toast as sonnerToast } from "sonner";
import { NewCoachGate } from "@/components/togo/EmptyStates";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Info,
  Clock,
  Eye,
  MessageCircle,
  Send,
  Pencil,
  Plus,
  Search,
  Settings2,
  Trash2,
  Trophy,
  UserPlus,
  X,
} from "lucide-react";
import { Sidebar } from "@/components/togo/Sidebar";
import { CalendarTopBar, DenseSessionBlock, denseCell, type DenseRow } from "@/components/togo/DenseSession";
import { SelectionToolbar, Selectable, dayDiff, mapOps, selId, useDragSelect } from "@/components/togo/CalendarSelection";
import { LAB_SESSIONS } from "@/components/togo/LabSessions";
import { SessionCard, newEx, type CalEx, type DaySession as FullSession } from "@/components/togo/AthleteSessionCard";

type EquiposSearch = { nueva?: string; fecha?: string; ejercicios?: string; equipo?: string };

export const Route = createFileRoute("/equipos")({
  validateSearch: (search: Record<string, unknown>): EquiposSearch => ({
    ...(typeof search["nueva"] === "string" ? { nueva: search["nueva"] } : {}),
    ...(typeof search["fecha"] === "string" ? { fecha: search["fecha"] } : {}),
    ...(typeof search["ejercicios"] === "string" ? { ejercicios: search["ejercicios"] } : {}),
    ...(typeof search["equipo"] === "string" ? { equipo: search["equipo"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Equipos · TOGO" },
      {
        name: "description",
        content:
          "Gestioná tus equipos: planificación compartida, miembros y logros del grupo en una sola pantalla.",
      },
      { property: "og:title", content: "Equipos · TOGO" },
      {
        property: "og:description",
        content: "Planificá una semana y publicala para todos los atletas del equipo al mismo tiempo.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <NewCoachGate section="equipos"><TeamsPage /></NewCoachGate>,
});

type Load = "ok" | "warn" | "risk" | "none" | "inactive";

type Member = { id: string; name: string; months: number; load: Load; last: string };

const LOAD_COLOR: Record<Load, { color: string; label: string }> = {
  ok: { color: "#16A34A", label: "Carga OK" },
  warn: { color: "#D97706", label: "En alerta" },
  risk: { color: "#DC2626", label: "Sobrecargado" },
  none: { color: "#CBD5E1", label: "Sin datos" },
  inactive: { color: "#CBD5E1", label: "Inactivo" },
};

const ALL_ATHLETES: Member[] = [
  { id: "santiago-perez", name: "Santiago Pérez", months: 8, load: "ok", last: "ayer" },
  { id: "valentina-garcia", name: "Valentina García", months: 5, load: "warn", last: "hace 3 días" },
  { id: "lucia-torres", name: "Lucía Torres", months: 3, load: "ok", last: "hoy" },
  { id: "matias-lopez", name: "Matías López", months: 12, load: "none", last: "hace 7 días" },
  { id: "camila-sanchez", name: "Camila Sánchez", months: 6, load: "warn", last: "ayer" },
  { id: "federico-diaz", name: "Federico Díaz", months: 2, load: "ok", last: "hoy" },
  { id: "agustina-ruiz", name: "Agustina Ruiz", months: 9, load: "risk", last: "hace 2 días" },
  { id: "tomas-fernandez", name: "Tomás Fernández", months: 4, load: "none", last: "hace 7 días" },
  { id: "romina-castro", name: "Romina Castro", months: 7, load: "ok", last: "ayer" },
  { id: "nicolas-herrera", name: "Nicolás Herrera", months: 1, load: "ok", last: "hace 3 días" },
  { id: "florencia-medina", name: "Florencia Medina", months: 10, load: "warn", last: "hoy" },
  { id: "ezequiel-mora", name: "Ezequiel Mora", months: 3, load: "inactive", last: "hace 14 días" },
];

type Features = { planning: boolean; chat: boolean; achievements: boolean };

type Team = {
  id: string;
  name: string;
  description: string;
  members: string[];
  features: Features;
};

const INITIAL_TEAMS: Team[] = [
  {
    id: "equipo-a",
    name: "Equipo A",
    description: "",
    members: ["santiago-perez", "valentina-garcia", "lucia-torres", "matias-lopez", "camila-sanchez"],
    features: { planning: true, chat: true, achievements: true },
  },
  {
    id: "equipo-manana",
    name: "Equipo Mañana",
    description: "Entrenan de 7 a 9 AM.",
    members: ["federico-diaz", "agustina-ruiz", "tomas-fernandez", "romina-castro"],
    features: { planning: true, chat: true, achievements: true },
  },
  {
    id: "equipo-avanzado",
    name: "Equipo Avanzado",
    description: "",
    members: ["nicolas-herrera", "florencia-medina", "ezequiel-mora"],
    features: { planning: true, chat: true, achievements: true },
  },
];

type DaySession = { id: string; name: string; exercises: number; published: boolean; detail?: FullSession };

function toFull(s: DaySession): FullSession {
  if (s.detail) return { ...s.detail, name: s.name, status: s.detail.status === "done" ? "done" : s.published ? "published" : "draft" };
  const lab = LAB_SESSIONS.find((l) => l.name === s.name);
  const items: CalEx[] = (lab?.exercises ?? []).map((e, i, arr) => ({ ...newEx(e.name, String(e.sets), String(e.reps)), weight: e.weight ? String(e.weight) : "", chain: e.group === "B" && i > 0 && arr[i - 1]?.group === "B" }));
  return { id: s.id, name: s.name, status: s.published ? "published" : "draft", minutes: 50, items, circuits: [] };
}

function teamRows(s: DaySession): DenseRow[] {
  if (s.detail) return s.detail.items.map((e, i) => ({ label: String.fromCharCode(65 + i), kind: "single" as const, name: e.name, detail: `${e.sets} × ${e.reps}${e.weight ? ` @ ${e.weight} kg` : ""}` }));
  const lab = LAB_SESSIONS.find((l) => l.name === s.name);
  if (!lab) return [];
  let letter = 0;
  const out: DenseRow[] = [];
  const next = () => String.fromCharCode(65 + letter++);
  lab.exercises.filter((e) => e.group === "A").forEach((e) =>
    out.push({ label: next(), kind: "single", name: e.name, detail: `${e.sets} × ${e.reps}${e.weight ? ` @ ${e.weight} kg` : ""}` }),
  );
  const sup = lab.exercises.filter((e) => e.group === "B");
  if (sup.length) {
    const L = next();
    sup.forEach((e, i) =>
      out.push({ label: sup.length > 1 ? `${L}${i + 1}` : L, kind: sup.length > 1 ? "superset" : "single", ...(sup.length > 1 ? { group: L } : {}), name: e.name, detail: `${e.sets} × ${e.reps}${e.weight ? ` @ ${e.weight} kg` : ""}` }),
    );
  }
  lab.circuits.forEach((c, ci) =>
    c.exercises.forEach((e, ei) => out.push({ label: `C${ei + 1}`, kind: "circuit", group: `C${ci}`, name: e.name, detail: `${e.reps || "—"}${ei === 0 ? ` · ${c.type}` : ""}` })),
  );
  return out;
}

function dateKey(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function dayInThisMonth(day: number) {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(day);
  return dateKey(d);
}

const INITIAL_SESSIONS: Record<string, DaySession[]> = {
  [`equipo-a|${dayInThisMonth(3)}`]: [{ id: "s-a1", name: "Full body A", exercises: 6, published: true }],
  [`equipo-a|${dayInThisMonth(5)}`]: [{ id: "s-a2", name: "HIIT cardio 20 min", exercises: 4, published: true }],
  [`equipo-a|${dayInThisMonth(8)}`]: [
    { id: "s-a3", name: "Empuje horizontal", exercises: 3, published: false },
    { id: "s-a4", name: "Movilidad de cadera", exercises: 3, published: false },
    { id: "s-a5", name: "Core y abdominales", exercises: 4, published: false },
  ],
  [`equipo-manana|${dayInThisMonth(4)}`]: [
    { id: "s-m1", name: "Movilidad de cadera", exercises: 3, published: false },
  ],
  [`equipo-avanzado|${dayInThisMonth(6)}`]: [
    { id: "s-v1", name: "Full body A", exercises: 6, published: true },
  ],
};

const LOGROS = [
  { id: "l1", name: "Santiago Pérez", text: "alcanzó 8 semanas consecutivas entrenando", when: "Hace 1 hora", fire: 4 },
  { id: "l2", name: "Valentina García", text: "completó su primera sesión de Cardio y movilidad", when: "Hace 3 horas", fire: 2 },
  { id: "l3", name: "Lucía Torres", text: "superó su récord personal en Sentadilla trasera", when: "Ayer", fire: 7 },
];

const DAYS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];
const MONTH_NAMES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function AvatarStack({ names, size = 22 }: { names: string[]; size?: number }) {
  const shown = names.slice(0, 3);
  const extra = names.length - shown.length;
  return (
    <div className="flex flex-shrink-0 items-center">
      {shown.map((n, i) => (
        <div
          key={n}
          className="flex items-center justify-center rounded-full"
          style={{
            width: size,
            height: size,
            marginLeft: i === 0 ? 0 : -6,
            backgroundColor: "#F1F5F9",
            color: "#94A3B8",
            border: "2px solid #FFFFFF",
            fontSize: size >= 32 ? 11 : 9,
            fontWeight: 600,
          }}
        >
          {initials(n)}
        </div>
      ))}
      {extra > 0 ? (
        <span style={{ fontSize: 11, color: "#94A3B8", marginLeft: 6 }}>+{extra}</span>
      ) : null}
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      aria-label={on ? "Desactivar" : "Activar"}
      className="cursor-pointer"
      style={{
        width: 36,
        height: 20,
        borderRadius: 999,
        border: "none",
        backgroundColor: on ? "#111827" : "#E2E8F0",
        position: "relative",
        flexShrink: 0,
      }}
    >
      <span
        style={{
          position: "absolute",
          top: 2,
          left: on ? 18 : 2,
          width: 16,
          height: 16,
          borderRadius: 999,
          backgroundColor: "#FFFFFF",
          transition: "left 150ms",
        }}
      />
    </button>
  );
}

const outlineBtn = {
  border: "1px solid #E2E8F0",
  borderRadius: 9,
  height: 36,
  padding: "0 14px",
  fontSize: 13,
  color: "#374151",
  backgroundColor: "#FFFFFF",
  gap: 6,
  cursor: "pointer",
} as const;

function TeamsPage() {
  const navigate = useNavigate();
  const [teams, setTeams] = useState<Team[]>(INITIAL_TEAMS);
  const [activeId, setActiveId] = useState<string>(INITIAL_TEAMS[0]!.id);
  const [tab, setTab] = useState<"Calendario" | "Miembros" | "Logros">("Calendario");
  const [monthOffset, setMonthOffset] = useState(0);
  const [sessions, setSessions] = useState<Record<string, DaySession[]>>(INITIAL_SESSIONS);
  const sel = useDragSelect();
  const [publishedOnly, setPublishedOnly] = useState(false);
  const [copied, setCopied] = useState<{ key: string; s: DaySession }[]>([]);
  const ops = mapOps(setSessions, (s: DaySession) => ({ ...s, id: `c${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, published: false }));
  const selItems = ops.collect(sessions, sel.selected);
  const pasteHere = (key: string) => {
    if (!copied.length) return;
    const first = copied.reduce((m, c) => (dayDiff(c.key, m) < 0 ? c.key : m), copied[0]!.key);
    ops.place(copied.map((c) => ({ ...c, key: `${key.slice(0, -10)}${c.key.slice(-10)}` })), dayDiff(key, first));
    setCopied([]);
  };
  const [picker, setPicker] = useState<{ key: string } | null>(null);
  const [pickerQuery, setPickerQuery] = useState("");
  const [confirmPublish, setConfirmPublish] = useState(false);
  const [switcherOpen, setSwitcherOpen] = useState(false);
  useEffect(() => {
    if (!switcherOpen) return;
    const close = () => setSwitcherOpen(false);
    window.addEventListener("click", close);
    return () => window.removeEventListener("click", close);
  }, [switcherOpen]);
  const [modal, setModal] = useState<{ mode: "create" | "edit"; team: Team | null } | null>(null);
  const [editingName, setEditingName] = useState(false);
  const [addMember, setAddMember] = useState(false);
  const [fires, setFires] = useState<Record<string, number>>({});
  const [toast, setToast] = useState<string | null>(null);
  const [expandedDay, setExpandedDay] = useState<string | null>(null);
  const [dragX, setDragX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const dragStart = useRef<number | null>(null);

  const incoming = Route.useSearch();

  useEffect(() => {
    if (!incoming.nueva || !incoming.fecha) return;
    const teamId = incoming.equipo || activeId;
    const key = `${teamId}|${incoming.fecha}`;
    const count = Number(incoming.ejercicios) || 0;
    setActiveId(teamId);
    setSessions((prev) => ({
      ...prev,
      [key]: [
        ...(prev[key] ?? []),
        { id: `${key}-${Date.now()}`, name: incoming.nueva!, exercises: count, published: false },
      ],
    }));
    flash("Sesión guardada como borrador");
    navigate({ to: "/equipos", search: {}, replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [incoming.nueva, incoming.fecha]);

  const team = teams.find((t) => t.id === activeId) ?? teams[0]!;
  const memberList = team.members
    .map((id) => ALL_ATHLETES.find((a) => a.id === id))
    .filter((a): a is Member => Boolean(a));

  const viewMonth = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(1);
    d.setMonth(d.getMonth() + monthOffset);
    return d;
  }, [monthOffset]);

  const monthCells = useMemo(() => {
    const first = new Date(viewMonth);
    const lead = (first.getDay() + 6) % 7;
    const start = new Date(first);
    start.setDate(start.getDate() - lead);
    const daysInMonth = new Date(viewMonth.getFullYear(), viewMonth.getMonth() + 1, 0).getDate();
    const total = Math.ceil((lead + daysInMonth) / 7) * 7;
    return Array.from({ length: total }, (_, i) => {
      const d = new Date(start);
      d.setDate(d.getDate() + i);
      return d;
    });
  }, [viewMonth]);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const monthLabel = `${MONTH_NAMES[viewMonth.getMonth()]} ${viewMonth.getFullYear()}`;

  const cellKey = (d: Date) =>
    `${team.id}|${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

  const monthSessions = monthCells
    .filter((d) => d.getMonth() === viewMonth.getMonth())
    .flatMap((d) => sessions[cellKey(d)] ?? []);
  const draftCount = monthSessions.filter((s) => !s.published).length;

  const flash = (msg: string) => {
    sonnerToast.success(msg);
  };

  const goMonth = (dir: number) => {
    setMonthOffset((m) => m + dir);
    setPicker(null);
    setExpandedDay(null);
  };

  const onDragStart = (e: React.PointerEvent) => {
    if (e.pointerType === "mouse") return;
    if ((e.target as HTMLElement).closest("button, input")) return;
    dragStart.current = e.clientX;
    setDragging(true);
  };
  const onDragMove = (e: React.PointerEvent) => {
    if (dragStart.current === null) return;
    setDragX(e.clientX - dragStart.current);
  };
  const onDragEnd = () => {
    if (dragStart.current === null) return;
    const dx = dragX;
    dragStart.current = null;
    setDragging(false);
    setDragX(0);
    if (dx < -60) goMonth(1);
    else if (dx > 60) goMonth(-1);
  };

  const addSession = (key: string, name: string, exercises: number) => {
    setSessions((prev) => ({
      ...prev,
      [key]: [
        ...(prev[key] ?? []),
        { id: `${key}-${Date.now()}`, name, exercises, published: false },
      ],
    }));
    setPicker(null);
    setPickerQuery("");
  };

  const removeSession = (key: string, id: string) => {
    setSessions((prev) => ({ ...prev, [key]: (prev[key] ?? []).filter((s) => s.id !== id) }));
  };

  const publishWeek = () => {
    setSessions((prev) => {
      const next = { ...prev };
      monthCells.forEach((d) => {
        const key = cellKey(d);
        if (next[key]) next[key] = next[key]!.map((s) => ({ ...s, published: true }));
      });
      return next;
    });
    setConfirmPublish(false);
    flash(`Mes publicado para ${memberList.length} atletas`);
  };

  void editingName; void setEditingName;
  const featureLine = [
    `${memberList.length} atletas`,
    team.features.planning ? "Planificación compartida" : null,
    team.features.chat ? "Chat grupal" : null,
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <div className="grid min-h-screen grid-cols-[240px_1fr]" style={{ backgroundColor: "#F8FAFC" }}>
      <Sidebar active="Equipos" />

      <main className="flex" style={{ height: "100vh", overflow: "hidden" }}>
        <div style={{ flex: 1, overflowY: "auto" }}>
          {/* TEAM SELECTOR ROW */}
          <div className="relative flex items-center" style={{ gap: 12, padding: "24px 32px 0", marginBottom: 20 }}>
            <AvatarStack names={memberList.map((m) => m.name)} />
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); setSwitcherOpen((v) => !v); }}
              className="flex cursor-pointer items-center transition-colors hover:border-[#CBD5E1]"
              style={{ gap: 8, padding: "8px 14px", border: "1px solid #E2E8F0", borderRadius: 10, backgroundColor: "#FFFFFF" }}
            >
              <span style={{ fontSize: 16, fontWeight: 700, color: "#111827" }}>{team.name}</span>
              <span style={{ fontSize: 12, color: "#94A3B8" }}>{memberList.length} atletas</span>
              <ChevronDown size={14} color="#CBD5E1" />
            </button>
            {switcherOpen ? (
              <div
                onClick={(e) => e.stopPropagation()}
                style={{ position: "absolute", top: "calc(100% + 6px)", left: 32, backgroundColor: "#FFFFFF", borderRadius: 12, border: "1px solid #E2E8F0", boxShadow: "0 4px 16px rgba(0,0,0,0.10)", padding: 6, minWidth: 260, zIndex: 30 }}
              >
                <div style={{ fontSize: 10, fontWeight: 600, color: "#94A3B8", textTransform: "uppercase", padding: "6px 12px" }}>Mis equipos</div>
                {teams.map((t) => {
                  const names = t.members.map((id) => ALL_ATHLETES.find((x) => x.id === id)?.name ?? "").filter(Boolean);
                  const on = t.id === team.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => { setActiveId(t.id); setTab("Calendario"); setSwitcherOpen(false); }}
                      className="flex w-full cursor-pointer items-center hover:bg-[#F8FAFC]"
                      style={{ gap: 10, padding: "9px 12px", borderRadius: 8, border: "none", backgroundColor: on ? "#F1F5F9" : "transparent", textAlign: "left" }}
                    >
                      <AvatarStack names={names} size={20} />
                      <span style={{ fontSize: 13, fontWeight: 500, color: "#111827" }}>{t.name}</span>
                      <span style={{ fontSize: 11, color: "#94A3B8", marginLeft: "auto" }}>{t.members.length} atletas</span>
                      {on ? <Check size={13} color="#111827" /> : <span style={{ width: 13 }} />}
                    </button>
                  );
                })}
                <div style={{ height: 1, backgroundColor: "#F1F5F9", margin: "4px 0" }} />
                <button
                  type="button"
                  onClick={() => { setSwitcherOpen(false); setModal({ mode: "create", team: null }); }}
                  className="flex w-full cursor-pointer items-center hover:bg-[#F8FAFC]"
                  style={{ gap: 8, padding: "8px 12px", borderRadius: 8, border: "none", background: "none", fontSize: 12, color: "#374151" }}
                >
                  <Plus size={12} color="#94A3B8" /> Nuevo equipo
                </button>
              </div>
            ) : null}
            <div className="flex items-center" style={{ gap: 8, marginLeft: "auto" }}>
              <button type="button" onClick={() => setModal({ mode: "edit", team })} className="inline-flex items-center" style={outlineBtn}>
                <Settings2 size={13} color="#94A3B8" /> Gestionar equipo
              </button>
              <button type="button" onClick={() => navigate({ to: "/mensajes", search: { atleta: team.name } })} className="inline-flex items-center" style={outlineBtn}>
                <MessageCircle size={13} color="#94A3B8" /> Chat grupal
              </button>
              <button type="button" onClick={() => setConfirmPublish(true)} style={{ backgroundColor: "#111827", color: "#FFFFFF", borderRadius: 9, height: 36, padding: "0 16px", fontSize: 13, fontWeight: 600, border: "none", cursor: "pointer" }}>
                Publicar mes
              </button>
            </div>
          </div>

          <div style={{ padding: "0 32px 32px" }}>
          {/* TABS */}
          <div
            className="flex"
            style={{ borderBottom: "1px solid #E2E8F0", marginBottom: 24 }}
          >
            {(["Calendario", "Miembros", "Logros"] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                className="cursor-pointer"
                style={{
                  padding: "10px 20px",
                  fontSize: 13,
                  fontWeight: 500,
                  background: "none",
                  border: "none",
                  borderBottom: `2px solid ${tab === t ? "#111827" : "transparent"}`,
                  color: tab === t ? "#111827" : "#94A3B8",
                }}
              >
                {t}
              </button>
            ))}
          </div>

          {tab === "Calendario" ? (
            <>

              {sel.overlay}
              <SelectionToolbar
                count={selItems.length}
                hasDraft={selItems.some((i) => !i.s.published)}
                hasPublished={selItems.some((i) => i.s.published)}
                onCopy={() => setCopied(selItems)}
                onDuplicate={() => ops.place(selItems, 7)}
                onPublish={() => ops.patch(sel.selected, (s) => ({ ...s, published: true }))}
                onUnpublish={() => ops.patch(sel.selected, (s) => ({ ...s, published: false }))}
                onDelete={() => { ops.remove(sel.selected); sel.clear(); }}
                onCancel={sel.clear}
              />
              {/* MONTH GRID */}
              <div
                onPointerDown={onDragStart}
                onPointerMove={onDragMove}
                onPointerUp={onDragEnd}
                onPointerCancel={onDragEnd}
                style={{
                  backgroundColor: "#FFFFFF",
                  border: "1px solid #E2E8F0",
                  borderRadius: 12,
                  overflow: "hidden",
                  touchAction: "pan-y",
                }}
              >
                <CalendarTopBar>
                  <button type="button" aria-label="Mes anterior" onClick={() => goMonth(-1)} style={{ background: "none", border: "none", cursor: "pointer", lineHeight: 0 }}>
                    <ChevronLeft size={20} color="#FFFFFF" />
                  </button>
                  <button type="button" aria-label="Mes siguiente" onClick={() => goMonth(1)} style={{ background: "none", border: "none", cursor: "pointer", lineHeight: 0 }}>
                    <ChevronRight size={20} color="#FFFFFF" />
                  </button>
                  <span style={{ fontSize: 16, fontWeight: 700, color: "#FFFFFF", flex: 1 }}>{monthLabel}</span>
                  <div className="flex items-center" style={{ gap: 8 }}>
                    <button type="button" onClick={() => navigate({ to: "/mensajes", search: { atleta: team.name } })} className="flex items-center" style={{ gap: 6, border: "1.5px solid rgba(255,255,255,0.3)", borderRadius: 8, height: 34, padding: "0 14px", fontSize: 12, color: "#FFFFFF", background: "none", cursor: "pointer" }}>
                      <MessageCircle size={13} color="#FFFFFF" />Mensaje al equipo
                    </button>
                    <button type="button" onClick={() => setConfirmPublish(true)} style={{ backgroundColor: "#FFFFFF", color: "#111827", borderRadius: 8, height: 34, padding: "0 14px", fontSize: 12, fontWeight: 600, border: "none", cursor: "pointer" }}>
                      Publicar todo
                    </button>
                    <button type="button" title={publishedOnly ? "Ver todo" : "Ver solo publicadas"} aria-label="Vista de atletas" onClick={() => setPublishedOnly((v) => !v)} style={{ background: "none", border: "none", cursor: "pointer", lineHeight: 0, padding: 4 }}>
                      <Eye size={18} color={publishedOnly ? "#FFFFFF" : "rgba(255,255,255,0.6)"} />
                    </button>
                    <button type="button" title="Agregar sesión hoy" aria-label="Agregar sesión hoy" onClick={() => { setMonthOffset(0); setPicker({ key: cellKey(today) }); setPickerQuery(""); }} style={{ background: "none", border: "none", cursor: "pointer", lineHeight: 0, padding: 4 }}>
                      <Plus size={18} color="rgba(255,255,255,0.6)" />
                    </button>
                    <button type="button" title="Ir a hoy" aria-label="Ir a hoy" onClick={() => setMonthOffset(0)} style={{ background: "none", border: "none", cursor: "pointer", lineHeight: 0, padding: 4 }}>
                      <Clock size={18} color="rgba(255,255,255,0.6)" />
                    </button>
                  </div>
                </CalendarTopBar>
                <div
                  style={{
                    ...(dragX !== 0 ? { transform: `translateX(${dragX}px)` } : {}),
                    transition: dragging ? "none" : "transform 300ms ease",
                  }}
                >
                  {/* DAY HEADERS */}
                  <div
                    className="grid"
                    style={{
                      gridTemplateColumns: "repeat(7, 1fr)",
                      position: "sticky",
                      top: 0,
                      backgroundColor: "#FFFFFF",
                      borderBottom: "1px solid #E2E8F0",
                      zIndex: 10,
                    }}
                  >
                    {DAYS.map((d) => (
                      <div
                        key={d}
                        style={{
                          fontSize: 11,
                          fontWeight: 500,
                          color: "#94A3B8",
                          textAlign: "center",
                          padding: "8px 0",
                        }}
                      >
                        {d}
                      </div>
                    ))}
                  </div>

                  <div
                    ref={sel.containerRef}
                    onMouseDown={sel.onMouseDown}
                    style={{ maxHeight: "62vh", overflowY: "auto", userSelect: "none" }}
                  >
                    {Array.from({ length: monthCells.length / 7 }, (_, wi) => (
                    <div key={wi} style={denseCell.weekRow}>
                    {monthCells.slice(wi * 7, wi * 7 + 7).map((d, j) => {
                      const idx = wi * 7 + j;
                      const key = cellKey(d);
                      const day = (sessions[key] ?? []).filter((s) => !publishedOnly || s.published);
                      const outside = d.getMonth() !== viewMonth.getMonth();
                      const isToday = d.getTime() === today.getTime();
                      return (
                        <div key={key} className="group/cell" style={denseCell.cell(outside, idx % 7 === 6)}>
                          <div style={denseCell.header}>
                            <span style={denseCell.dayNum(isToday, outside)}>{d.getDate()}</span>
                            <span className="flex-1" />
                            {copied.length ? (
                              <button
                                type="button"
                                onClick={() => pasteHere(key)}
                                className="cursor-pointer opacity-0 group-hover/cell:opacity-100"
                                style={{ fontSize: 10, color: "#3B82F6", background: "none", border: "none", padding: 0 }}
                              >
                                Pegar aquí
                              </button>
                            ) : null}
                          </div>
                          <div style={denseCell.area}>
                          {day.map((s) => (
                            <Selectable key={s.id} id={selId(key, s.id)} selected={sel.selected.has(selId(key, s.id))} onToggle={sel.toggle} radius={4}>
                              <SessionCard
                                session={toFull(s)}
                                alignRight={false}
                                onChange={(full) => ops.patch(new Set([selId(key, s.id)]), (x) => ({ ...x, name: full.name, published: full.status !== "draft", exercises: full.items.length, detail: full }))}
                                onDelete={() => removeSession(key, s.id)}
                                onCopy={() => { setCopied([{ key, s }] as never); flash("Sesión copiada"); }}
                                onRepeat={() => { ops.place([{ key, s }] as never, 7); flash("Sesión repetida la semana siguiente"); }}
                                onEditDetail={() => navigate({ to: "/sesiones/$sessionId", params: { sessionId: LAB_SESSIONS.find((l) => l.name === s.name)?.id ?? "s1" } })}
                              />
                            </Selectable>
                          ))}
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setPicker({ key });
                              setPickerQuery("");
                            }}
                            className={denseCell.addBtn}
                            style={denseCell.addStyle}
                          >
                            <Plus size={10} />
                            sesión
                          </button>

                          {picker?.key === key ? (
                            <>
                              <div
                                onClick={() => setPicker(null)}
                                style={{ position: "fixed", inset: 0, zIndex: 25 }}
                              />
                              <div
                                style={{
                                  position: "absolute",
                                  top: 6,
                                  left: 6,
                                  width: 230,
                                  backgroundColor: "#FFFFFF",
                                  border: "1px solid #E2E8F0",
                                  borderRadius: 12,
                                  boxShadow: "0 4px 16px rgba(0,0,0,0.10)",
                                  padding: 8,
                                  zIndex: 30,
                                }}
                              >
                                <div className="relative" style={{ marginBottom: 6 }}>
                                  <Search
                                    size={13}
                                    color="#CBD5E1"
                                    style={{ position: "absolute", left: 10, top: 10 }}
                                  />
                                  <input
                                    autoFocus
                                    value={pickerQuery}
                                    onChange={(e) => setPickerQuery(e.target.value)}
                                    placeholder="Buscar sesión…"
                                    aria-label="Buscar sesión"
                                    style={{
                                      width: "100%",
                                      height: 34,
                                      border: "1px solid #E2E8F0",
                                      borderRadius: 9,
                                      padding: "0 10px 0 30px",
                                      fontSize: 12,
                                      color: "#374151",
                                      outline: "none",
                                    }}
                                  />
                                </div>
                                {LAB_SESSIONS.filter((s) =>
                                  s.name.toLowerCase().includes(pickerQuery.trim().toLowerCase()),
                                ).map((s) => (
                                  <button
                                    key={s.id}
                                    type="button"
                                    onClick={() => addSession(key, s.name, s.exercises.length)}
                                    className="flex w-full cursor-pointer items-center justify-between rounded-[8px] transition-colors hover:bg-[#F8FAFC]"
                                    style={{
                                      background: "none",
                                      border: "none",
                                      padding: "7px 10px",
                                      fontSize: 12,
                                      color: "#374151",
                                      textAlign: "left",
                                    }}
                                  >
                                    <span>{s.name}</span>
                                    <span style={{ fontSize: 10, color: "#94A3B8" }}>{s.category}</span>
                                  </button>
                                ))}
                                <div style={{ height: 1, backgroundColor: "#F1F5F9", margin: "6px 0" }} />
                                <button
                                  type="button"
                                  onClick={() => {
                                    setPicker(null);
                                    setPickerQuery("");
                                    navigate({
                                      to: "/sesiones/$sessionId",
                                      params: { sessionId: "nueva" },
                                      search: {
                                        equipo: team.name,
                                        equipoId: team.id,
                                        fecha: key.split("|")[1] ?? "",
                                      },
                                    });
                                  }}
                                  className="flex w-full cursor-pointer items-center rounded-[8px] transition-colors hover:bg-[#F8FAFC]"
                                  style={{
                                    background: "none",
                                    border: "none",
                                    padding: "7px 10px",
                                    fontSize: 12,
                                    color: "#94A3B8",
                                    gap: 6,
                                  }}
                                >
                                  <Plus size={12} />
                                  Nueva sesión
                                </button>
                              </div>
                            </>
                          ) : null}
                        </div>
                      );
                    })}
                    </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* TEAM NOTE */}
              <div
                className="flex items-start"
                style={{
                  marginTop: 16,
                  backgroundColor: "#FFFBEB",
                  borderRadius: 10,
                  border: "1px solid #FDE68A",
                  padding: "12px 16px",
                  gap: 10,
                }}
              >
                <Info size={16} color="#D97706" style={{ flexShrink: 0, marginTop: 1 }} />
                <p style={{ fontSize: 12, color: "#92400E" }}>
                  Al publicar, todos los atletas del equipo reciben estas sesiones automáticamente. Podés
                  editarlas individualmente desde el perfil de cada atleta si alguno necesita ajustes.
                </p>
              </div>
            </>
          ) : null}

          {tab === "Miembros" ? (
            <div className="flex flex-col" style={{ gap: 8 }}>
              <button
                type="button"
                onClick={() => setAddMember(true)}
                className="flex w-full cursor-pointer items-center justify-center transition-colors hover:bg-[#F8FAFC]"
                style={{
                  border: "1px solid #E2E8F0",
                  borderRadius: 10,
                  height: 40,
                  fontSize: 13,
                  color: "#374151",
                  gap: 8,
                  backgroundColor: "#FFFFFF",
                  marginBottom: 8,
                }}
              >
                <UserPlus size={13} color="#94A3B8" />
                Agregar atleta
              </button>

              {memberList.map((m) => (
                <div
                  key={m.id}
                  className="flex items-center"
                  style={{
                    backgroundColor: "#FFFFFF",
                    borderRadius: 10,
                    border: "1px solid #E2E8F0",
                    padding: "12px 16px",
                    gap: 12,
                  }}
                >
                  <div
                    className="flex flex-shrink-0 items-center justify-center rounded-full"
                    style={{
                      width: 36,
                      height: 36,
                      backgroundColor: "#F1F5F9",
                      color: "#94A3B8",
                      fontSize: 12,
                      fontWeight: 600,
                    }}
                  >
                    {initials(m.name)}
                  </div>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 500, color: "#111827" }}>{m.name}</div>
                    <div style={{ fontSize: 11, color: "#94A3B8" }}>
                      Coach desde hace {m.months} {m.months === 1 ? "mes" : "meses"}
                    </div>
                  </div>
                  <span
                    title={LOAD_COLOR[m.load].label}
                    style={{
                      width: 8,
                      height: 8,
                      borderRadius: 999,
                      backgroundColor: LOAD_COLOR[m.load].color,
                      flexShrink: 0,
                    }}
                  />
                  <span style={{ flex: 1, textAlign: "right", fontSize: 11, color: "#94A3B8" }}>
                    Última sesión: {m.last}
                  </span>
                  <button
                    type="button"
                    onClick={() => navigate({ to: "/atletas/$athleteId", params: { athleteId: m.id } })}
                    className="cursor-pointer transition-colors hover:text-[#111827]"
                    style={{ background: "none", border: "none", padding: 0, fontSize: 12, color: "#94A3B8" }}
                  >
                    Ver perfil
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setTeams((prev) =>
                        prev.map((t) =>
                          t.id === team.id
                            ? { ...t, members: t.members.filter((id) => id !== m.id) }
                            : t,
                        ),
                      )
                    }
                    aria-label={`Quitar ${m.name} del equipo`}
                    className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#EF4444]"
                    style={{ background: "none", border: "none", padding: 0 }}
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          ) : null}

          {tab === "Logros" ? (
            <div className="flex flex-col" style={{ gap: 10 }}>
              <div
                style={{
                  fontSize: 11,
                  fontWeight: 600,
                  color: "#94A3B8",
                  textTransform: "uppercase",
                  letterSpacing: "0.5px",
                }}
              >
                Esta semana
              </div>
              {LOGROS.map((l) => (
                <div
                  key={l.id}
                  className="flex items-start"
                  style={{
                    backgroundColor: "#FFFFFF",
                    borderRadius: 10,
                    border: "1px solid #E2E8F0",
                    padding: "14px 16px",
                    gap: 12,
                  }}
                >
                  <div
                    className="flex flex-shrink-0 items-center justify-center rounded-full"
                    style={{ width: 36, height: 36, backgroundColor: "#FFFBEB" }}
                  >
                    <Trophy size={16} color="#D97706" />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div>
                      <span style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>{l.name}</span>{" "}
                      <span style={{ fontSize: 12, color: "#374151" }}>{l.text}</span>
                    </div>
                    <div style={{ fontSize: 10, color: "#94A3B8", marginTop: 2 }}>{l.when}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFires((f) => ({ ...f, [l.id]: (f[l.id] ?? 0) + 1 }))}
                    className="cursor-pointer transition-colors hover:bg-[#FEF9C3]"
                    style={{
                      fontSize: 10,
                      color: "#94A3B8",
                      border: "1px solid #E2E8F0",
                      borderRadius: 20,
                      padding: "3px 8px",
                      backgroundColor: "#FFFFFF",
                    }}
                  >
                    🔥 {l.fire + (fires[l.id] ?? 0)}
                  </button>
                </div>
              ))}
            </div>
          ) : null}
          </div>
        </div>
      </main>

      {/* PUBLISH CONFIRM */}
      {confirmPublish ? (
        <ModalShell onClose={() => setConfirmPublish(false)} width={420}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: "#111827" }}>
            ¿Publicar {draftCount} {draftCount === 1 ? "sesión" : "sesiones"} para los{" "}
            {memberList.length} atletas del equipo?
          </h3>
          <p style={{ fontSize: 12, color: "#94A3B8", marginTop: 6 }}>
            Todos los miembros van a recibir la planificación de esta semana.
          </p>
          <div className="flex" style={{ gap: 10, marginTop: 20 }}>
            <button
              type="button"
              onClick={() => setConfirmPublish(false)}
              className="cursor-pointer"
              style={{ ...outlineBtn, flex: 1, height: 40 }}
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={publishWeek}
              className="cursor-pointer"
              style={{
                flex: 1,
                height: 40,
                backgroundColor: "#111827",
                color: "#FFFFFF",
                border: "none",
                borderRadius: 10,
                fontSize: 13,
                fontWeight: 600,
              }}
            >
              Confirmar
            </button>
          </div>
        </ModalShell>
      ) : null}

      {/* ADD MEMBER */}
      {addMember ? (
        <AddMemberModal
          current={team.members}
          onClose={() => setAddMember(false)}
          onSave={(ids) => {
            setTeams((prev) => prev.map((t) => (t.id === team.id ? { ...t, members: ids } : t)));
            setAddMember(false);
            flash("Miembros actualizados");
          }}
        />
      ) : null}

      {/* CREATE / EDIT TEAM */}
      {modal ? (
        <TeamModal
          mode={modal.mode}
          team={modal.team}
          onClose={() => setModal(null)}
          onDelete={() => {
            const id = modal.team?.id;
            setTeams((prev) => {
              const next = prev.filter((t) => t.id !== id);
              if (next[0]) setActiveId(next[0].id);
              return next;
            });
            setModal(null);
            flash("Equipo eliminado");
          }}
          onSave={(t) => {
            if (modal.mode === "create") {
              setTeams((prev) => [...prev, t]);
              setActiveId(t.id);
              flash("Equipo creado ✓");
            } else {
              setTeams((prev) => prev.map((x) => (x.id === t.id ? t : x)));
              flash(`Equipo "${t.name}" actualizado`);
            }
            setModal(null);
          }}
        />
      ) : null}

      {toast ? (
        <div
          style={{
            position: "fixed",
            bottom: 24,
            left: "50%",
            transform: "translateX(-50%)",
            backgroundColor: "#111827",
            color: "#FFFFFF",
            borderRadius: 10,
            padding: "10px 18px",
            fontSize: 13,
            zIndex: 60,
          }}
        >
          {toast}
        </div>
      ) : null}
    </div>
  );
}

function ModalShell({
  children,
  onClose,
  width = 480,
}: {
  children: React.ReactNode;
  onClose: () => void;
  width?: number;
}) {
  return (
    <div
      className="fixed inset-0 flex items-center justify-center"
      style={{ backgroundColor: "rgba(0,0,0,0.35)", zIndex: 50 }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width,
          backgroundColor: "#FFFFFF",
          borderRadius: 16,
          padding: 28,
          boxShadow: "0 8px 32px rgba(0,0,0,0.12)",
          maxHeight: "88vh",
          overflowY: "auto",
        }}
      >
        {children}
      </div>
    </div>
  );
}

function AthletePicker({
  selected,
  onToggle,
}: {
  selected: string[];
  onToggle: (id: string) => void;
}) {
  const [q, setQ] = useState("");
  const list = ALL_ATHLETES.filter((a) => a.name.toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <>
      <div className="relative" style={{ marginBottom: 8 }}>
        <Search size={13} color="#CBD5E1" style={{ position: "absolute", left: 12, top: 12 }} />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar atleta…"
          aria-label="Buscar atleta"
          style={{
            width: "100%",
            height: 38,
            border: "1px solid #E2E8F0",
            borderRadius: 9,
            padding: "0 12px 0 32px",
            fontSize: 13,
            color: "#374151",
            outline: "none",
          }}
        />
      </div>
      <div style={{ maxHeight: 180, overflowY: "auto" }}>
        {list.map((a) => (
          <label
            key={a.id}
            className="flex cursor-pointer items-center transition-colors hover:bg-[#F8FAFC]"
            style={{ gap: 10, padding: "7px 8px", borderRadius: 8 }}
          >
            <input
              type="checkbox"
              checked={selected.includes(a.id)}
              onChange={() => onToggle(a.id)}
              style={{ width: 16, height: 16, accentColor: "#111827" }}
            />
            <span
              className="flex items-center justify-center rounded-full"
              style={{
                width: 28,
                height: 28,
                backgroundColor: "#F1F5F9",
                color: "#94A3B8",
                fontSize: 10,
                fontWeight: 600,
              }}
            >
              {initials(a.name)}
            </span>
            <span style={{ flex: 1, fontSize: 13, color: "#111827" }}>{a.name}</span>
            <span style={{ fontSize: 11, color: "#94A3B8" }}>
              {LOAD_COLOR[a.load].label}
            </span>
          </label>
        ))}
      </div>
    </>
  );
}

function AddMemberModal({
  current,
  onClose,
  onSave,
}: {
  current: string[];
  onClose: () => void;
  onSave: (ids: string[]) => void;
}) {
  const [ids, setIds] = useState<string[]>(current);
  return (
    <ModalShell onClose={onClose}>
      <div className="flex items-start justify-between" style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827" }}>Agregar atletas</h3>
        <button
          type="button"
          onClick={onClose}
          aria-label="Cerrar"
          className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#111827]"
          style={{ background: "none", border: "none", padding: 0 }}
        >
          <X size={16} />
        </button>
      </div>
      <AthletePicker
        selected={ids}
        onToggle={(id) => setIds((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]))}
      />
      <div className="flex" style={{ gap: 10, marginTop: 20 }}>
        <button type="button" onClick={onClose} style={{ ...outlineBtn, flex: 1, height: 40 }}>
          Cancelar
        </button>
        <button
          type="button"
          onClick={() => onSave(ids)}
          className="cursor-pointer"
          style={{
            flex: 1,
            height: 40,
            backgroundColor: "#111827",
            color: "#FFFFFF",
            border: "none",
            borderRadius: 10,
            fontSize: 13,
            fontWeight: 600,
          }}
        >
          Guardar
        </button>
      </div>
    </ModalShell>
  );
}

function TeamModal({
  mode,
  team,
  onClose,
  onSave,
  onDelete,
}: {
  mode: "create" | "edit";
  team: Team | null;
  onClose: () => void;
  onSave: (team: Team) => void;
  onDelete: () => void;
}) {
  const [name, setName] = useState(team?.name ?? "");
  const [desc, setDesc] = useState(team?.description ?? "");
  const [ids, setIds] = useState<string[]>(team?.members ?? []);
  const [features, setFeatures] = useState<Features>(
    team?.features ?? { planning: true, chat: true, achievements: true },
  );

  const rows: { key: keyof Features; label: string; hint: string }[] = [
    { key: "planning", label: "Planificación compartida", hint: "Todos reciben la misma sesión automáticamente." },
    { key: "chat", label: "Chat grupal", hint: "Los atletas pueden chatear entre ellos." },
    { key: "achievements", label: "Logros visibles", hint: "Los miembros ven los logros de sus compañeros." },
  ];

  return (
    <ModalShell onClose={onClose}>
      <div className="flex items-start justify-between" style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 16, fontWeight: 700, color: "#111827" }}>
          {mode === "create" ? "Nuevo equipo" : "Gestionar equipo"}
        </h3>
        <button
          type="button"
          onClick={onClose}
          aria-label="Cerrar"
          className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#111827]"
          style={{ background: "none", border: "none", padding: 0 }}
        >
          <X size={16} />
        </button>
      </div>

      <div style={{ fontSize: 12, fontWeight: 500, color: "#374151", marginBottom: 6 }}>
        Nombre del equipo
      </div>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Ej. Equipo Mañana"
        aria-label="Nombre del equipo"
        style={{
          width: "100%",
          height: 44,
          border: "1px solid #E2E8F0",
          borderRadius: 10,
          padding: "0 14px",
          fontSize: 13,
          color: "#374151",
          outline: "none",
          marginBottom: 14,
        }}
      />

      <div style={{ fontSize: 12, fontWeight: 500, color: "#374151", marginBottom: 6 }}>
        Descripción (opcional)
      </div>
      <textarea
        value={desc}
        onChange={(e) => setDesc(e.target.value)}
        placeholder="Objetivos, horarios u observaciones del grupo."
        aria-label="Descripción del equipo"
        style={{
          width: "100%",
          height: 60,
          border: "1px solid #E2E8F0",
          borderRadius: 10,
          padding: "10px 14px",
          fontSize: 13,
          color: "#374151",
          outline: "none",
          resize: "none",
          marginBottom: 16,
        }}
      />

      <div
        style={{
          fontSize: 11,
          fontWeight: 600,
          color: "#94A3B8",
          textTransform: "uppercase",
          letterSpacing: "0.5px",
          marginBottom: 8,
        }}
      >
        Miembros
      </div>
      <AthletePicker
        selected={ids}
        onToggle={(id) => setIds((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]))}
      />

      <div
        style={{
          fontSize: 11,
          fontWeight: 600,
          color: "#94A3B8",
          textTransform: "uppercase",
          letterSpacing: "0.5px",
          margin: "16px 0 8px",
        }}
      >
        Funciones del equipo
      </div>
      {rows.map((r) => (
        <div
          key={r.key}
          className="flex items-center"
          style={{ gap: 12, padding: "10px 0", borderBottom: "1px solid #F1F5F9" }}
        >
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, color: "#111827" }}>{r.label}</div>
            <div style={{ fontSize: 11, color: "#94A3B8" }}>{r.hint}</div>
          </div>
          <Toggle
            on={features[r.key]}
            onChange={(v) => setFeatures((f) => ({ ...f, [r.key]: v }))}
          />
        </div>
      ))}

      <div className="flex items-center" style={{ gap: 10, marginTop: 20 }}>
        {mode === "edit" ? (
          <button
            type="button"
            onClick={onDelete}
            className="cursor-pointer"
            style={{ background: "none", border: "none", padding: 0, fontSize: 12, color: "#EF4444" }}
          >
            Eliminar equipo
          </button>
        ) : null}
        <div style={{ flex: 1 }} />
        <button type="button" onClick={onClose} style={{ ...outlineBtn, height: 40 }}>
          Cancelar
        </button>
        <button
          type="button"
          disabled={!name.trim()}
          onClick={() =>
            onSave({
              id: team?.id ?? `equipo-${Date.now()}`,
              name: name.trim(),
              description: desc.trim(),
              members: ids,
              features,
            })
          }
          className={name.trim() ? "cursor-pointer" : ""}
          style={{
            flex: 1,
            height: 40,
            backgroundColor: name.trim() ? "#111827" : "#94A3B8",
            color: "#FFFFFF",
            border: "none",
            borderRadius: 10,
            fontSize: 13,
            fontWeight: 600,
          }}
        >
          {mode === "create" ? "Crear equipo" : "Guardar cambios"}
        </button>
      </div>
    </ModalShell>
  );
}
