import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle,
  ChevronDown,
  MessageCircle,
  Search,
  Sparkles,
  Users,
  X,
} from "lucide-react";
import { Sidebar } from "@/components/togo/Sidebar";

export const Route = createFileRoute("/bienestar")({
  head: () => ({
    meta: [
      { title: "Monitor de bienestar · TOGO" },
      {
        name: "description",
        content:
          "Seguí el estado de bienestar de tus atletas: energía, sueño, ánimo y RPE de cada sesión en un solo panel.",
      },
      { property: "og:title", content: "Monitor de bienestar · TOGO" },
      {
        property: "og:description",
        content: "Energía, sueño, ánimo y RPE de tus atletas en tiempo real.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WellnessMonitor,
});

type Status = "risk" | "warn" | "ok" | "none";

type Athlete = {
  initials: string;
  name: string;
  status: Status;
  energy: number | null;
  sleep: number | null;
  mood: number | null;
  rpe: number | null;
  last: string;
  stale?: boolean;
};

const athletes: Athlete[] = [
  { initials: "MG", name: "Martina González", status: "risk", energy: 3, sleep: 4, mood: 3, rpe: 9, last: "Hace 1h" },
  { initials: "LR", name: "Lucas Rodríguez", status: "risk", energy: 5, sleep: 4, mood: 4, rpe: 8, last: "Hace 3h" },
  { initials: "SP", name: "Sofía Pérez", status: "warn", energy: 5, sleep: 5, mood: 6, rpe: 7, last: "Ayer" },
  { initials: "JM", name: "Julián Martínez", status: "warn", energy: 3, sleep: 5, mood: 5, rpe: 7, last: "Hace 2 días" },
  { initials: "VM", name: "Valentina Muñoz", status: "warn", energy: 6, sleep: 6, mood: 7, rpe: 6, last: "Hace 4h" },
  { initials: "AI", name: "Agustín Ibáñez", status: "warn", energy: 7, sleep: 8, mood: 6, rpe: 5, last: "Ayer" },
  { initials: "CR", name: "Camila Ramírez", status: "ok", energy: 8, sleep: 8, mood: 8, rpe: 5, last: "Hace 1h" },
  { initials: "TF", name: "Tomás Fernández", status: "ok", energy: 9, sleep: 9, mood: 9, rpe: 4, last: "Hace 2h" },
  { initials: "LC", name: "Lucía Castro", status: "ok", energy: 8, sleep: 8, mood: 7, rpe: 6, last: "Ayer" },
  { initials: "NV", name: "Nicolás Vargas", status: "ok", energy: 7, sleep: 8, mood: 8, rpe: 5, last: "Hace 3h" },
  { initials: "PA", name: "Paula Acosta", status: "ok", energy: 9, sleep: 9, mood: 9, rpe: 4, last: "Ayer" },
  {
    initials: "RB",
    name: "Rodrigo Blanco",
    status: "none",
    energy: null,
    sleep: null,
    mood: null,
    rpe: null,
    last: "Hace +7 días",
    stale: true,
  },
];

const statusMeta: Record<Status, { label: string; color: string; bg: string; dot: string }> = {
  ok: { label: "Bien", color: "#16A34A", bg: "#F0FDF4", dot: "#16A34A" },
  warn: { label: "Precaución", color: "#D97706", bg: "#FFFBEB", dot: "#D97706" },
  risk: { label: "En riesgo", color: "#EF4444", bg: "#FEF2F2", dot: "#EF4444" },
  none: { label: "Sin registro", color: "#94A3B8", bg: "#F8FAFC", dot: "#CBD5E1" },
};

const aiSuggestion: Record<Status, string> = {
  risk: "El atleta muestra señales de fatiga acumulada. Considerá una semana de descarga o reducir la intensidad en la próxima sesión.",
  warn: "Los niveles de bienestar son moderados. Mantené la carga actual y monitoreá de cerca los próximos registros.",
  ok: "El atleta está respondiendo muy bien. Está apto para aumentar la carga o introducir un nuevo estímulo esta semana.",
  none: "Sin datos suficientes para generar una sugerencia. Recordale al atleta registrar su bienestar antes de la próxima sesión.",
};

const rangeOptions = ["Hoy", "Última semana", "Últimas 2 semanas", "Último mes"];
const filters = ["Todos", "En riesgo", "Precaución", "Bien", "Sin registro"];
const filterStatus: Record<string, Status> = {
  "En riesgo": "risk",
  Precaución: "warn",
  Bien: "ok",
  "Sin registro": "none",
};

const dash = (
  <span className="text-[12px]" style={{ color: "#CBD5E1" }}>
    —
  </span>
);

function StatusPill({ status }: { status: Status }) {
  const m = statusMeta[status];
  return (
    <span
      className="inline-flex items-center"
      style={{ gap: 6, backgroundColor: m.bg, borderRadius: 20, padding: "3px 10px" }}
    >
      <span style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: m.dot }} />
      <span className="text-[12px] font-medium" style={{ color: m.color }}>
        {m.label}
      </span>
    </span>
  );
}

function ScoreCell({ value }: { value: number | null }) {
  if (value === null)
    return (
      <span className="block text-center text-[13px]" style={{ color: "#CBD5E1" }}>
        —
      </span>
    );
  return (
    <span className="block text-center text-[13px]" style={{ color: "#374151" }}>
      {value}/10
    </span>
  );
}

function RpeChip({ value }: { value: number | null }) {
  if (value === null) return dash;
  return (
    <span
      className="inline-flex items-center text-[12px]"
      style={{ backgroundColor: "#F1F5F9", borderRadius: 6, padding: "3px 8px", gap: 4, color: "#94A3B8" }}
    >
      RPE
      <strong style={{ color: "#111827" }}>{value}</strong>
    </span>
  );
}

const dayNames = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];

/** Deterministic pseudo-series around the athlete's current values. */
function buildSeries(base: number, days: number) {
  const out: number[] = [];
  for (let i = 0; i < days; i++) {
    const wave = Math.sin((i + base) * 1.1) * 1.2;
    const v = Math.round(Math.min(10, Math.max(1, base + wave - (days - 1 - i) * 0.05)));
    out.push(v);
  }
  return out;
}

function WellnessChart({ athlete, days }: { athlete: Athlete; days: number }) {
  const w = 360;
  const h = 120;
  const padL = 20;
  const padR = 6;
  const padT = 8;
  const padB = 18;
  const energy = buildSeries(athlete.energy ?? 5, days);
  const sleep = buildSeries(athlete.sleep ?? 5, days);
  const mood = buildSeries(athlete.mood ?? 5, days);
  const x = (i: number) => padL + (i / Math.max(1, days - 1)) * (w - padL - padR);
  const y = (v: number) => padT + (1 - v / 10) * (h - padT - padB);
  const step = days <= 7 ? 1 : days <= 14 ? 2 : 5;

  const line = (vals: number[], color: string) => (
    <g key={color}>
      <polyline
        points={vals.map((v, i) => `${x(i)},${y(v)}`).join(" ")}
        fill="none"
        stroke={color}
        strokeWidth="2"
      />
      {vals.map((v, i) => (
        <circle key={i} cx={x(i)} cy={y(v)} r={2.5} fill={color} />
      ))}
    </g>
  );

  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" height={h} role="img" aria-label="Evolución de bienestar">
      {[0, 5, 10].map((g) => (
        <g key={g}>
          <line
            x1={padL}
            x2={w - padR}
            y1={y(g)}
            y2={y(g)}
            stroke="#F1F5F9"
            strokeWidth="1"
            strokeDasharray="3 3"
          />
          <text x={0} y={y(g) + 3} fontSize="10" fill="#CBD5E1">
            {g}
          </text>
        </g>
      ))}
      {line(energy, "#3B82F6")}
      {line(sleep, "#8B5CF6")}
      {line(mood, "#F59E0B")}
      {energy.map((_, i) =>
        i % step === 0 ? (
          <text key={i} x={x(i)} y={h - 4} fontSize="10" fill="#CBD5E1" textAnchor="middle">
            {dayNames[i % 7]}
          </text>
        ) : null,
      )}
    </svg>
  );
}

const panelSessions = [
  { date: "Hoy", name: "Fuerza tren superior", rpe: 9, dot: "#EF4444" },
  { date: "Lun 25/8", name: "Sentadillas", rpe: 8, dot: "#EF4444" },
  { date: "Vie 22/8", name: "HIIT", rpe: 7, dot: "#D97706" },
  { date: "Mié 20/8", name: "Movilidad", rpe: 5, dot: "#16A34A" },
  { date: "Lun 18/8", name: "Fuerza general", rpe: 6, dot: "#16A34A" },
];

const colWidths = { status: 110, metric: 90, rpe: 140, last: 130, actions: 80 };


function WellnessMonitor() {
  const navigate = useNavigate();
  const [range, setRange] = useState("Última semana");
  const [rangeOpen, setRangeOpen] = useState(false);
  const [filter, setFilter] = useState("Todos");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Athlete | null>(null);
  const [chartDays, setChartDays] = useState(7);

  const rows = useMemo(
    () =>
      athletes.filter(
        (a) =>
          (filter === "Todos" || a.status === filterStatus[filter]) &&
          a.name.toLowerCase().includes(query.trim().toLowerCase()),
      ),
    [filter, query],
  );

  const counts = {
    total: athletes.length,
    risk: athletes.filter((a) => a.status === "risk").length,
    warn: athletes.filter((a) => a.status === "warn").length,
    ok: athletes.filter((a) => a.status === "ok").length,
  };

  const chips = [
    { icon: Users, value: counts.total, label: "Atletas", color: "#111827", labelColor: "#94A3B8", bg: "#FFFFFF", border: "#E2E8F0", iconColor: "#94A3B8" },
    { icon: AlertCircle, value: counts.risk, label: "En riesgo", color: "#EF4444", labelColor: "#EF4444", bg: "#FEF2F2", border: "#FECACA", iconColor: "#EF4444" },
    { icon: AlertTriangle, value: counts.warn, label: "Precaución", color: "#D97706", labelColor: "#D97706", bg: "#FFFBEB", border: "#FDE68A", iconColor: "#D97706" },
    { icon: CheckCircle, value: counts.ok, label: "Bien", color: "#16A34A", labelColor: "#16A34A", bg: "#F0FDF4", border: "#BBF7D0", iconColor: "#16A34A" },
  ];

  const headers: { label: string; width?: number; center?: boolean }[] = [
    { label: "Atleta" },
    { label: "Estado", width: colWidths.status },
    { label: "Energía", width: colWidths.metric, center: true },
    { label: "Sueño", width: colWidths.metric, center: true },
    { label: "Ánimo", width: colWidths.metric, center: true },
    { label: "RPE última sesión", width: colWidths.rpe },
    { label: "Último registro", width: colWidths.last },
    { label: "", width: colWidths.actions },
  ];

  return (
    <div className="grid min-h-screen grid-cols-[240px_1fr]" style={{ backgroundColor: "#F8FAFC" }}>
      <Sidebar active="Bienestar" />

      <main style={{ padding: "32px 40px" }}>
        <div className="flex items-center justify-between" style={{ marginBottom: 8 }}>
          <h1 className="text-[22px] font-bold" style={{ color: "#111827" }}>
            Monitor de bienestar
          </h1>
          <div style={{ position: "relative" }}>
            <button
              type="button"
              onClick={() => setRangeOpen((v) => !v)}
              className="inline-flex items-center"
              style={{
                height: 36,
                border: "1px solid #E2E8F0",
                borderRadius: 10,
                padding: "0 14px",
                fontSize: 13,
                color: "#374151",
                backgroundColor: "#FFFFFF",
                gap: 8,
              }}
            >
              {range}
              <ChevronDown size={13} color="#CBD5E1" />
            </button>
            {rangeOpen && (
              <div
                style={{
                  position: "absolute",
                  right: 0,
                  top: 42,
                  zIndex: 20,
                  backgroundColor: "#FFFFFF",
                  border: "1px solid #E2E8F0",
                  borderRadius: 10,
                  boxShadow: "0 8px 24px rgba(0,0,0,0.1)",
                  padding: "4px 0",
                  minWidth: 180,
                }}
              >
                {rangeOptions.map((o) => (
                  <button
                    key={o}
                    type="button"
                    onClick={() => {
                      setRange(o);
                      setRangeOpen(false);
                    }}
                    className="flex w-full items-center text-left text-[13px] hover:bg-[#F8FAFC]"
                    style={{ padding: "8px 14px", color: "#374151" }}
                  >
                    {o}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <p className="text-[13px]" style={{ color: "#94A3B8", marginBottom: 24 }}>
          Estado de bienestar de tus atletas basado en sus registros pre y post sesión.
        </p>

        {/* SUMMARY CHIPS */}
        <div className="flex" style={{ gap: 12, marginBottom: 24 }}>
          {chips.map((c) => (
            <div
              key={c.label}
              className="flex items-center"
              style={{
                backgroundColor: c.bg,
                border: `1px solid ${c.border}`,
                borderRadius: 12,
                padding: "14px 20px",
                gap: 10,
                minWidth: 140,
              }}
            >
              <c.icon size={18} color={c.iconColor} />
              <div className="flex items-baseline" style={{ gap: 6 }}>
                <span className="text-[20px] font-bold" style={{ color: c.color }}>
                  {c.value}
                </span>
                <span className="text-[12px]" style={{ color: c.labelColor }}>
                  {c.label}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* FILTER + SEARCH */}
        <div className="flex items-center" style={{ gap: 12, marginBottom: 20 }}>
          <div
            className="flex flex-1 items-center"
            style={{
              height: 40,
              border: "1px solid #E2E8F0",
              borderRadius: 10,
              padding: "0 14px",
              backgroundColor: "#FFFFFF",
              gap: 8,
            }}
          >
            <Search size={15} color="#CBD5E1" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar atleta..."
              aria-label="Buscar atleta"
              className="w-full bg-transparent text-[13px] outline-none"
              style={{ color: "#111827" }}
            />
          </div>
          <div className="flex" style={{ gap: 8 }}>
            {filters.map((f) => {
              const active = f === filter;
              return (
                <button
                  key={f}
                  type="button"
                  onClick={() => setFilter(f)}
                  style={{
                    height: 36,
                    borderRadius: 20,
                    padding: "0 14px",
                    fontSize: 13,
                    fontWeight: 500,
                    backgroundColor: active ? "#111827" : "#FFFFFF",
                    color: active ? "#FFFFFF" : "#64748B",
                    border: active ? "1px solid #111827" : "1px solid #E2E8F0",
                  }}
                >
                  {f}
                </button>
              );
            })}
          </div>
        </div>

        {/* TABLE */}
        <div
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 14,
            border: "1px solid #E2E8F0",
            overflow: "hidden",
          }}
        >
          <div
            className="flex items-center"
            style={{
              backgroundColor: "#F8FAFC",
              borderBottom: "1px solid #E2E8F0",
              height: 40,
              padding: "0 20px",
            }}
          >
            {headers.map((h) => (
              <span
                key={h.label || "actions"}
                className="uppercase"
                style={{
                  width: h.width,
                  flex: h.width ? undefined : 1,
                  flexShrink: 0,
                  fontSize: 11,
                  fontWeight: 500,
                  color: "#94A3B8",
                  letterSpacing: "0.4px",
                  textAlign: h.center ? "center" : undefined,
                }}
              >
                {h.label}
              </span>
            ))}
          </div>

          {rows.map((a, i) => (
            <div
              key={a.name}
              className="flex items-center"
              style={{
                backgroundColor: i % 2 === 0 ? "#FFFFFF" : "#FAFAFA",
                borderBottom: "1px solid #F8FAFC",
                height: 60,
                padding: "0 20px",
              }}
            >
              <div className="flex flex-1 items-center" style={{ gap: 10 }}>
                <span
                  className="flex items-center justify-center"
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: "50%",
                    backgroundColor: "#E2E8F0",
                    fontSize: 13,
                    fontWeight: 600,
                    color: "#94A3B8",
                    border: a.status === "risk" ? "2px solid #EF4444" : undefined,
                  }}
                >
                  {a.initials}
                </span>
                <span className="text-[13px] font-semibold" style={{ color: "#111827" }}>
                  {a.name}
                </span>
              </div>
              <span style={{ width: colWidths.status, flexShrink: 0 }}>
                <StatusPill status={a.status} />
              </span>
              <span style={{ width: colWidths.metric, flexShrink: 0 }}>
                <ScoreCell value={a.energy} />
              </span>
              <span style={{ width: colWidths.metric, flexShrink: 0 }}>
                <ScoreCell value={a.sleep} />
              </span>
              <span style={{ width: colWidths.metric, flexShrink: 0 }}>
                <ScoreCell value={a.mood} />
              </span>
              <span style={{ width: colWidths.rpe, flexShrink: 0 }}>
                <RpeChip value={a.rpe} />
              </span>
              <span
                className="text-[12px]"
                style={{ width: colWidths.last, flexShrink: 0, color: a.stale ? "#EF4444" : "#94A3B8" }}
              >
                {a.last}
              </span>
              <span
                className="flex justify-end"
                style={{ width: colWidths.actions, flexShrink: 0, gap: 8 }}
              >
                <button
                  type="button"
                  onClick={() => setSelected(a)}
                  style={{
                    border: "1px solid #E2E8F0",
                    borderRadius: 8,
                    padding: "5px 12px",
                    fontSize: 12,
                    fontWeight: 500,
                    color: "#374151",
                    backgroundColor: "#FFFFFF",
                  }}
                >
                  Ver
                </button>
              </span>
            </div>
          ))}
        </div>
      </main>

      {/* DETAIL PANEL */}
      {selected && (
        <>
          <div
            role="button"
            tabIndex={0}
            aria-label="Cerrar panel"
            onClick={() => setSelected(null)}
            onKeyDown={(e) => {
              if (e.key === "Escape" || e.key === "Enter") setSelected(null);
            }}
            style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.2)", zIndex: 55 }}
          />
          <aside
            className="flex flex-col togo-panel-slide"
            style={{
              position: "fixed",
              right: 0,
              top: 0,
              height: "100vh",
              width: 420,
              backgroundColor: "#FFFFFF",
              borderLeft: "1px solid #E2E8F0",
              zIndex: 60,
            }}
          >
            <div
              className="flex items-center"
              style={{ padding: 20, borderBottom: "1px solid #E2E8F0", gap: 12 }}
            >
              <span
                className="flex items-center justify-center"
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  backgroundColor: "#E2E8F0",
                  fontSize: 13,
                  fontWeight: 600,
                  color: "#94A3B8",
                }}
              >
                {selected.initials}
              </span>
              <div className="flex flex-1 items-center" style={{ gap: 10 }}>
                <span className="text-[15px] font-semibold" style={{ color: "#111827" }}>
                  {selected.name}
                </span>
                <StatusPill status={selected.status} />
              </div>
              <button type="button" aria-label="Cerrar" onClick={() => setSelected(null)}>
                <X size={18} color="#94A3B8" />
              </button>
            </div>

            <div className="flex flex-col" style={{ padding: 20, gap: 16, borderBottom: "1px solid #F8FAFC" }}>
              <div
                style={{
                  backgroundColor: "#FFFFFF",
                  borderRadius: 12,
                  border: "1px solid #E2E8F0",
                  padding: 16,
                }}
              >
                <div className="flex items-center justify-between" style={{ marginBottom: 12 }}>
                  <span className="text-[13px] font-semibold" style={{ color: "#111827" }}>
                    Evolución de bienestar
                  </span>
                  <div className="flex" style={{ gap: 6 }}>
                    {[7, 14, 30].map((d) => (
                      <button
                        key={d}
                        type="button"
                        onClick={() => setChartDays(d)}
                        style={{
                          height: 26,
                          borderRadius: 6,
                          padding: "0 10px",
                          fontSize: 11,
                          backgroundColor: chartDays === d ? "#111827" : "#F1F5F9",
                          color: chartDays === d ? "#FFFFFF" : "#64748B",
                        }}
                      >
                        {d}d
                      </button>
                    ))}
                  </div>
                </div>
                <WellnessChart athlete={selected} days={chartDays} />
                <div className="flex" style={{ gap: 16, marginTop: 8 }}>
                  {[
                    { c: "#3B82F6", l: "Energía" },
                    { c: "#8B5CF6", l: "Sueño" },
                    { c: "#F59E0B", l: "Ánimo" },
                  ].map((x) => (
                    <span key={x.l} className="flex items-center" style={{ gap: 6 }}>
                      <span
                        style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: x.c }}
                      />
                      <span style={{ fontSize: 11, color: "#64748B" }}>{x.l}</span>
                    </span>
                  ))}
                </div>
              </div>

              <div
                style={{
                  backgroundColor: "#FFFFFF",
                  borderRadius: 12,
                  border: "1px solid #E2E8F0",
                  padding: "14px 16px",
                }}
              >
                <div className="flex items-center" style={{ gap: 8, marginBottom: 6 }}>
                  <Sparkles size={15} color="#D97706" />
                  <span className="text-[12px] font-semibold" style={{ color: "#D97706" }}>
                    Sugerencia IA
                  </span>
                </div>
                <p style={{ fontSize: 13, color: "#374151", lineHeight: 1.5 }}>
                  {aiSuggestion[selected.status]}
                </p>
                <p style={{ fontSize: 10, color: "#CBD5E1", fontStyle: "italic", marginTop: 6 }}>
                  Esta sugerencia es orientativa y no reemplaza el criterio del coach.
                </p>
              </div>
            </div>


            <div className="min-h-0 flex-1 overflow-y-auto" style={{ padding: 20 }}>
              <p style={{ fontSize: 12, fontWeight: 500, color: "#374151", marginBottom: 12 }}>
                Últimas sesiones
              </p>
              <div className="flex flex-col" style={{ gap: 8 }}>
                {panelSessions.map((s) => (
                  <div key={s.date} className="flex items-center" style={{ gap: 10 }}>
                    <span
                      className="text-[12px] font-medium"
                      style={{ color: "#111827", width: 80 }}
                    >
                      {s.date}
                    </span>
                    <span className="flex-1 truncate text-[12px]" style={{ color: "#64748B" }}>
                      {s.name}
                    </span>
                    <RpeChip value={s.rpe} />
                    <span
                      style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: s.dot }}
                    />
                  </div>
                ))}
              </div>
            </div>

            <div style={{ padding: "16px 20px", borderTop: "1px solid #E2E8F0" }}>
              <button
                type="button"
                onClick={() =>
                  navigate({ to: "/mensajes", search: { atleta: selected.initials } })
                }
                className="flex w-full items-center justify-center"
                style={{
                  border: "1px solid #E2E8F0",
                  borderRadius: 10,
                  height: 40,
                  fontSize: 13,
                  fontWeight: 500,
                  color: "#374151",
                  gap: 8,
                  backgroundColor: "#FFFFFF",
                }}
              >
                <MessageCircle size={15} />
                Enviar mensaje
              </button>
            </div>
          </aside>
        </>
      )}
    </div>
  );
}
