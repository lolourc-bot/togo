import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Bell, ChevronLeft } from "lucide-react";
import { useUserContext } from "@/lib/user-context";
import { forUser, useNotifs, type NotifCat } from "@/lib/notifications";
import { NotifIcon } from "@/components/togo/NotifIcon";

export const Route = createFileRoute("/notificaciones")({
  head: () => ({
    meta: [
      { title: "Notificaciones · TOGO" },
      { name: "description", content: "Tus avisos de entrenamiento, mensajes e institución en TOGO." },
      { property: "og:title", content: "Notificaciones · TOGO" },
      { property: "og:description", content: "Tus avisos de entrenamiento, mensajes e institución en TOGO." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AthleteNotifs,
});

const FILTERS: ("Todas" | NotifCat)[] = ["Todas", "Entrenamiento", "Mensajes", "Institución"];

function AthleteNotifs() {
  const navigate = useNavigate();
  const ctx = useUserContext();
  const { list, markAll, markRead } = useNotifs("athlete");
  const [f, setF] = useState<(typeof FILTERS)[number]>("Todas");
  const mine = forUser(list, ctx.type);
  const shown = mine.filter((n) => f === "Todas" || n.cat === f);
  const anyUnread = mine.some((n) => n.unread);
  const days = [...new Set(shown.map((n) => n.day))];

  return (
    <div className="flex min-h-screen items-center justify-center" style={{ backgroundColor: "#F1F5F9", padding: 24 }}>
      <div className="relative flex flex-col" style={{ width: 375, height: 812, backgroundColor: "#FFF", borderRadius: 40, boxShadow: "0 20px 60px rgba(0,0,0,0.15)", overflow: "hidden" }}>
        <div className="flex items-center" style={{ padding: "44px 20px 8px", gap: 8 }}>
          <button aria-label="Volver" onClick={() => (history.length > 1 ? history.back() : navigate({ to: "/hoy" }))} style={{ background: "none", border: 0, cursor: "pointer", display: "flex" }}>
            <ChevronLeft size={22} color="#111827" />
          </button>
          <span style={{ fontSize: 20, fontWeight: 800, color: "#111827", flex: 1 }}>Notificaciones</span>
          {anyUnread && <button onClick={markAll} style={{ fontSize: 12, color: "#3B82F6", background: "none", border: 0, cursor: "pointer" }}>Marcar todo leído</button>}
        </div>
        <div className="flex" style={{ padding: "8px 16px", gap: 8, overflowX: "auto", whiteSpace: "nowrap" }}>
          {FILTERS.map((x) => (
            <button key={x} onClick={() => setF(x)} style={{ borderRadius: 20, padding: "5px 14px", fontSize: 12, cursor: "pointer", flexShrink: 0, transition: "all .15s", ...(f === x ? { background: "#111827", color: "#FFF", border: "1px solid #111827" } : { background: "#FFF", color: "#374151", border: "1px solid #E2E8F0" }) }}>{x}</button>
          ))}
        </div>
        <div className="flex flex-1 flex-col" style={{ overflowY: "auto" }}>
          {shown.length === 0 ? (
            <div className="flex flex-col items-center" style={{ padding: "60px 32px", textAlign: "center", gap: 8 }}>
              <Bell size={40} color="#E2E8F0" />
              <div style={{ fontSize: 15, fontWeight: 600, color: "#374151" }}>Todo al día</div>
              <div style={{ fontSize: 12, color: "#94A3B8" }}>No tenés notificaciones nuevas.</div>
            </div>
          ) : days.map((d) => (
            <div key={d}>
              <div style={{ padding: "10px 16px", fontSize: 11, fontWeight: 600, color: "#94A3B8" }}>{d}</div>
              {shown.filter((n) => n.day === d).map((n) => (
                <button key={n.id} onClick={() => markRead(n.id)} className="flex items-start" style={{ width: "100%", textAlign: "left", gap: 12, padding: "14px 16px", border: 0, borderBottom: "1px solid #F8FAFC", position: "relative", background: n.unread ? "#FAFAFE" : "#FFF", cursor: "pointer" }}>
                  {n.unread && <span style={{ position: "absolute", left: 6, top: 20, width: 6, height: 6, borderRadius: "50%", background: "#111827" }} />}
                  <NotifIcon kind={n.kind} size={36} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: n.unread ? 600 : 400, color: "#111827" }}>{n.title}</div>
                    <div style={{ fontSize: 12, color: "#94A3B8", lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{n.body}</div>
                    <div style={{ fontSize: 10, color: "#CBD5E1", marginTop: 4 }}>{n.time}</div>
                  </div>
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
