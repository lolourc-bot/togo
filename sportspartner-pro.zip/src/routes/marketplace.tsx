import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, Dumbbell, Search, Star, User } from "lucide-react";
import { CATEGORIES, COACHES, PROGRAMS, type Category } from "@/lib/marketplace-data";
import { Chip, ChipRow } from "@/components/togo/MarketplaceChips";
import { CoachCard, ProgramCard } from "@/components/togo/MarketplaceCards";

export const Route = createFileRoute("/marketplace")({
  head: () => ({
    meta: [
      { title: "Marketplace · TOGO" },
      {
        name: "description",
        content:
          "Explorá coaches y programas de entrenamiento en el marketplace de TOGO.",
      },
      { property: "og:title", content: "Marketplace · TOGO" },
      {
        property: "og:description",
        content: "Encontrá tu próximo programa o coach en TOGO.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MarketplaceScreen,
});

const TABS = ["Todo", "Programas", "Coaches"] as const;

const FEATURED = [
  {
    kind: "program" as const,
    title: "Fuerza Total 12 Semanas",
    subtitle: "Coach Pablo · 3 días/sem",
    price: "$29.99/mes",
    rating: "4.9",
  },
  {
    kind: "coach" as const,
    title: "Coach Laura Méndez",
    subtitle: "Especialista en movilidad",
    price: "Desde $80/mes",
    rating: "4.8",
  },
];

function SectionHeader({ title, onMore }: { title: string; onMore: () => void }) {
  return (
    <div
      className="flex items-center"
      style={{ padding: "0 16px", marginBottom: 10 }}
    >
      <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: "#111827" }}>
        {title}
      </span>
      <button
        type="button"
        onClick={onMore}
        style={{
          fontSize: 12,
          color: "#94A3B8",
          background: "none",
          border: "none",
          cursor: "pointer",
        }}
      >
        Ver más →
      </button>
    </div>
  );
}

function FeaturedCard({ item }: { item: (typeof FEATURED)[number] }) {
  const Icon = item.kind === "program" ? Dumbbell : User;
  return (
    <div
      style={{
        width: 220,
        flexShrink: 0,
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        border: "1px solid #E2E8F0",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <div
        className="flex items-center justify-center"
        style={{ width: 220, height: 110, backgroundColor: "#F1F5F9" }}
      >
        <Icon size={32} color="#CBD5E1" />
      </div>
      <span
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          backgroundColor: "#111827",
          color: "#FFFFFF",
          fontSize: 9,
          fontWeight: 700,
          letterSpacing: "0.5px",
          padding: "3px 8px",
          borderRadius: "0 0 8px 0",
        }}
      >
        DESTACADO
      </span>
      <div style={{ padding: 12 }}>
        <div
          style={{
            fontSize: 13,
            fontWeight: 600,
            color: "#111827",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {item.title}
        </div>
        <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 2 }}>
          {item.subtitle}
        </div>
        <div
          className="flex items-center justify-between"
          style={{ marginTop: 8 }}
        >
          <span style={{ fontSize: 13, fontWeight: 700, color: "#111827" }}>
            {item.price}
          </span>
          <span className="flex items-center" style={{ gap: 3 }}>
            <Star size={11} color="#D97706" fill="#D97706" />
            <span style={{ fontSize: 11, color: "#64748B" }}>{item.rating}</span>
          </span>
        </div>
      </div>
    </div>
  );
}

function MarketplaceScreen() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Todo");
  const [category, setCategory] = useState<Category>("Todas");

  const showPrograms = tab === "Todo" || tab === "Programas";
  const showCoaches = tab === "Todo" || tab === "Coaches";

  const programs = PROGRAMS.filter(
    (p) => category === "Todas" || p.category === category,
  ).slice(0, 3);
  const coaches = COACHES.filter(
    (c) => category === "Todas" || c.category === category,
  ).slice(0, 3);

  return (
    <div
      className="flex min-h-screen items-center justify-center"
      style={{ backgroundColor: "#F1F5F9", padding: 24 }}
    >
      <div
        className="relative flex flex-col"
        style={{
          width: 375,
          height: 812,
          backgroundColor: "#F8FAFC",
          borderRadius: 40,
          boxShadow: "0 20px 60px rgba(0,0,0,0.15)",
          overflow: "hidden",
        }}
      >
        <div className="flex-1 overflow-y-auto">
          {/* STICKY HEADER — TOP BAR + SEARCH + CATEGORIES + TABS */}
          <div
            style={{
              position: "sticky",
              top: 0,
              zIndex: 10,
              backgroundColor: "#F8FAFC",
            }}
          >
            <div
              className="flex items-center justify-between"
              style={{
                backgroundColor: "#FFFFFF",
                borderBottom: "1px solid #E2E8F0",
                padding: "16px 20px",
              }}
            >
              <button
                type="button"
                aria-label="Volver"
                onClick={() => navigate({ to: "/hoy" })}
              >
                <ChevronLeft size={20} color="#94A3B8" />
              </button>
              <span style={{ fontSize: 16, fontWeight: 600, color: "#111827" }}>
                Marketplace
              </span>
              <span style={{ width: 20 }} />
            </div>

            {/* SEARCH BAR */}
            <div style={{ margin: "12px 16px" }}>
              <div
                className="flex items-center"
                style={{
                  height: 44,
                  backgroundColor: "#FFFFFF",
                  border: "1px solid #E2E8F0",
                  borderRadius: 12,
                  padding: "0 14px",
                }}
              >
                <Search size={16} color="#CBD5E1" />
                <input
                  type="search"
                  className="togo-search"
                  placeholder="Buscar coaches o programas..."
                  aria-label="Buscar coaches o programas"
                  style={{
                    flex: 1,
                    marginLeft: 8,
                    border: "none",
                    outline: "none",
                    fontSize: 13,
                    color: "#111827",
                    backgroundColor: "transparent",
                  }}
                />
              </div>
            </div>

            {/* CATEGORY CHIPS */}
            <div style={{ marginBottom: 12 }}>
              <ChipRow>
                {CATEGORIES.map((c) => (
                  <Chip
                    key={c}
                    label={c}
                    selected={category === c}
                    onClick={() => setCategory(c)}
                  />
                ))}
              </ChipRow>
            </div>

            {/* TABS */}
            <div
              className="flex"
              style={{
                margin: "0 16px 4px",
                backgroundColor: "#F1F5F9",
                borderRadius: 10,
                padding: 3,
              }}
            >
              {TABS.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTab(t)}
                  style={{
                    flex: 1,
                    height: 34,
                    borderRadius: 8,
                    fontSize: 13,
                    fontWeight: 500,
                    textAlign: "center",
                    border: "none",
                    cursor: "pointer",
                    backgroundColor: tab === t ? "#FFFFFF" : "transparent",
                    color: tab === t ? "#111827" : "#94A3B8",
                    boxShadow:
                      tab === t ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
                  }}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* DESTACADOS */}
          {tab === "Todo" && (
            <div style={{ margin: "16px 0 0" }}>
              <div
                style={{
                  fontSize: 13,
                  fontWeight: 600,
                  color: "#111827",
                  padding: "0 16px",
                  marginBottom: 10,
                }}
              >
                Destacados
              </div>
              <div
                className="flex"
                style={{
                  padding: "0 16px",
                  gap: 12,
                  overflowX: "auto",
                  scrollbarWidth: "none",
                }}
              >
                {FEATURED.map((item) => (
                  <FeaturedCard key={item.title} item={item} />
                ))}
              </div>
            </div>
          )}

          {/* PROGRAMAS DESTACADOS */}
          {showPrograms && (
            <div style={{ margin: "20px 0 0" }}>
              <SectionHeader
                title="Programas destacados"
                onMore={() => navigate({ to: "/marketplace-programas" })}
              />
              <div
                className="flex"
                style={{ flexDirection: "column", padding: "0 16px", gap: 10 }}
              >
                {programs.map((p) => (
                  <ProgramCard key={p.name} program={p} />
                ))}
                {programs.length === 0 && (
                  <span style={{ fontSize: 12, color: "#94A3B8" }}>
                    No hay programas en esta categoría.
                  </span>
                )}
              </div>
            </div>
          )}

          {/* COACHES DESTACADOS */}
          {showCoaches && (
            <div style={{ margin: "20px 0 24px" }}>
              <SectionHeader
                title="Coaches destacados"
                onMore={() => navigate({ to: "/marketplace-coaches" })}
              />
              <div
                className="flex"
                style={{ flexDirection: "column", padding: "0 16px", gap: 10 }}
              >
                {coaches.map((c) => (
                  <CoachCard
                    key={c.id}
                    coach={c}
                    onContact={() =>
                      navigate({
                        to: "/chat/$coachId",
                        params: { coachId: c.id },
                      })
                    }
                  />
                ))}
                {coaches.length === 0 && (
                  <span style={{ fontSize: 12, color: "#94A3B8" }}>
                    No hay coaches en esta categoría.
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
