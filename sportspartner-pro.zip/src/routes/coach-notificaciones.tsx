import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Bell } from "lucide-react";
import { Sidebar } from "@/components/togo/Sidebar";
import { TopBar } from "@/components/togo/TopBar";
import { CoachNotifList } from "@/components/togo/CoachNotifList";
import { useNotifs, type NotifCat } from "@/lib/notifications";

export const Route = createFileRoute("/coach-notificaciones")({
  head: () => ({
    meta: [
      { title: "Notificaciones del coach · TOGO" },
      { name: "description", content: "Todas las novedades de tus atletas, mensajes e institución." },
      { property: "og:title", content: "Notificaciones del coach · TOGO" },
      { property: "og:description", content: "Todas las novedades de tus atletas, mensajes e institución." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CoachNotifs,
});

const FILTERS: ("Todas" | NotifCat)[] = ["Todas", "Entrenamiento", "Mensajes", "Institución"];

function CoachNotifs() {
  const { list, markAll, markRead } = useNotifs("coach");
  const [f, setF] = useState<(typeof FILTERS)[number]>("Todas");
  const shown = list.filter((n) => f === "Todas" || n.cat === f);
  return (
    <div className="grid min-h-screen grid-cols-[240px_1fr] bg-background">
      <Sidebar />
      <div className="flex min-h-screen flex-col">
        <TopBar title="Notificaciones" />
        <main className="flex-1 bg-background p-6">
          <div style={{ maxWidth: 720, background: "#FFF", border: "1px solid #E2E8F0", borderRadius: 14, overflow: "hidden" }}>
            <div className="flex items-center" style={{ padding: "14px 16px", borderBottom: "1px solid #E2E8F0", gap: 8 }}>
              <div className="flex" style={{ gap: 8, flex: 1 }}>
                {FILTERS.map((x) => (
                  <button key={x} onClick={() => setF(x)} style={{ borderRadius: 20, padding: "5px 14px", fontSize: 12, cursor: "pointer", ...(f === x ? { background: "#111827", color: "#FFF", border: "1px solid #111827" } : { background: "#FFF", color: "#374151", border: "1px solid #E2E8F0" }) }}>{x}</button>
                ))}
              </div>
              {list.some((n) => n.unread) && <button onClick={markAll} style={{ fontSize: 11, color: "#3B82F6", background: "none", border: 0, cursor: "pointer" }}>Marcar todo leído</button>}
            </div>
            {shown.length ? <CoachNotifList list={shown} onRead={markRead} /> : (
              <div className="flex flex-col items-center" style={{ padding: "60px 32px", gap: 8 }}>
                <Bell size={40} color="#E2E8F0" />
                <div style={{ fontSize: 15, fontWeight: 600, color: "#374151" }}>Todo al día</div>
                <div style={{ fontSize: 12, color: "#94A3B8" }}>No tenés notificaciones nuevas.</div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
