import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, SlidersHorizontal } from "lucide-react";
import {
  PROGRAMS,
  SORTS,
  sortItems,
  type Category,
  type Sort,
} from "@/lib/marketplace-data";
import { Chip, ChipRow } from "@/components/togo/MarketplaceChips";
import { MarketplaceSearchBar } from "@/components/togo/MarketplaceSearchBar";
import { ProgramCard } from "@/components/togo/MarketplaceCards";
import { FilterSheet } from "@/components/togo/MarketplaceFilterSheet";

export const Route = createFileRoute("/marketplace-programas")({
  head: () => ({
    meta: [
      { title: "Todos los programas · TOGO" },
      {
        name: "description",
        content: "Explorá todos los programas de entrenamiento disponibles en TOGO.",
      },
      { property: "og:title", content: "Todos los programas · TOGO" },
      {
        property: "og:description",
        content: "Filtrá programas por duración, precio y especialidad en TOGO.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AllProgramsScreen,
});

function matchesPrice(value: number, price: string | null) {
  if (!price) return true;
  if (price === "Hasta $20") return value <= 20;
  if (price === "$20-$50") return value > 20 && value <= 50;
  return value > 50;
}

function matchesDuration(weeks: number, duration: string | null) {
  if (!duration) return true;
  if (duration === "1-4 sem") return weeks <= 4;
  if (duration === "5-8 sem") return weeks >= 5 && weeks <= 8;
  return weeks > 8;
}

function AllProgramsScreen() {
  const navigate = useNavigate();
  const [sort, setSort] = useState<Sort>("Relevancia");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [duration, setDuration] = useState<string | null>(null);
  const [price, setPrice] = useState<string | null>(null);
  const [category, setCategory] = useState<Category>("Todas");
  const [query, setQuery] = useState("");

  const results = sortItems(
    PROGRAMS.filter(
      (p) =>
        (category === "Todas" || p.category === category) &&
        (query.trim() === "" ||
          p.name.toLowerCase().includes(query.trim().toLowerCase()) ||
          p.meta.toLowerCase().includes(query.trim().toLowerCase())) &&
        matchesPrice(p.priceValue, price) &&
        matchesDuration(p.weeks, duration),
    ),
    sort,
  ).slice(0, 6);

  return (
    <div
      className="flex min-h-screen items-center justify-center"
      style={{ backgroundColor: "#F1F5F9", padding: 24 }}
    >
      <div
        className="relative flex flex-col"
        style={{
          width: 375,
          height: 812,
          backgroundColor: "#F8FAFC",
          borderRadius: 40,
          boxShadow: "0 20px 60px rgba(0,0,0,0.15)",
          overflow: "hidden",
          animation: "togo-slide-in 220ms ease-out",
        }}
      >
        <div className="flex-1 overflow-y-auto">
          <div
            style={{
              position: "sticky",
              top: 0,
              zIndex: 10,
              backgroundColor: "#F8FAFC",
            }}
          >
            <div
              className="flex items-center justify-between"
              style={{
                backgroundColor: "#FFFFFF",
                borderBottom: "1px solid #E2E8F0",
                padding: "16px 20px",
              }}
            >
              <button
                type="button"
                aria-label="Volver"
                onClick={() => navigate({ to: "/marketplace" })}
              >
                <ChevronLeft size={20} color="#94A3B8" />
              </button>
              <span style={{ fontSize: 16, fontWeight: 600, color: "#111827" }}>
                Todos los programas
              </span>
              <button
                type="button"
                aria-label="Filtros"
                onClick={() => setFiltersOpen(true)}
              >
                <SlidersHorizontal size={20} color="#94A3B8" />
              </button>
            </div>

            <MarketplaceSearchBar
              placeholder="Buscar programas..."
              value={query}
              onChange={setQuery}
            />

            <div style={{ padding: "0 0 12px" }}>
              <ChipRow>
                {SORTS.map((s) => (
                  <Chip
                    key={s}
                    label={s}
                    selected={sort === s}
                    onClick={() => setSort(s)}
                  />
                ))}
              </ChipRow>
            </div>
          </div>

          <div
            className="flex"
            style={{
              flexDirection: "column",
              padding: "4px 16px 24px",
              gap: 10,
            }}
          >
            {results.map((p) => (
              <ProgramCard key={p.name} program={p} />
            ))}
            {results.length === 0 && (
              <span style={{ fontSize: 12, color: "#94A3B8" }}>
                No hay programas con estos filtros.
              </span>
            )}
          </div>
        </div>

        <FilterSheet
          open={filtersOpen}
          onClose={() => setFiltersOpen(false)}
          showDuration
          duration={duration}
          setDuration={setDuration}
          price={price}
          setPrice={setPrice}
          category={category}
          setCategory={setCategory}
          onClear={() => {
            setDuration(null);
            setPrice(null);
            setCategory("Todas");
          }}
        />
      </div>
    </div>
  );
}
