import { Lock } from "lucide-react";
import { Link as RLink } from "@tanstack/react-router";
import { useUserContext } from "@/lib/user-context";
import { PhoneFrame } from "@/components/togo/Entrenamiento";
import { useHasCoach } from "@/components/togo/AthleteBottomNav";
import { AthleteBottomNav } from "@/components/togo/AthleteBottomNav";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  ChevronDown,
  Home,
  Info,
  MessageCircle,
  TrendingUp,
  User,
} from "lucide-react";

export const Route = createFileRoute("/progreso")({
  head: () => ({
    meta: [
      { title: "Progreso del atleta · TOGO" },
      {
        name: "description",
        content:
          "Adherencia, racha, evolución de pesos e historial de sesiones del atleta en las últimas 4 semanas.",
      },
      { property: "og:title", content: "Progreso del atleta · TOGO" },
      {
        property: "og:description",
        content:
          "Seguimiento de adherencia, evolución de cargas e historial de entrenamientos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProgressScreen,
});

const PERIODS = ["1 semana", "4 semanas", "3 meses"];

const EXERCISES = ["Sentadilla", "Press banca", "Peso muerto", "Curl bíceps"];

type Session = { name: string; meta: string; rpe: number };

const PERIOD_DATA: Record<
  string,
  {
    label: string;
    chips: { number: string; label: string }[];
    axis: string[];
    base: number[];
    history: Session[];
  }
> = {
  "1 semana": {
    label: "Última semana",
    chips: [
      { number: "100%", label: "ADHERENCIA" },
      { number: "3", label: "SESIONES" },
      { number: "🔥 6", label: "RACHA" },
    ],
    axis: ["L", "M", "J", "S"],
    base: [95, 97, 95, 98, 97, 100, 99, 102],
    history: [
      { name: "Fuerza", meta: "Lun 25/8 · 50 min · 4 bloques", rpe: 6 },
      { name: "Movilidad", meta: "Mié 27/8 · 24 min · 1 bloque", rpe: 4 },
      { name: "Fuerza", meta: "Vie 29/8 · 57 min · 4 bloques", rpe: 8 },
    ],
  },
  "4 semanas": {
    label: "Últimas 4 semanas",
    chips: [
      { number: "85%", label: "ADHERENCIA" },
      { number: "14", label: "SESIONES" },
      { number: "🔥 6", label: "RACHA" },
    ],
    axis: ["S1", "S2", "S3", "S4"],
    base: [82, 85, 84, 88, 87, 90, 92, 95],
    history: [
      { name: "Fuerza", meta: "Lun 18/8 · 54 min · 4 bloques", rpe: 7 },
      { name: "Movilidad", meta: "Mié 20/8 · 22 min · 1 bloque", rpe: 4 },
      { name: "Fuerza", meta: "Jue 21/8 · 61 min · 4 bloques", rpe: 9 },
      { name: "Fuerza", meta: "Lun 25/8 · 50 min · 4 bloques", rpe: 6 },
    ],
  },
  "3 meses": {
    label: "Últimos 3 meses",
    chips: [
      { number: "78%", label: "ADHERENCIA" },
      { number: "38", label: "SESIONES" },
      { number: "🔥 6", label: "RACHA" },
    ],
    axis: ["M1", "M2", "M3"],
    base: [70, 74, 73, 78, 80, 83, 88, 95],
    history: [
      { name: "Fuerza", meta: "Mar 10/6 · 48 min · 3 bloques", rpe: 8 },
      { name: "Movilidad", meta: "Jue 26/6 · 20 min · 1 bloque", rpe: 3 },
      { name: "Fuerza", meta: "Lun 14/7 · 56 min · 4 bloques", rpe: 7 },
      { name: "Potencia", meta: "Vie 25/7 · 44 min · 3 bloques", rpe: 9 },
      { name: "Fuerza", meta: "Jue 21/8 · 61 min · 4 bloques", rpe: 9 },
      { name: "Fuerza", meta: "Lun 25/8 · 50 min · 4 bloques", rpe: 6 },
    ],
  },
};

const EXERCISE_DATA: Record<string, number[]> = {
  Sentadilla: [82, 85, 84, 88, 87, 90, 92, 95],
  "Press banca": [65, 67, 66, 70, 69, 72, 73, 75],
  "Peso muerto": [100, 103, 102, 107, 108, 110, 112, 115],
  "Curl bíceps": [28, 29, 29, 30, 31, 31, 32, 33],
};

function rmSeries(period: string, exercise: string) {
  const base = PERIOD_DATA[period]!.base;
  if (period === "4 semanas") return EXERCISE_DATA[exercise]!;
  const ref = EXERCISE_DATA["Sentadilla"]!;
  const target = EXERCISE_DATA[exercise]!;
  const ratio = target[target.length - 1]! / ref[ref.length - 1]!;
  return base.map((v) => Math.round(v * ratio));
}

const TABS = [
  { icon: Home, label: "Inicio", to: "/hoy" },
  { icon: MessageCircle, label: "Chat", to: "/chat", unread: true },
  { icon: TrendingUp, label: "Progreso", to: "/progreso" },
  { icon: User, label: "Perfil", to: "/perfil" },
];

function Dropdown({
  value,
  options,
  onSelect,
  small,
}: {
  value: string;
  options: string[];
  onSelect: (v: string) => void;
  small?: boolean;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ position: "relative" }}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex items-center"
        style={{
          gap: 4,
          fontSize: small ? 11 : 12,
          fontWeight: 500,
          color: "#64748B",
          backgroundColor: small ? "#F8FAFC" : "#FFFFFF",
          border: "1px solid #E2E8F0",
          borderRadius: small ? 8 : 20,
          padding: small ? "4px 8px" : "6px 12px",
          cursor: "pointer",
        }}
      >
        {value}
        <ChevronDown size={small ? 11 : 12} color="#94A3B8" />
      </button>
      {open && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 4px)",
            right: 0,
            zIndex: 20,
            backgroundColor: "#FFFFFF",
            border: "1px solid #E2E8F0",
            borderRadius: 10,
            boxShadow: "0 8px 20px rgba(0,0,0,0.08)",
            overflow: "hidden",
            minWidth: 110,
          }}
        >
          {options.map((opt) => (
            <button
              key={opt}
              type="button"
              onClick={() => {
                onSelect(opt);
                setOpen(false);
              }}
              className="flex w-full items-center"
              style={{
                padding: "8px 12px",
                fontSize: 11,
                fontWeight: opt === value ? 600 : 400,
                color: opt === value ? "#111827" : "#64748B",
                background: "none",
                border: "none",
                cursor: "pointer",
                whiteSpace: "nowrap",
              }}
            >
              {opt}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function WeightChart({ data }: { data: number[] }) {
  const w = 300;
  const h = 100;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * (w - 8) + 4;
    const y = h - 12 - ((v - min) / span) * (h - 26);
    return [x, y] as const;
  });
  const line = pts.map(([x, y], i) => `${i === 0 ? "M" : "L"} ${x} ${y}`).join(" ");
  const lastPt = pts[pts.length - 1]!;
  const firstPt = pts[0]!;
  const area = `${line} L ${lastPt[0]} ${h} L ${firstPt[0]} ${h} Z`;

  return (
    <div>
      <svg
        viewBox={`0 0 ${w} ${h}`}
        style={{ width: "100%", height: 100, display: "block" }}
        preserveAspectRatio="none"
      >
        <path d={area} fill="rgba(17,24,39,0.05)" />
        <path
          d={line}
          fill="none"
          stroke="#111827"
          strokeWidth={2}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {pts.map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r={2.5} fill="#111827" />
        ))}
      </svg>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: 6,
        }}
      >
        <span style={{ fontSize: 10, color: "#94A3B8", textAlign: "left" }}>
          {data[0]} kg
        </span>
        <span style={{ fontSize: 10, color: "#94A3B8", textAlign: "right" }}>
          {data[data.length - 1]} kg
        </span>
      </div>
    </div>
  );
}

function ProgressScreen() {
  const ctx = useUserContext();
  const hasCoach = useHasCoach();
  if (ctx.type === "gym_member" && !hasCoach) {
    return (
      <PhoneFrame>
        <div className="flex flex-1 flex-col items-center justify-center" style={{ padding: "40px 24px" }}>
          <Lock size={32} color="#CBD5E1" />
          <div style={{ fontSize: 13, color: "#94A3B8", textAlign: "center", marginTop: 12 }}>El progreso estará disponible una vez que tengas un coach asignado.</div>
          <RLink to="/hoy" style={{ fontSize: 12, color: "#3B82F6", marginTop: 8 }}>Solicitar coach</RLink>
        </div>
        <AthleteBottomNav active="Progreso" />
      </PhoneFrame>
    );
  }
  return <ProgressContent />;
}

function ProgressContent() {
  const [period, setPeriod] = useState("4 semanas");
  const [exercise, setExercise] = useState("Sentadilla");
  const pdata = PERIOD_DATA[period]!;
  const series = rmSeries(period, exercise);
  const firstVal = series[0]!;
  const lastVal = series[series.length - 1]!;
  const delta = lastVal - firstVal;


  return (
    <div
      className="flex min-h-screen items-center justify-center"
      style={{ backgroundColor: "#F1F5F9", padding: 24 }}
    >
      <div
        className="relative flex flex-col"
        style={{
          width: 375,
          height: 812,
          backgroundColor: "#F8FAFC",
          borderRadius: 40,
          boxShadow: "0 20px 60px rgba(0,0,0,0.15)",
          overflow: "hidden",
        }}
      >
        <div className="flex-1 overflow-y-auto">
          {/* TOP BAR */}
          <div
            className="flex items-center justify-between"
            style={{ padding: "16px 20px 0" }}
          >
            <h1 style={{ fontSize: 18, fontWeight: 600, color: "#111827", margin: 0 }}>
              Progreso
            </h1>
            <Dropdown value={period} options={PERIODS} onSelect={setPeriod} />
          </div>

          {/* SECTION 1 — ADHERENCIA Y RACHA */}
          <div
            style={{
              margin: "16px 16px 0",
              backgroundColor: "#FFFFFF",
              border: "1px solid #E2E8F0",
              borderRadius: 14,
              padding: 16,
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center" style={{ gap: 4, position: "relative" }}>
                <h2 style={{ fontSize: 13, fontWeight: 600, color: "#111827", margin: 0 }}>
                  Adherencia
                </h2>
                <span
                  style={{ display: "inline-flex", position: "relative" }}
                  className="togo-info-wrap"
                >
                  <Info size={13} color="#CBD5E1" />
                  <span className="togo-info-tip">
                    De cada 10 sesiones que te manda el coach, ¿cuántas
                    completás? 85% = 8 o 9 de 10.
                  </span>
                </span>
              </div>
              <span style={{ fontSize: 11, color: "#94A3B8" }}>{pdata.label}</span>
            </div>

            <div className="flex" style={{ gap: 10, marginTop: 12 }}>
              {pdata.chips.map((c) => ({
                ...c,
                tip:
                  c.label === "RACHA"
                    ? "Entrenamientos seguidos sin faltar ninguno."
                    : "",
              })).map((chip) => (
                <div
                  key={chip.label}
                  className="flex flex-1 flex-col items-center justify-center"
                  style={{
                    backgroundColor: "#F8FAFC",
                    borderRadius: 10,
                    padding: "10px 14px",
                  }}
                >
                  <span
                    style={{
                      fontSize: 20,
                      fontWeight: 700,
                      color: "#111827",
                      lineHeight: 1.1,
                      whiteSpace: "nowrap",
                    }}
                  >
                    {chip.number}
                  </span>
                  <div
                    className="flex items-center"
                    style={{ gap: 4, marginTop: 2, position: "relative" }}
                  >
                    <span
                      style={{
                        fontSize: 10,
                        fontWeight: 500,
                        color: "#94A3B8",
                        textTransform: "uppercase",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {chip.label}
                    </span>
                    {chip.tip && (
                      <span
                        style={{ display: "inline-flex", position: "relative" }}
                        className="togo-info-wrap"
                      >
                        <Info size={11} color="#CBD5E1" />
                        <span className="togo-info-tip togo-info-tip--left">
                          {chip.tip}
                        </span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

          </div>

          {/* SECTION 2 — EVOLUCIÓN DE RM */}
          <div
            style={{
              margin: "12px 16px 0",
              backgroundColor: "#FFFFFF",
              border: "1px solid #E2E8F0",
              borderRadius: 14,
              padding: 16,
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center" style={{ gap: 4 }}>
                <h2 style={{ fontSize: 13, fontWeight: 600, color: "#111827", margin: 0 }}>
                  Evolución de RM
                </h2>
                <span
                  style={{ display: "inline-flex", position: "relative" }}
                  className="togo-info-wrap"
                >
                  <Info size={11} color="#CBD5E1" />
                  <span className="togo-info-tip">
                    El RM (repetición máxima) es el peso máximo que podés mover
                    en una sola repetición. Se calcula a partir de tus series
                    registradas.
                  </span>
                </span>
              </div>
              <Dropdown
                small
                value={exercise}
                options={EXERCISES}
                onSelect={setExercise}
              />
            </div>

            <div style={{ marginTop: 12 }}>
              <WeightChart data={series} />
            </div>

            <div className="flex" style={{ marginTop: 6 }}>
              {pdata.axis.map((a) => (
                <span
                  key={a}
                  className="flex-1 text-center"
                  style={{ fontSize: 10, color: "#94A3B8" }}
                >
                  {a}
                </span>
              ))}
            </div>

            <div className="flex items-center" style={{ gap: 4, marginTop: 8 }}>
              <TrendingUp size={12} color="#16A34A" />
              <span style={{ fontSize: 12, fontWeight: 600, color: "#16A34A" }}>
                +{delta} kg de RM en {period === "1 semana" ? "1 semana" : period}
              </span>
            </div>
          </div>

          {/* SECTION 3 — HISTORIAL */}
          <div style={{ margin: "12px 16px 16px" }}>
            <div
              className="flex items-center justify-between"
              style={{ padding: "0 0 10px" }}
            >
              <h2 style={{ fontSize: 13, fontWeight: 600, color: "#111827", margin: 0 }}>
                Historial
              </h2>
              <button
                type="button"
                style={{
                  fontSize: 11,
                  color: "#94A3B8",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  padding: 0,
                }}
              >
                Ver todo →
              </button>
            </div>

            <div className="flex flex-col" style={{ gap: 8 }}>
              {pdata.history.map((s, i) => {
                return (
                  <div
                    key={i}
                    className="flex items-center"
                    style={{
                      backgroundColor: "#FFFFFF",
                      border: "1px solid #E2E8F0",
                      borderRadius: 12,
                      padding: "12px 14px",
                    }}
                  >
                    <div className="flex flex-col" style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>
                        {s.name}
                      </span>
                      <span
                        style={{
                          fontSize: 11,
                          color: "#94A3B8",
                          marginTop: 2,
                          whiteSpace: "nowrap",
                        }}
                      >
                        {s.meta}
                      </span>
                    </div>
                    <div
                      className="flex items-center"
                      style={{
                        gap: 4,
                        backgroundColor: "#F1F5F9",
                        borderRadius: 20,
                        padding: "3px 10px",
                        flexShrink: 0,
                      }}
                    >
                      <span
                        style={{
                          fontSize: 9,
                          fontWeight: 500,
                          color: "#94A3B8",
                          whiteSpace: "nowrap",
                        }}
                      >
                        RPE
                      </span>
                      <span
                        style={{
                          fontSize: 12,
                          fontWeight: 700,
                          color: "#111827",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {s.rpe}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <AthleteBottomNav active="Progreso" />
      </div>
    </div>
  );
}
