import { createFileRoute } from "@tanstack/react-router";
import { AthleteBottomNav } from "@/components/togo/AthleteBottomNav";
import { setTimerSlot } from "@/components/togo/AthleteTimer";

export const Route = createFileRoute("/timer")({
  head: () => ({
    meta: [
      { title: "Temporizador — TOGO" },
      { name: "description", content: "Cronómetro, cuenta regresiva, AMRAP, TABATA y EMOM para tus entrenamientos." },
      { property: "og:title", content: "Temporizador — TOGO" },
      { property: "og:description", content: "Todos los timers de entrenamiento en un solo lugar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TimerPage,
});

function TimerPage() {
  return (
    <div className="flex min-h-screen items-center justify-center" style={{ backgroundColor: "#F1F5F9", padding: 24 }}>
      <div className="relative flex flex-col" style={{ width: 375, height: 812, backgroundColor: "#FFFFFF", borderRadius: 40, boxShadow: "0 20px 60px rgba(0,0,0,0.15)", overflow: "hidden" }}>
        <div ref={setTimerSlot} className="relative min-h-0 flex-1" style={{ paddingTop: 28 }} />
        <AthleteBottomNav active="Timer" />
      </div>
    </div>
  );
}
