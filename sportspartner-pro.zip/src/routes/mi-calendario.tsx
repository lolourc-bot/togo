import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { AthleteBottomNav } from "@/components/togo/AthleteBottomNav";
import { useMyCoachRequest } from "@/components/togo/CoachPlanRequest";

export const Route = createFileRoute("/mi-calendario")({
  head: () => ({
    meta: [
      { title: "Mi calendario — TOGO" },
      { name: "description", content: "Tus sesiones de entrenamiento del mes, planificadas por tu coach." },
      { property: "og:title", content: "Mi calendario — TOGO" },
      { property: "og:description", content: "Mirá todas tus sesiones del mes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CalendarPage,
});

const MONTHS = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
const SESSIONS: Record<number, string> = { 1: "Tren inferior", 3: "Tren superior", 4: "Fuerza", 6: "Acondicionamiento", 8: "Tren inferior", 10: "Tren superior", 11: "Fuerza", 13: "Movilidad", 15: "Tren inferior", 17: "Tren superior", 18: "Fuerza", 22: "Tren inferior", 24: "Tren superior", 25: "Fuerza", 27: "Acondicionamiento", 29: "Tren inferior" };

function CalendarPage() {
  const myReq = useMyCoachRequest();
  const [month, setMonth] = useState(8);
  const [sel, setSel] = useState(25);
  const first = (new Date(2026, month, 1).getDay() + 6) % 7;
  const days = new Date(2026, month + 1, 0).getDate();
  const cells = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  return (
    <div className="flex min-h-screen items-center justify-center" style={{ backgroundColor: "#F1F5F9", padding: 24 }}>
      <div className="relative flex flex-col" style={{ width: 375, height: 812, backgroundColor: "#F8FAFC", borderRadius: 40, boxShadow: "0 20px 60px rgba(0,0,0,0.15)", overflow: "hidden" }}>
        <div className="flex-1 overflow-y-auto" style={{ padding: "44px 20px 20px" }}>
          <div className="flex items-center" style={{ marginBottom: 16 }}>
            <span style={{ fontSize: 20, fontWeight: 800, color: "#111827", flex: 1, textTransform: "capitalize" }}>{MONTHS[month]} 2026</span>
            <button aria-label="Mes anterior" onClick={() => setMonth((m) => Math.max(0, m - 1))} style={{ padding: 6 }}><ChevronLeft size={18} color="#94A3B8" /></button>
            <button aria-label="Mes siguiente" onClick={() => setMonth((m) => Math.min(11, m + 1))} style={{ padding: 6 }}><ChevronRight size={18} color="#94A3B8" /></button>
          </div>
          {myReq?.coach && (
            <div style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", borderRadius: 14, padding: 16, marginBottom: 16, display: "flex", gap: 12 }}>
              <span style={{ width: 36, height: 36, borderRadius: "50%", background: "#111827", color: "#FFF", fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{myReq.coach.split(" ").map((w) => w[0]).join("").slice(0, 2)}</span>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#111827" }}>{myReq.coach} · tu coach</div>
                <div style={{ fontSize: 12, color: "#64748B", marginTop: 3, lineHeight: 1.5 }}>{myReq.welcome || `¡Hola! Soy ${myReq.coach}. Esta semana empezamos con una evaluación para armar tu plan.`}</div>
              </div>
            </div>
          )}
          <div className="grid" style={{ gridTemplateColumns: "repeat(7, 1fr)", gap: 4, background: "#FFFFFF", border: "1px solid #E2E8F0", borderRadius: 14, padding: 10 }}>
            {["L", "M", "X", "J", "V", "S", "D"].map((d) => <span key={d} style={{ fontSize: 10, color: "#94A3B8", textAlign: "center", fontWeight: 600 }}>{d}</span>)}
            {cells.map((d, i) => d ? (
              <button key={i} onClick={() => setSel(d)} className="flex flex-col items-center" style={{ height: 40, borderRadius: 10, background: d === sel ? "#111827" : "transparent", color: d === sel ? "#FFFFFF" : "#111827", fontSize: 13, fontWeight: 600, justifyContent: "center", gap: 3 }}>
                {d}
                <span style={{ width: 4, height: 4, borderRadius: "50%", background: SESSIONS[d] ? (d === sel ? "#FFFFFF" : "#22C55E") : "transparent" }} />
              </button>
            ) : <span key={i} />)}
          </div>
          <div style={{ marginTop: 16, background: "#FFFFFF", border: "1px solid #E2E8F0", borderRadius: 14, padding: 16 }}>
            <div style={{ fontSize: 12, color: "#94A3B8" }}>{sel} de {MONTHS[month]}</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: "#111827", marginTop: 4 }}>{SESSIONS[sel] ?? "Día de descanso"}</div>
            {SESSIONS[sel] ? <div style={{ fontSize: 12, color: "#64748B", marginTop: 2 }}>Coach Pablo · 50 min</div> : null}
          </div>
        </div>
        <AthleteBottomNav active="Calendario" />
      </div>
    </div>
  );
}
