import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  BarChart2,
  BookOpen,
  Dumbbell,
  Edit2,
  Image as ImageIcon,
  MoreHorizontal,
  Plus,
  Star,
  TrendingUp,
  Users,
} from "lucide-react";
import { Sidebar } from "@/components/togo/Sidebar";
import { PricingSection, EditPriceModal } from "@/components/togo/MarketplacePricing";
import { ProgramEditor } from "@/components/togo/ProgramEditor";
import { ProgramStatsPanel } from "@/components/togo/ProgramStatsPanel";

export const Route = createFileRoute("/marketplace-coach")({
  head: () => ({
    meta: [
      { title: "Marketplace del coach · TOGO" },
      {
        name: "description",
        content:
          "Publicá y gestioná tus programas de entrenamiento, suscriptores y precios en TOGO.",
      },
      { property: "og:title", content: "Marketplace del coach · TOGO" },
      {
        property: "og:description",
        content: "Gestioná tus programas publicados, reseñas y suscriptores en TOGO.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MarketplaceCoachScreen,
});

type Status = "Publicado" | "Borrador" | "Archivado";

type Program = {
  id: string;
  name: string;
  category: string;
  duration: string;
  frequency: string;
  status: Status;
  subscribers: number;
  rating: string | null;
  price: string;
  revenue: string;
  payment: string;
};

const PROGRAMS: Program[] = [
  {
    id: "p1",
    name: "Fuerza Total 12 Semanas",
    category: "Fuerza",
    duration: "12 semanas",
    frequency: "3 días/sem",
    status: "Publicado",
    subscribers: 18,
    rating: "4.9",
    price: "$19.99/mes",
    revenue: "= $359/mes",
    payment: "Suscripción mensual",
  },
  {
    id: "p2",
    name: "Definición Verano",
    category: "Cardio",
    duration: "6 semanas",
    frequency: "4 días/sem",
    status: "Publicado",
    subscribers: 12,
    rating: "4.7",
    price: "$14.99/mes",
    revenue: "= $179/mes",
    payment: "Suscripción mensual",
  },
  {
    id: "p3",
    name: "Movilidad y Flexibilidad",
    category: "Movilidad",
    duration: "4 semanas",
    frequency: "2 días/sem",
    status: "Publicado",
    subscribers: 8,
    rating: "4.8",
    price: "$9.99",
    revenue: "= $79/mes",
    payment: "Pago único",
  },
  {
    id: "p4",
    name: "Hipertrofia Avanzada",
    category: "Fuerza",
    duration: "8 semanas",
    frequency: "5 días/sem",
    status: "Borrador",
    subscribers: 0,
    rating: null,
    price: "$24.99/mes",
    revenue: "= $0/mes",
    payment: "Suscripción mensual",
  },
];

const STATUS_STYLE: Record<Status, { bg: string; color: string }> = {
  Publicado: { bg: "#F0FDF4", color: "#16A34A" },
  Borrador: { bg: "#FFFBEB", color: "#D97706" },
  Archivado: { bg: "#F1F5F9", color: "#94A3B8" },
};

const TABS = ["Mis programas", "Reseñas", "Suscriptores"] as const;
const FILTERS = ["Todos", "Publicados", "Borradores", "Archivados"] as const;

const REVIEWS = [
  {
    id: "r1",
    name: "Martina Silva",
    initials: "MS",
    stars: 5,
    text: "El programa está buenísimo, muy bien explicado y con progresión clara.",
    date: "12 ago 2026",
  },
  {
    id: "r2",
    name: "Julián Pérez",
    initials: "JP",
    stars: 4,
    text: "Muy completo. Me hubiese gustado más variantes de movilidad.",
    date: "5 ago 2026",
  },
  {
    id: "r3",
    name: "Camila Ruiz",
    initials: "CR",
    stars: 5,
    text: "Cambió mi rutina por completo, súper recomendable.",
    date: "28 jul 2026",
  },
];

const SUBSCRIBERS = [
  { athlete: "Martina Silva", program: "Fuerza Total 12 Semanas", since: "01 jun 2026", state: "Activo", next: "01 oct 2026" },
  { athlete: "Julián Pérez", program: "Definición Verano", since: "15 jun 2026", state: "Activo", next: "15 sep 2026" },
  { athlete: "Camila Ruiz", program: "Movilidad y Flexibilidad", since: "02 jul 2026", state: "Activo", next: "02 oct 2026" },
  { athlete: "Nicolás Gómez", program: "Fuerza Total 12 Semanas", since: "10 may 2026", state: "Cancelado", next: "—" },
  { athlete: "Sofía Herrera", program: "Definición Verano", since: "21 jul 2026", state: "Activo", next: "21 sep 2026" },
];

const chip = {
  fontSize: 10,
  color: "#64748B",
  background: "#F1F5F9",
  borderRadius: 6,
  padding: "2px 7px",
} as const;

const inputStyle = {
  width: "100%",
  height: 40,
  border: "1px solid #E2E8F0",
  borderRadius: 10,
  padding: "0 12px",
  fontSize: 13,
  color: "#374151",
  background: "#FFFFFF",
} as const;

const labelStyle = {
  display: "block",
  fontSize: 12,
  fontWeight: 500,
  color: "#374151",
  marginBottom: 6,
} as const;

function StatCard({
  label,
  value,
  hint,
  hintColor,
  icon,
}: {
  label: string;
  value: string;
  hint: string;
  hintColor: string;
  icon: React.ReactNode;
}) {
  return (
    <div
      style={{
        flex: 1,
        background: "#FFFFFF",
        borderRadius: 14,
        border: "1px solid #E2E8F0",
        padding: "18px 20px",
        display: "flex",
        flexDirection: "column",
        gap: 4,
        position: "relative",
      }}
    >
      <div style={{ position: "absolute", top: 16, right: 16 }}>{icon}</div>
      <span style={{ fontSize: 12, color: "#94A3B8" }}>{label}</span>
      <span style={{ fontSize: 22, fontWeight: 700, color: "#111827" }}>{value}</span>
      <span style={{ fontSize: 11, color: hintColor }}>{hint}</span>
    </div>
  );
}

function Stars({ n }: { n: number }) {
  return (
    <span style={{ display: "inline-flex", gap: 2 }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={13}
          color={i <= n ? "#D97706" : "#CBD5E1"}
          fill={i <= n ? "#D97706" : "none"}
        />
      ))}
    </span>
  );
}

function ProgramCard({
  p,
  onEdit,
  onStats,
}: {
  p: Program;
  onEdit: () => void;
  onStats: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [priceOpen, setPriceOpen] = useState(false);
  const st = STATUS_STYLE[p.status];
  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 14,
        border: "1px solid #E2E8F0",
        overflow: "hidden",
        transition: "transform 120ms, border-color 120ms",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "#94A3B8";
        e.currentTarget.style.transform = "translateY(-1px)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "#E2E8F0";
        e.currentTarget.style.transform = "none";
      }}
    >
      <div
        style={{
          height: 140,
          background: "#F1F5F9",
          position: "relative",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Dumbbell size={32} color="#CBD5E1" />
        <span
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            background: st.bg,
            color: st.color,
            fontSize: 9,
            fontWeight: 700,
            borderRadius: "0 0 8px 0",
            padding: "3px 8px",
          }}
        >
          {p.status}
        </span>
      </div>

      <div style={{ padding: 14 }}>
        <p
          style={{
            fontSize: 14,
            fontWeight: 600,
            color: "#111827",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {p.name}
        </p>
        <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
          <span style={chip}>{p.category}</span>
          <span style={chip}>{p.duration}</span>
          <span style={chip}>{p.frequency}</span>
        </div>
        <div style={{ display: "flex", gap: 16, marginTop: 10, alignItems: "center" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
            <Users size={13} color="#94A3B8" />
            <span style={{ fontSize: 12, color: "#94A3B8" }}>{p.subscribers} suscriptores</span>
          </span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
            <Star size={13} color="#D97706" fill={p.rating ? "#D97706" : "none"} />
            <span style={{ fontSize: 12, color: "#64748B" }}>{p.rating ?? "Sin reseñas"}</span>
          </span>
        </div>
        <div
          style={{
            marginTop: 6,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <span style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>{p.price}</span>
          <span
            style={{
              fontSize: 11,
              color: "#16A34A",
              background: "#F0FDF4",
              borderRadius: 6,
              padding: "2px 8px",
            }}
          >
            {p.revenue}
          </span>
        </div>
        <div style={{ fontSize: 10, color: "#94A3B8", marginTop: 4 }}>{p.payment}</div>
      </div>

      <div
        style={{
          padding: "10px 14px",
          borderTop: "1px solid #F8FAFC",
          display: "flex",
          gap: 8,
          alignItems: "center",
          position: "relative",
        }}
      >
        <button
          type="button"
          style={{
            flex: 1,
            border: "1px solid #E2E8F0",
            borderRadius: 8,
            height: 34,
            fontSize: 12,
            fontWeight: 500,
            color: "#374151",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
            background: "#FFFFFF",
          }}
          onClick={onEdit}
        >
          <Edit2 size={13} /> Editar
        </button>
        <button
          type="button"
          onClick={onStats}
          style={{
            flex: 1,
            border: "1px solid #E2E8F0",
            borderRadius: 8,
            height: 34,
            fontSize: 12,
            fontWeight: 500,
            color: "#374151",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 6,
            background: "#FFFFFF",
          }}
        >
          <BarChart2 size={13} /> Ver estadísticas
        </button>
        <button
          type="button"
          onClick={() => setMenuOpen((v) => !v)}
          style={{ display: "inline-flex", color: "#CBD5E1" }}
        >
          <MoreHorizontal size={20} />
        </button>
        {menuOpen ? (
          <div
            style={{
              position: "absolute",
              right: 10,
              bottom: 44,
              background: "#FFFFFF",
              border: "1px solid #E2E8F0",
              borderRadius: 10,
              boxShadow: "0 8px 24px rgba(15,23,42,0.08)",
              padding: 4,
              zIndex: 20,
              minWidth: 130,
            }}
          >
            {["Editar precio", "Duplicar", "Archivar", "Eliminar"].map((o) => (
              <button
                key={o}
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  if (o === "Editar precio") setPriceOpen(true);
                }}
                style={{
                  display: "block",
                  width: "100%",
                  textAlign: "left",
                  fontSize: 13,
                  color: o === "Eliminar" ? "#EF4444" : "#374151",
                  padding: "8px 10px",
                  borderRadius: 8,
                  whiteSpace: "nowrap",
                }}
              >
                {o}
              </button>
            ))}
          </div>
        ) : null}
      </div>
      {priceOpen ? <EditPriceModal program={p} onClose={() => setPriceOpen(false)} /> : null}
    </div>
  );
}

function CreateProgramModal({
  onClose,
  onCreate,
}: {
  onClose: () => void;
  onCreate: (name: string) => void;
}) {
  const [name, setName] = useState("");

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.35)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 60,
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: 520,
          background: "#FFFFFF",
          borderRadius: 16,
          padding: 28,
          maxHeight: "88vh",
          overflowY: "auto",
        }}
      >
        <h2 style={{ fontSize: 16, fontWeight: 700, color: "#111827" }}>Nuevo programa</h2>
        <p style={{ fontSize: 13, color: "#94A3B8", marginTop: 4, marginBottom: 20 }}>
          Definí las características principales. Después podés completar el detalle.
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 20 }}>
          <div>
            <label style={labelStyle}>Nombre del programa</label>
            <input
              style={inputStyle}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej: Fuerza Total 12 Semanas"
            />
          </div>
          <div>
            <label style={labelStyle}>Descripción breve</label>
            <textarea
              style={{ ...inputStyle, height: 72, padding: 10, resize: "none" }}
              placeholder="Una línea que resuma de qué se trata."
            />
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <div style={{ flex: 1 }}>
              <label style={labelStyle}>Categoría</label>
              <select style={inputStyle} defaultValue="Fuerza">
                {["Fuerza", "Cardio", "Movilidad", "Crossfit", "Rehabilitación"].map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </div>
            <div style={{ flex: 1 }}>
              <label style={labelStyle}>Duración</label>
              <select style={inputStyle} defaultValue="12 semanas">
                {["4 semanas", "6 semanas", "8 semanas", "12 semanas"].map((d) => (
                  <option key={d}>{d}</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label style={labelStyle}>Días por semana</label>
            <select style={inputStyle} defaultValue="3 días/sem">
              {["2 días/sem", "3 días/sem", "4 días/sem", "5 días/sem"].map((d) => (
                <option key={d}>{d}</option>
              ))}
            </select>
          </div>
          <div
            style={{
              height: 120,
              border: "2px dashed #E2E8F0",
              borderRadius: 12,
              background: "#F8FAFC",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
            }}
          >
            <ImageIcon size={24} color="#CBD5E1" />
            <span style={{ fontSize: 13, color: "#94A3B8" }}>Subir imagen de portada</span>
          </div>
        </div>

        <div style={{ height: 1, background: "#F1F5F9", margin: "4px 0 20px" }} />

        <PricingSection showVisibility />

        <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 8 }}>
          <button
            type="button"
            onClick={onClose}
            style={{
              height: 38,
              padding: "0 16px",
              borderRadius: 10,
              border: "1px solid #E2E8F0",
              fontSize: 13,
              color: "#374151",
              background: "#FFFFFF",
            }}
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={() => onCreate(name.trim() || "Programa sin título")}
            style={{
              height: 38,
              padding: "0 16px",
              borderRadius: 10,
              background: "#111827",
              color: "#FFFFFF",
              fontSize: 13,
              fontWeight: 500,
            }}
          >
            Crear programa →
          </button>
        </div>
      </div>
    </div>
  );
}


function MarketplaceCoachScreen() {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Mis programas");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("Todos");
  const [modalOpen, setModalOpen] = useState(false);
  const [programs, setPrograms] = useState<Program[]>(PROGRAMS);
  const [editing, setEditing] = useState<Program | null>(null);
  const [statsFor, setStatsFor] = useState<Program | null>(null);

  const filtered = programs.filter((p) => {
    if (filter === "Todos") return true;
    if (filter === "Publicados") return p.status === "Publicado";
    if (filter === "Borradores") return p.status === "Borrador";
    return p.status === "Archivado";
  });

  if (editing) {
    return (
      <div className="flex min-h-screen" style={{ background: "#F8FAFC" }}>
        <Sidebar active="Marketplace" />
        <ProgramEditor program={editing} onBack={() => setEditing(null)} />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen" style={{ background: "#F8FAFC" }}>
      <Sidebar active="Marketplace" />
      <main style={{ flex: 1, padding: "32px 40px" }}>
        <div style={{ display: "flex", alignItems: "center", marginBottom: 8 }}>
          <h1 style={{ flex: 1, fontSize: 22, fontWeight: 700, color: "#111827" }}>Marketplace</h1>
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            style={{
              background: "#111827",
              color: "#FFFFFF",
              fontSize: 13,
              fontWeight: 500,
              borderRadius: 10,
              padding: "8px 16px",
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
            }}
          >
            <Plus size={14} color="#FFFFFF" /> Publicar programa
          </button>
        </div>
        <p style={{ fontSize: 13, color: "#94A3B8", marginBottom: 24 }}>
          Publicá y gestioná tus programas de entrenamiento.
        </p>

        <div style={{ display: "flex", gap: 16, marginBottom: 28 }}>
          <StatCard
            label="Ingresos del mes"
            value="$1.240"
            hint="+12% vs mes anterior"
            hintColor="#16A34A"
            icon={<TrendingUp size={18} color="#16A34A" />}
          />
          <StatCard
            label="Suscriptores activos"
            value="38"
            hint="3 nuevos esta semana"
            hintColor="#94A3B8"
            icon={<Users size={18} color="#94A3B8" />}
          />
          <StatCard
            label="Programas publicados"
            value="4"
            hint="1 en borrador"
            hintColor="#94A3B8"
            icon={<BookOpen size={18} color="#94A3B8" />}
          />
          <StatCard
            label="Valoración promedio"
            value="4.8 ★"
            hint="21 reseñas"
            hintColor="#94A3B8"
            icon={<Star size={18} color="#D97706" fill="#D97706" />}
          />
        </div>

        <div style={{ borderBottom: "1px solid #E2E8F0", marginBottom: 20 }}>
          <div style={{ display: "flex", gap: 24 }}>
            {TABS.map((t) => {
              const active = t === tab;
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTab(t)}
                  style={{
                    fontSize: 13,
                    fontWeight: 500,
                    color: active ? "#111827" : "#94A3B8",
                    borderBottom: active ? "2px solid #111827" : "2px solid transparent",
                    paddingBottom: 10,
                  }}
                >
                  {t}
                </button>
              );
            })}
          </div>
        </div>

        {tab === "Mis programas" ? (
          <>
            <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
              {FILTERS.map((f) => {
                const active = f === filter;
                return (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFilter(f)}
                    style={{
                      height: 34,
                      borderRadius: 20,
                      padding: "0 14px",
                      fontSize: 13,
                      fontWeight: 500,
                      background: active ? "#111827" : "#FFFFFF",
                      color: active ? "#FFFFFF" : "#64748B",
                      border: active ? "none" : "1px solid #E2E8F0",
                    }}
                  >
                    {f}
                  </button>
                );
              })}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
              {filtered.map((p) => (
                <ProgramCard
                  key={p.id}
                  p={p}
                  onEdit={() => setEditing(p)}
                  onStats={() => setStatsFor(p)}
                />

              ))}
            </div>
            {filtered.length === 0 ? (
              <p style={{ fontSize: 13, color: "#94A3B8" }}>No hay programas en esta categoría.</p>
            ) : null}
          </>
        ) : null}

        {tab === "Reseñas" ? (
          <div
            style={{
              background: "#FFFFFF",
              border: "1px solid #E2E8F0",
              borderRadius: 14,
              overflow: "hidden",
            }}
          >
            {REVIEWS.map((r, i) => (
              <div
                key={r.id}
                style={{
                  display: "flex",
                  gap: 12,
                  padding: 16,
                  borderTop: i === 0 ? "none" : "1px solid #F8FAFC",
                }}
              >
                <span
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: "50%",
                    background: "#F1F5F9",
                    color: "#64748B",
                    fontSize: 12,
                    fontWeight: 600,
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  {r.initials}
                </span>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>{r.name}</span>
                    <Stars n={r.stars} />
                    <span style={{ marginLeft: "auto", fontSize: 11, color: "#94A3B8" }}>{r.date}</span>
                  </div>
                  <p style={{ fontSize: 13, color: "#374151", marginTop: 4 }}>{r.text}</p>
                </div>
              </div>
            ))}
          </div>
        ) : null}

        {tab === "Suscriptores" ? (
          <div
            style={{
              background: "#FFFFFF",
              border: "1px solid #E2E8F0",
              borderRadius: 14,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                display: "flex",
                padding: "0 16px",
                height: 44,
                alignItems: "center",
                background: "#F8FAFC",
                fontSize: 11,
                fontWeight: 600,
                color: "#94A3B8",
              }}
            >
              <span style={{ flex: 1 }}>Atleta</span>
              <span style={{ flex: 1 }}>Programa</span>
              <span style={{ width: 110 }}>Desde</span>
              <span style={{ width: 100 }}>Estado</span>
              <span style={{ width: 130 }}>Próxima facturación</span>
            </div>
            {SUBSCRIBERS.map((s) => (
              <div
                key={s.athlete}
                style={{
                  display: "flex",
                  padding: "0 16px",
                  height: 52,
                  alignItems: "center",
                  borderTop: "1px solid #F8FAFC",
                  fontSize: 13,
                  color: "#374151",
                }}
              >
                <span style={{ flex: 1, fontWeight: 500, color: "#111827" }}>{s.athlete}</span>
                <span style={{ flex: 1 }}>{s.program}</span>
                <span style={{ width: 110 }}>{s.since}</span>
                <span style={{ width: 100 }}>
                  <span
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      borderRadius: 6,
                      padding: "3px 8px",
                      background: s.state === "Activo" ? "#F0FDF4" : "#F1F5F9",
                      color: s.state === "Activo" ? "#16A34A" : "#94A3B8",
                    }}
                  >
                    {s.state}
                  </span>
                </span>
                <span style={{ width: 130 }}>{s.next}</span>
              </div>
            ))}
          </div>
        ) : null}
      </main>

      {modalOpen ? (
        <CreateProgramModal
          onClose={() => setModalOpen(false)}
          onCreate={(name) => {
            const created: Program = {
              id: `p${Date.now()}`,
              name,
              category: "Fuerza",
              duration: "12 semanas",
              frequency: "3 días/sem",
              status: "Borrador",
              subscribers: 0,
              rating: null,
              price: "$19.99/mes",
              revenue: "= $0/mes",
              payment: "Suscripción mensual",
            };
            setPrograms((prev) => [created, ...prev]);
            setModalOpen(false);
            setEditing(created);
          }}
        />
      ) : null}
      {statsFor ? (
        <ProgramStatsPanel programName={statsFor.name} onClose={() => setStatsFor(null)} />
      ) : null}
    </div>
  );
}
