import { toast } from "sonner";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Fragment, useRef, useState } from "react";
import {
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  GripVertical,
  Link2,
  Unlink,
  Pencil,
  Play,
  Plus,
  RefreshCw,
  Settings2,
  Sparkles,
  Timer,
  Trash2,
  Trophy,
  Upload,
  X,
} from "lucide-react";
import { Sidebar } from "@/components/togo/Sidebar";
import { ExercisePickerPanel } from "@/components/togo/ExercisePickerPanel";
import {
  CircuitModal,
  circuitTimerLabel,
  type CircuitConfig,
} from "@/components/togo/CircuitModal";
import type { LibraryExercise } from "@/lib/exercise-data";
import { LAB_SESSIONS } from "@/components/togo/LabSessions";

type SessionSearch = {
  programa?: string;
  sesion?: string;
  ejercicios?: string;
  equipo?: string;
  equipoId?: string;
  fecha?: string;
};

export const Route = createFileRoute("/sesiones/$sessionId")({
  validateSearch: (search: Record<string, unknown>): SessionSearch => ({
    ...(typeof search["programa"] === "string" ? { programa: search["programa"] } : {}),
    ...(typeof search["sesion"] === "string" ? { sesion: search["sesion"] } : {}),
    ...(typeof search["ejercicios"] === "string" ? { ejercicios: search["ejercicios"] } : {}),
    ...(typeof search["equipo"] === "string" ? { equipo: search["equipo"] } : {}),
    ...(typeof search["equipoId"] === "string" ? { equipoId: search["equipoId"] } : {}),
    ...(typeof search["fecha"] === "string" ? { fecha: search["fecha"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Editor de sesión · Fuerza — Jueves | TOGO" },
      {
        name: "description",
        content:
          "Editá la sesión Fuerza — Jueves de Santiago Pérez: ejercicios, series, pesos, descansos e indicaciones.",
      },
      { property: "og:title", content: "Editor de sesión · TOGO" },
      {
        property: "og:description",
        content: "Armá y publicá sesiones de entrenamiento con series, cargas y sugerencias de IA.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SessionEditor,
});

const initialExercises = [
  { name: "Sentadilla trasera", sets: "4 × 8" },
  { name: "Press de banca", sets: "4 × 10" },
  { name: "Peso muerto", sets: "3 × 5" },
  { name: "Hip thrust", sets: "4 × 12" },
];

const initialFinisher: CircuitConfig = {
  name: "Finisher",
  type: "AMRAP",
  summary: "AMRAP · 8:00",
  description:
    "Completá la mayor cantidad de rondas posibles en el tiempo indicado. Mantené buena técnica en cada rep. Anotá cuántas rondas completás al terminar.",
  exercises: [
    { name: "Burpee", reps: "10", weight: "", unit: "kg" },
    { name: "Kettlebell swing", reps: "15", weight: "24", unit: "kg" },
    { name: "Box jump", reps: "10", weight: "", unit: "kg" },
  ],
  tabataAlternate: true,
  emomRepeat: true,
  tabataRepeat: true,
  amrapSeconds: 8 * 60,
  emomInterval: 60,
  emomRounds: 10,
  work: 20,
  rest: 10,
  tabataRounds: 8,
};

const letterAt = (i: number) => String.fromCharCode(65 + i);

function NumInput({
  value,
  onChange,
  allowMax = false,
  style,
  ...rest
}: {
  value: string;
  onChange: (v: string) => void;
  allowMax?: boolean;
  style?: React.CSSProperties;
  placeholder?: string | undefined;
  "aria-label"?: string | undefined;
}) {
  const isMax = value === "MÁX";
  return (
    <input
      {...rest}
      inputMode="numeric"
      value={value}
      className="outline-none"
      style={{
        ...style,
        ...(isMax ? { fontWeight: 400, color: "#111827" } : null),
      }}
      onKeyDown={(e) => {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        const k = e.key;
        if (k.length > 1) return;
        if (allowMax && (k === "m" || k === "M")) {
          e.preventDefault();
          onChange("MÁX");
          return;
        }
        if (!/[0-9.,]/.test(k)) {
          e.preventDefault();
          return;
        }
        if (isMax) {
          e.preventDefault();
          onChange(k === "," ? "." : k);
        }
      }}
      onChange={(e) => {
        const v = e.target.value;
        if (v === "MÁX") return;
        onChange(v.replace(/,/g, ".").replace(/[^0-9.]/g, ""));
      }}
    />
  );
}


function ChainConnector({ onClick }: { onClick: () => void }) {
  return (
    <div className="flex items-center justify-center" style={{ padding: "2px 0" }}>
      <button
        type="button"
        onClick={onClick}
        aria-label="Encadenar ejercicios"
        className="group/chain flex cursor-pointer items-center text-[#CBD5E1] transition-colors hover:text-[#6366F1]"
        style={{ gap: 4 }}
      >
        <Link2 size={14} />
        <span className="text-[11px]">Superset</span>
      </button>

    </div>
  );
}

const initialGroups: number[][] = [[0], [1, 2], [3]];


const weekDays = [
  { label: "LUN", date: "11", status: "completed" },
  { label: "MAR", date: "12", status: "completed" },
  { label: "MIÉ", date: "13", status: "none" },
  { label: "JUE", date: "14", status: "published" },
  { label: "VIE", date: "15", status: "draft" },
  { label: "SÁB", date: "16", status: "empty" },
  { label: "DOM", date: "17", status: "empty" },
];

const dayStyles: Record<string, React.CSSProperties> = {
  completed: { backgroundColor: "#F0FDF4", border: "1px solid #16A34A" },
  published: { backgroundColor: "#FFFBEB", border: "1px solid #D97706" },
  draft: { backgroundColor: "#F8FAFC", border: "1px dashed #CBD5E1" },
  none: { backgroundColor: "#F8FAFC", border: "1px solid #E2E8F0" },
  empty: { backgroundColor: "transparent", border: "1px dashed #E2E8F0" },
};

const repsUnitOptions = ["Reps", "Segundos", "Metros", "Calorías", "Distancia"];
const weightUnitOptions = ["kg", "lb", "% 1RM", "RPE", "Altura (cm)", "Tiempo (min:ss)"];
const extraVarOptions = [
  { value: "RIR", label: "RIR (Reps en reserva)" },
  { value: "RPE", label: "RPE (Esfuerzo percibido)" },
  { value: "Tempo", label: "Tempo (ej: 3-1-2)" },
  { value: "% 1RM", label: "% 1RM" },
];


const restOptions = ["30s", "60s", "90s", "120s", "Custom"];
const microRestOptions = ["15s", "30s", "45s"];

const dayNames: Record<string, string> = {
  "11": "Lunes",
  "12": "Martes",
  "13": "Miércoles",
  "14": "Jueves",
  "15": "Viernes",
  "16": "Sábado",
  "17": "Domingo",
};

type PreviewRow = { block: string; name: string; sets: string; amber?: boolean };
const dayPreview: Record<string, { title: string; rows: PreviewRow[] | null }> = {
  "11": {
    title: "Fuerza",
    rows: [
      { block: "A1", name: "Sentadilla", sets: "4×8" },
      { block: "B1", name: "Press banca", sets: "4×10" },
      { block: "B2", name: "Peso muerto", sets: "3×5" },
      { block: "C1", name: "Hip thrust", sets: "4×12" },
    ],
  },
  "12": {
    title: "Fuerza",
    rows: [
      { block: "A1", name: "Press inclinado", sets: "4×10" },
      { block: "A2", name: "Aperturas", sets: "3×12" },
      { block: "B1", name: "Curl bíceps", sets: "4×12" },
    ],
  },
  "14": {
    title: "Fuerza",
    rows: [
      { block: "A1", name: "Sentadilla", sets: "4×8" },
      { block: "B1", name: "Press banca", sets: "4×10" },
      { block: "B2", name: "Peso muerto", sets: "3×5" },
      { block: "C1", name: "Hip thrust", sets: "4×12" },
    ],
  },
  "15": {
    title: "Fuerza",
    rows: [
      { block: "A1", name: "Press banca", sets: "4×10" },
      { block: "B1", name: "Remo", sets: "4×8" },
      { block: "C1", name: "Curl bíceps", sets: "4×12" },
    ],
  },
  "13": { title: "Sin sesión", rows: null },
  "16": { title: "Sin sesión", rows: null },
  "17": { title: "Sin sesión", rows: null },
};

type ExState = {
  series: { weight: string; reps: string }[];
  notes: string;
  rest: string;
  microRest: string | null;
};

const initialExStates: ExState[] = [
  {
    series: [
      { weight: "80", reps: "8" },
      { weight: "80", reps: "8" },
      { weight: "82.5", reps: "6" },
      { weight: "82.5", reps: "6" },
    ],
    notes: "",
    rest: "90s",
    microRest: null,
  },
  {
    series: [
      { weight: "60", reps: "10" },
      { weight: "60", reps: "10" },
      { weight: "62.5", reps: "10" },
      { weight: "62.5", reps: "10" },
    ],
    notes: "",
    rest: "90s",
    microRest: null,
  },
  {
    series: [
      { weight: "100", reps: "5" },
      { weight: "105", reps: "5" },
      { weight: "110", reps: "3" },
    ],
    notes: "",
    rest: "120s",
    microRest: null,
  },
  {
    series: [
      { weight: "90", reps: "12" },
      { weight: "90", reps: "12" },
      { weight: "95", reps: "10" },
      { weight: "95", reps: "10" },
    ],
    notes: "",
    rest: "90s",
    microRest: null,
  },
];

function SessionEditor() {
  const search = Route.useSearch();
  const params = Route.useParams();
  const navigate = useNavigate();
  const teamMode = Boolean(search.equipo);
  const labSession = teamMode ? null : (LAB_SESSIONS.find((s) => s.id === params.sessionId) ?? null);
  const labMode = labSession !== null;
  const programMode = !teamMode && Boolean(search.programa);
  const templateMode = programMode || labMode || teamMode;
  const programExercises = (search.ejercicios ?? "")
    .split("|")
    .map((n) => n.trim())
    .filter(Boolean)
    .map((name) => ({ name, sets: "3 × 10" }));
  const labExercises = labSession
    ? labSession.exercises.map((e) => ({ name: e.name, sets: `${e.sets} × ${e.reps}` }))
    : [];
  const startExercises = teamMode
    ? []
    : labMode
      ? labExercises
      : programMode
        ? programExercises
        : initialExercises;
  const sesionLabel = search.sesion ?? "";
  const ctxMatch = /Sem\s+(\d+),\s*Día\s+(\d+)/i.exec(sesionLabel);
  const ctxWeek = ctxMatch ? Number(ctxMatch[1]) : 1;
  const ctxDay = ctxMatch ? Number(ctxMatch[2]) : 1;
  const ctxName = labSession ? labSession.name : (sesionLabel.split("—")[0]?.trim() ?? "Sesión");
  const programWeeks = Array.from({ length: Math.max(4, ctxWeek + 1) }, (_, i) => i + 1);
  const programDayLabels = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];
  const programSessionDays = [1, 3, 5];
  const teamDateLabel = (() => {
    if (!search.fecha) return "";
    const [y, m, d] = search.fecha.split("-").map(Number);
    if (!y || !m || !d) return search.fecha;
    const names = [
      "enero",
      "febrero",
      "marzo",
      "abril",
      "mayo",
      "junio",
      "julio",
      "agosto",
      "septiembre",
      "octubre",
      "noviembre",
      "diciembre",
    ];
    return `${d} de ${names[m - 1]} ${y}`;
  })();

  const [teamSessionName, setTeamSessionName] = useState("Nueva sesión");
  const [activeExercise, setActiveExercise] = useState(0);
  const [exercises, setExercises] = useState(startExercises);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [circuitOpen, setCircuitOpen] = useState(false);
  const [editingCircuit, setEditingCircuit] = useState<number | null>(null);
  const [customCircuits, setCustomCircuits] = useState<CircuitConfig[]>(
    labSession
      ? labSession.circuits.map((c) => ({ ...c }))
      : programMode || teamMode
        ? []
        : [initialFinisher],
  );
  const [activeBlockId, setActiveBlockId] = useState<string | null>(null);
  const [confirmDeleteCircuit, setConfirmDeleteCircuit] = useState<number | null>(null);
  const [editingDesc, setEditingDesc] = useState<number | null>(null);
  const circuitRefs = useRef<(HTMLElement | null)[]>([]);
  const [exStates, setExStates] = useState<ExState[]>(
    labSession
      ? labSession.exercises.map((e) => ({
          series: Array.from({ length: Math.max(1, Number(e.sets) || 3) }, () => ({
            weight: e.weight,
            reps: e.reps,
          })),
          notes: "",
          rest: "90s",
          microRest: null,
        }))
      : programMode || teamMode
        ? startExercises.map(() => ({
            series: [
              { weight: "", reps: "10" },
              { weight: "", reps: "10" },
              { weight: "", reps: "10" },
            ],
            notes: "",
            rest: "90s",
            microRest: null,
          }))
        : initialExStates,
  );
  const [previewDay, setPreviewDay] = useState("14");
  const [units, setUnits] = useState(
    startExercises.map(() => ({ reps: "Reps", weight: "kg" })),
  );
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [menuPos, setMenuPos] = useState<{ top: number; right: number } | null>(null);

  const [groups, setGroups] = useState<number[][]>(
    templateMode ? startExercises.map((_, i) => [i]) : initialGroups,
  );
  const [extras, setExtras] = useState<{ name: string; values: string[] }[][]>(
    templateMode
      ? startExercises.map(() => [])
      : [[{ name: "RIR", values: ["3", "3", "2", "2"] }], [], [], []],
  );
  const sectionRefs = useRef<(HTMLElement | null)[]>([]);

  // Dynamic block labels: recalculated from the current grouping, top to bottom.
  const blockLabels: string[] = [];
  groups.forEach((g, gi) => {
    g.forEach((exIdx, pos) => {
      blockLabels[exIdx] = `${letterAt(gi)}${pos + 1}`;
    });
  });
  // Estimación en vivo para el mini calendario.
  const totalExercises =
    exercises.length + customCircuits.reduce((acc, c) => acc + c.exercises.length, 0);
  const circuitMinutes = (c: CircuitConfig) => {
    if (c.type === "AMRAP") return c.amrapSeconds / 60;
    if (c.type === "EMOM") return (c.emomInterval * c.emomRounds) / 60;
    if (c.type === "TABATA")
      return (
        ((c.work + c.rest) * c.tabataRounds * (c.tabataAlternate ? Math.max(1, c.exercises.length) : 1)) /
        60
      );
    return 10;
  };
  const rawMinutes =
    exStates.reduce((acc, st) => acc + st.series.length * 3, 0) +
    customCircuits.reduce((acc, c) => acc + circuitMinutes(c), 0);
  const estimatedMinutes = Math.max(5, Math.round(rawMinutes / 5) * 5);

  const chainGroups = (gi: number) => {
    setGroups((prev) => {
      if (gi < 0 || gi + 1 >= prev.length) return prev;
      const next = prev.map((g) => [...g]);
      const merged = [...next[gi]!, ...next[gi + 1]!];
      next.splice(gi, 2, merged);
      return next;
    });
  };

  const unchainGroup = (gi: number) => {
    setGroups((prev) => {
      const next = prev.map((g) => [...g]);
      const singles = next[gi]!.map((i) => [i]);
      next.splice(gi, 1, ...singles);
      return next;
    });
  };



  const addExerciseFromLibrary = (lib: LibraryExercise) => {
    if (activeBlockId?.startsWith("custom-")) {
      const ci = Number(activeBlockId.slice(7));
      setCustomCircuits((prev) =>
        prev.map((c, i) =>
          i === ci
            ? {
                ...c,
                exercises: [
                  ...c.exercises,
                  { name: lib.name, reps: "", weight: "", unit: "kg" as const },
                ],
              }
            : c,
        ),
      );
      return;
    }
    setExercises((prev) => [...prev, { name: lib.name, sets: "3 × 10" }]);
    setExStates((prev) => [
      ...prev,
      {
        series: [
          { weight: "", reps: "10" },
          { weight: "", reps: "10" },
          { weight: "", reps: "10" },
        ],
        notes: "",
        rest: "90s",
        microRest: null,
      },
    ]);
    setUnits((prev) => [...prev, { reps: "Reps", weight: "kg" }]);
    setExtras((prev) => [...prev, []]);
    setGroups((prev) => {
      const nextIdx = prev.reduce((acc, g) => acc + g.length, 0);
      const next = prev.map((g) => [...g]);
      const activeGroup = next.findIndex((g) => g.includes(activeExercise));
      if (activeGroup >= 0 && next[activeGroup]!.length > 1) {
        next[activeGroup]!.push(nextIdx);
        return next;
      }
      return [...next, [nextIdx]];
    });
  };

  const defaultCircuitDescription = (c: CircuitConfig): string => {
    switch (c.type) {
      case "AMRAP":
        return "Completá la mayor cantidad de rondas posibles en el tiempo indicado. Mantené buena técnica en cada rep. Anotá cuántas rondas completás al terminar.";
      case "EMOM":
        return "Al inicio de cada minuto, completá los ejercicios indicados. El tiempo que sobre en ese minuto es tu descanso. Si no terminás en el minuto, descansá al siguiente y retomá.";
      case "TABATA":
        return `Trabajá ${c.work}s y descansá ${c.rest}s, alternando los ejercicios durante ${c.tabataRounds} rondas. Mantené intensidad alta en los períodos de trabajo.`;
      case "ASAP":
        return "Completá todos los ejercicios de la lista lo más rápido posible, sin sacrificar la técnica. Tu tiempo se registra al terminar la última rep.";
      default:
        return "";
    }
  };

  const submitCircuit = (config: CircuitConfig) => {
    const withDefaults =
      editingCircuit === null && !config.description
        ? { ...config, description: defaultCircuitDescription(config) }
        : config;
    setCustomCircuits((prev) =>
      editingCircuit === null
        ? [...prev, withDefaults]
        : prev.map((c, i) => (i === editingCircuit ? withDefaults : c)),
    );
    setCircuitOpen(false);
    setEditingCircuit(null);
  };

  const setCircuitDescription = (ci: number, description: string) =>
    setCustomCircuits((prev) =>
      prev.map((c, i) => (i === ci ? { ...c, description } : c)),
    );

  const renameCircuit = (ci: number, name: string) =>
    setCustomCircuits((prev) =>
      prev.map((c, i) => (i === ci ? { ...c, name: name.trim() || c.name } : c)),
    );

  const openPickerFor = (blockId: string | null) => {
    setActiveBlockId(blockId);
    setPickerOpen(true);
  };

  const removeExercise = (exIdx: number) => {
    setExercises((prev) => prev.filter((_, i) => i !== exIdx));
    setExStates((prev) => prev.filter((_, i) => i !== exIdx));
    setUnits((prev) => prev.filter((_, i) => i !== exIdx));
    setExtras((prev) => prev.filter((_, i) => i !== exIdx));
    setGroups((prev) =>
      prev
        .map((g) => g.filter((i) => i !== exIdx).map((i) => (i > exIdx ? i - 1 : i)))
        .filter((g) => g.length > 0),
    );
    setActiveExercise((prev) => {
      const total = exercises.length - 1;
      const next = prev > exIdx ? prev - 1 : prev;
      return Math.max(0, Math.min(next, total - 1));
    });
  };


  const removeCircuit = (ci: number) => {
    setCustomCircuits((prev) => prev.filter((_, i) => i !== ci));
    setConfirmDeleteCircuit(null);
    circuitRefs.current.splice(ci, 1);
  };

  const removeCircuitExercise = (ci: number, i: number) => {
    setCustomCircuits((prev) =>
      prev.map((c, x) =>
        x === ci ? { ...c, exercises: c.exercises.filter((_, y) => y !== i) } : c,
      ),
    );
  };

  const inputStyle: React.CSSProperties = {
    backgroundColor: "#F8FAFC",
    border: "1px solid #E2E8F0",
    borderRadius: 6,
    height: 34,
    width: "100%",
    textAlign: "center",
    fontSize: 14,
    color: "#0F172A",
  };



  const updateSerie = (exIdx: number, i: number, key: "weight" | "reps", value: string) => {
    setExStates((prev) =>
      prev.map((e, ei) =>
        ei === exIdx
          ? { ...e, series: e.series.map((s, si) => (si === i ? { ...s, [key]: value } : s)) }
          : e,
      ),
    );
  };

  const addSerie = (exIdx: number) => {
    setExStates((prev) =>
      prev.map((e, ei) => (ei === exIdx ? { ...e, series: [...e.series, { weight: "", reps: "" }] } : e)),
    );
  };

  const removeSerie = (exIdx: number, i: number) => {
    setExStates((prev) =>
      prev.map((e, ei) => (ei === exIdx ? { ...e, series: e.series.filter((_, si) => si !== i) } : e)),
    );
  };

  const setExField = <K extends keyof ExState>(exIdx: number, key: K, value: ExState[K]) => {
    setExStates((prev) => prev.map((e, ei) => (ei === exIdx ? { ...e, [key]: value } : e)));
  };

  const selectExercise = (i: number) => {
    setActiveExercise(i);
    sectionRefs.current[i]?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const renderMenu = (
    key: string,
    options: { value: string; label: string }[],
    current: string,
    onSelect: (v: string) => void,
    trigger: React.ReactNode,
    align: "center" | "right" = "center",
    fixed = false,
  ) => {
    const open = openMenu === key;
    const panelStyle: React.CSSProperties = {
      minWidth: 170,
      backgroundColor: "#FFFFFF",
      border: "1px solid #E2E8F0",
      borderRadius: 8,
      boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
      padding: "4px 0",
    };
    return (
      <span className="relative inline-flex" style={{ overflow: "visible" }}>
        <button
          type="button"
          onClick={(e) => {
            if (open) {
              setOpenMenu(null);
              return;
            }
            if (fixed) {
              const r = e.currentTarget.getBoundingClientRect();
              setMenuPos({ top: r.bottom + 4, right: window.innerWidth - r.right });
            } else {
              setMenuPos(null);
            }
            setOpenMenu(key);
          }}
          className="inline-flex cursor-pointer items-center gap-1"
        >
          {trigger}
        </button>
        {open && (
          <div
            className={fixed ? "z-50" : "absolute z-30"}
            style={
              fixed && menuPos
                ? { position: "fixed", top: menuPos.top, right: menuPos.right, ...panelStyle }
                : {
                    top: "100%",
                    ...(align === "center"
                      ? { left: "50%", transform: "translateX(-50%)" }
                      : { right: 0 }),
                    marginTop: 4,
                    ...panelStyle,
                  }
            }
          >
            {options.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  onSelect(opt.value);
                  setOpenMenu(null);
                }}
                className="flex w-full items-center justify-between gap-3 whitespace-nowrap text-[12px] normal-case hover:bg-[#F8FAFC]"
                style={{ padding: "7px 14px", color: "#0F172A", fontWeight: 400 }}
              >
                {opt.label}
                {opt.value === current && <Check size={12} color="#111827" />}
              </button>
            ))}
          </div>
        )}
      </span>
    );
  };

  const unitTrigger = (label: string) => (
    <span
      className="inline-flex items-center gap-1 text-[11px] font-semibold uppercase"
      style={{ color: "#94A3B8" }}
    >
      {label}
      <ChevronDown size={10} color="#94A3B8" />
    </span>
  );

  const renderUnitHeader = (exIdx: number, col: "reps" | "weight") => {
    const options = (col === "reps"
      ? repsUnitOptions
      : templateMode
        ? weightUnitOptions.filter((o) => o !== "% 1RM")
        : weightUnitOptions
    ).map((o) => ({
      value: o,
      label: o,
    }));
    const current = units[exIdx]![col];
    return (
      <span className="flex flex-1 justify-center">
        {renderMenu(
          `${exIdx}-${col}`,
          options,
          current,
          (v) => setUnits((prev) => prev.map((u, ui) => (ui === exIdx ? { ...u, [col]: v } : u))),
          unitTrigger(current),
        )}
      </span>
    );
  };

  const addExtra = (exIdx: number, name: string) => {
    setExtras((prev) =>
      prev.map((list, li) =>
        li === exIdx
          ? [...list, { name, values: exStates[exIdx]!.series.map(() => "") }]
          : list,
      ),
    );
  };

  const updateExtraName = (exIdx: number, varIdx: number, name: string) => {
    setExtras((prev) =>
      prev.map((list, li) =>
        li === exIdx ? list.map((v, vi) => (vi === varIdx ? { ...v, name } : v)) : list,
      ),
    );
  };

  const updateExtraValue = (exIdx: number, varIdx: number, row: number, value: string) => {
    setExtras((prev) =>
      prev.map((list, li) =>
        li === exIdx
          ? list.map((v, vi) =>
              vi === varIdx
                ? { ...v, values: v.values.map((x, xi) => (xi === row ? value : x)) }
                : v,
            )
          : list,
      ),
    );
  };


  const removeExtra = (exIdx: number, varIdx: number) => {
    setExtras((prev) =>
      prev.map((list, li) => (li === exIdx ? list.filter((_, vi) => vi !== varIdx) : list)),
    );
  };

  const renderExerciseContent = (
    exIdx: number,
    blockLabel: string,
    chained: boolean,
    lastOfGroup: boolean,
  ) => {
    const ex = exercises[exIdx]!;
    const st = exStates[exIdx]!;
    const u = units[exIdx]!;
    const exExtras = extras[exIdx]!;
    return (
      <>
        {/* EXERCISE HEADER */}
        <div className="group flex items-center justify-between" style={{ marginBottom: 12 }}>
          <div className="flex items-center gap-2">
            <span
              className="font-mono text-[11px] font-bold"
              style={{ color: chained ? "#6366F1" : "#94A3B8" }}
            >
              {blockLabel}
            </span>
            <h2
              className="text-[17px] font-bold outline-none"
              style={{ color: "#0F172A" }}
              contentEditable
              suppressContentEditableWarning
              spellCheck={false}
            >
              {ex.name}
            </h2>
            <Pencil
              size={14}
              color="#94A3B8"
              className="opacity-0 transition-opacity group-hover:opacity-100"
            />
          </div>
          <button
            type="button"
            aria-label={`Eliminar ${ex.name}`}
            onClick={() => removeExercise(exIdx)}
            className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#EF4444]"
          >
            <Trash2 size={15} />
          </button>
        </div>

        {/* VIDEO + NOTES */}
        <div className="flex" style={{ gap: 14, marginBottom: 14 }}>
          <button
            type="button"
            className="flex shrink-0 flex-col items-center justify-center gap-1"
            style={{
              width: 120,
              height: 76,
              borderRadius: 8,
              backgroundColor: "#E2E8F0",
            }}
          >
            <Play size={24} color="#94A3B8" />
            <span className="text-[11px]" style={{ color: "#94A3B8" }}>
              Ver video
            </span>
          </button>

          <div className="min-w-0 flex-1">
            <label
              htmlFor={`indicaciones-${exIdx}`}
              className="block text-[12px] font-medium"
              style={{ color: "#64748B", marginBottom: 4 }}
            >
              Indicaciones
            </label>
            <textarea
              id={`indicaciones-${exIdx}`}
              value={st.notes}
              onChange={(e) => setExField(exIdx, "notes", e.target.value)}
              placeholder="Agregá indicaciones o consejos para esta ejercicio..."
              className="w-full resize-none text-[13px] outline-none"
              style={{
                backgroundColor: "#FFFFFF",
                border: "1px solid #E2E8F0",
                borderRadius: 8,
                padding: "8px 10px",
                color: "#0F172A",
                minHeight: 56,
              }}
            />
          </div>
        </div>

        {/* SERIES TABLE */}
        <div
          className="overflow-visible"
          style={{
            backgroundColor: "#FFFFFF",
            border: "1px solid #E2E8F0",
            borderRadius: 8,
            marginBottom: 12,
          }}
        >
          <div
            className="relative flex items-center text-[11px] font-semibold uppercase"
            style={{
              backgroundColor: "#F8FAFC",
              borderBottom: "1px solid #E2E8F0",
              padding: "7px 12px",
              gap: 12,
              color: "#94A3B8",
            }}
          >
            <span style={{ width: 40 }}>Serie</span>
            {renderUnitHeader(exIdx, "reps")}
            {renderUnitHeader(exIdx, "weight")}
            {exExtras.map((v, vi) => (
              <span key={vi} className="flex flex-1 items-center justify-center gap-1">
                {renderMenu(
                  `${exIdx}-extra-${vi}`,
                  extraVarOptions,
                  v.name,
                  (val) => updateExtraName(exIdx, vi, val),
                  unitTrigger(v.name),
                )}
                <button
                  type="button"
                  aria-label={`Quitar columna ${v.name}`}
                  onClick={() => removeExtra(exIdx, vi)}
                  className="text-[#94A3B8] transition-colors hover:text-[#EF4444]"
                >
                  <X size={10} />
                </button>
              </span>
            ))}
            <span className="group/add relative flex justify-center" style={{ width: 20 }}>
              {renderMenu(
                `${exIdx}-addvar`,
                extraVarOptions,
                "",
                (val) => addExtra(exIdx, val),
                <span title="Agregar variable" aria-label="Agregar variable">
                  <Plus size={11} color="#94A3B8" />
                </span>,
                "right",
              )}
            </span>
            <span className="flex-1 text-center">Descanso</span>
            <span style={{ width: 32 }} />

          </div>

          {st.series.map((s, i) => (
            <div
              key={i}
              className="flex items-center"
              style={{ padding: "7px 12px", borderBottom: "1px solid #F8FAFC", gap: 12 }}
            >
              <span style={{ width: 40 }}>
                <span
                  className="flex items-center justify-center rounded-full text-[12px] font-semibold"
                  style={{ width: 22, height: 22, backgroundColor: "#F1F5F9", color: "#64748B" }}
                >
                  {i + 1}
                </span>
              </span>
              <span className="flex-1">
                <NumInput
                  allowMax
                  aria-label={`${u.reps} serie ${i + 1}`}
                  placeholder={u.reps}
                  value={s.reps}
                  onChange={(v) => updateSerie(exIdx, i, "reps", v)}
                  style={inputStyle}
                />
              </span>
              <span className="flex-1">
                <NumInput
                  aria-label={`${u.weight} serie ${i + 1}`}
                  placeholder={u.weight}
                  value={s.weight}
                  onChange={(v) => updateSerie(exIdx, i, "weight", v)}
                  style={inputStyle}
                />
              </span>

              {exExtras.map((v, vi) => (
                <span key={vi} className="flex-1">
                  <input
                    aria-label={`${v.name} serie ${i + 1}`}
                    placeholder={v.name}
                    value={v.values[i] ?? ""}
                    onChange={(e) => updateExtraValue(exIdx, vi, i, e.target.value)}
                    className="outline-none"
                    style={inputStyle}
                  />
                </span>
              ))}
              <span style={{ width: 20 }} />
              <span className="flex flex-1 justify-center">
                <span
                  className="rounded-full text-[11px]"
                  style={{ backgroundColor: "#F1F5F9", color: "#64748B", padding: "3px 8px" }}
                >
                  {st.rest}
                </span>
              </span>
              <span className="flex justify-center" style={{ width: 32 }}>

                <button
                  type="button"
                  aria-label={`Eliminar serie ${i + 1}`}
                  className="text-[#CBD5E1] transition-colors hover:text-[#EF4444]"
                  onClick={() => removeSerie(exIdx, i)}
                >
                  <X size={14} />
                </button>
              </span>
            </div>
          ))}

          <div style={{ padding: "7px 12px", borderTop: "1px solid #F1F5F9" }}>
            <button
              type="button"
              onClick={() => addSerie(exIdx)}
              className="inline-flex items-center gap-1.5 text-[13px] text-[#64748B] transition-colors hover:text-[#111827]"
            >
              <Plus size={13} />
              Agregar serie
            </button>
          </div>
        </div>

        {/* DESCANSO ENTRE SERIES (last of group) */}
        {lastOfGroup && (
          <div className="flex items-center" style={{ gap: 10 }}>
            <span className="text-[12px]" style={{ color: "#64748B" }}>
              Descanso entre series
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              {restOptions.map((opt) => {
                const selected = opt === st.rest;
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setExField(exIdx, "rest", opt)}
                    className="rounded-full text-[11px]"
                    style={{
                      padding: "3px 8px",
                      backgroundColor: selected ? "#111827" : "#F1F5F9",
                      color: selected ? "#FFFFFF" : "#64748B",
                    }}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </>
    );
  };

  // El día actual (14) se deriva del estado vivo del editor.
  const liveRows: PreviewRow[] = [
    ...exercises.map((ex, i) => ({
      block: blockLabels[i] ?? "",
      name: ex.name,
      sets: ex.sets,
    })),
    ...customCircuits.map((c, i) => ({
      block: `C${i + 1}`,
      name: c.name || "Circuito",
      sets: circuitTimerLabel(c),
      amber: true,
    })),
  ];
  const preview =
    previewDay === "14"
      ? { title: dayPreview["14"]!.title, rows: liveRows }
      : (dayPreview[previewDay] ?? dayPreview["14"]!);
  const MAX_PREVIEW_ROWS = 8;
  const previewRows = preview.rows ? preview.rows.slice(0, MAX_PREVIEW_ROWS) : null;
  const previewOverflow = preview.rows ? preview.rows.length - (previewRows?.length ?? 0) : 0;


  return (
    <div className="grid h-screen grid-cols-[240px_1fr] overflow-hidden bg-background">
      <Sidebar />

      <div className="flex h-screen min-w-0 flex-col">
        {/* TOP BAR */}
        <header
          className="flex h-14 shrink-0 items-center justify-between bg-surface"
          style={{ borderBottom: "1px solid #E2E8F0", padding: "0 20px" }}
        >
          <div className="flex min-w-0 items-center" style={{ gap: 6 }}>
            {teamMode ? (
              <>
                <button
                  type="button"
                  className="flex items-center"
                  style={{ gap: 6, cursor: "pointer" }}
                  onClick={() => navigate({ to: "/equipos" })}
                >
                  <ChevronLeft size={16} color="#64748B" />
                  <span className="text-[13px]" style={{ color: "#64748B" }}>
                    Volver al calendario
                  </span>
                </button>
                <span className="text-[13px]" style={{ color: "#E2E8F0" }}>
                  /
                </span>
                <span
                  className="whitespace-nowrap text-[11px] font-medium"
                  style={{ backgroundColor: "#F1F5F9", color: "#374151", padding: "3px 8px", borderRadius: 6 }}
                >
                  {search.equipo}
                </span>
                <input
                  value={teamSessionName}
                  onChange={(e) => setTeamSessionName(e.target.value)}
                  aria-label="Nombre de la sesión"
                  className="truncate text-[13px] font-semibold"
                  style={{
                    color: "#0F172A",
                    border: "none",
                    outline: "none",
                    background: "transparent",
                    minWidth: 160,
                  }}
                />
                {search.fecha ? (
                  <span className="whitespace-nowrap text-[12px]" style={{ color: "#94A3B8" }}>
                    · {teamDateLabel}
                  </span>
                ) : null}
              </>
            ) : labSession ? (
              <>
                <Link to="/lab" className="flex items-center" style={{ gap: 6 }} aria-label="Volver al Lab">
                  <ChevronLeft size={16} color="#64748B" />
                  <span className="text-[13px]" style={{ color: "#64748B" }}>
                    Lab
                  </span>
                </Link>
                <span className="text-[13px]" style={{ color: "#E2E8F0" }}>
                  /
                </span>
                <span
                  className="whitespace-nowrap text-[11px] font-medium"
                  style={{ backgroundColor: "#F1F5F9", color: "#374151", padding: "3px 8px", borderRadius: 6 }}
                >
                  {labSession.category}
                </span>
                <span className="truncate text-[13px] font-semibold" style={{ color: "#0F172A" }}>
                  {labSession.name}
                </span>
              </>
            ) : programMode ? (
              <>
                <button
                  type="button"
                  className="flex items-center"
                  style={{ gap: 6, cursor: "pointer" }}
                  onClick={() => window.history.back()}
                >
                  <ChevronLeft size={16} color="#64748B" />
                  <span className="text-[13px]" style={{ color: "#64748B" }}>
                    Volver al calendario
                  </span>
                </button>
                <span className="text-[13px]" style={{ color: "#E2E8F0" }}>
                  /
                </span>
                <span className="truncate text-[13px] font-semibold" style={{ color: "#0F172A" }}>
                  {search.sesion ?? "Sesión del programa"}
                </span>
              </>
            ) : (
              <>
                <Link
                  to="/atletas/$athleteId"
                  params={{ athleteId: "santiago-perez" }}
                  className="flex items-center"
                  style={{ gap: 6 }}
                  aria-label="Volver al perfil de Santiago Pérez"
                >
                  <ChevronLeft size={16} color="#64748B" />
                  <span className="text-[13px]" style={{ color: "#64748B" }}>
                    Santiago Pérez
                  </span>
                </Link>
                <span className="text-[13px]" style={{ color: "#E2E8F0" }}>
                  /
                </span>
                <span className="truncate text-[13px] font-semibold" style={{ color: "#0F172A" }}>
                  Fuerza — Jueves 14 de agosto
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: "#22C55E" }} />
            <span className="text-[12px]" style={{ color: "#94A3B8" }}>
              Guardado
            </span>
          </div>

          <div className="flex items-center" style={{ gap: 10 }}>
            <button
              type="button"
              className="inline-flex items-center gap-1.5 text-[13px]"
              style={{
                border: "1px solid #E2E8F0",
                color: "#64748B",
                borderRadius: 6,
                padding: "6px 12px",
              }}
            >
              <Eye size={14} />
              Vista previa
            </button>
            <button
              type="button"
              onClick={() => {
                if (!teamMode) { toast.success("Sesión publicada ✓"); return; }
                navigate({
                  to: "/equipos",
                  search: {
                    nueva: teamSessionName.trim() || "Nueva sesión",
                    equipo: search.equipoId ?? "",
                    fecha: search.fecha ?? "",
                    ejercicios: String(exercises.length + customCircuits.length),
                  },
                });
              }}
              className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-white"
              style={{ backgroundColor: "#111827", borderRadius: 6, padding: "6px 16px" }}
            >
              <Upload size={14} />
              {teamMode ? "Guardar sesión" : "Publicar sesión"}
            </button>
          </div>
        </header>

        {/* 3 COLUMNS */}
        <div
          className="grid min-h-0"
          style={{
            gridTemplateColumns: "260px 1fr 240px",
            height: "calc(100vh - 56px)",
            overflow: "hidden",
          }}
        >
          {/* LEFT PANEL */}
          <aside
            className="flex min-h-0 flex-col bg-surface"
            style={{ borderRight: "1px solid #E2E8F0" }}
          >
            <div style={{ padding: 16, borderBottom: "1px solid #E2E8F0" }}>
              <h2 className="text-[13px] font-semibold" style={{ color: "#0F172A" }}>
                Ejercicios
              </h2>
            </div>

            <div
              className="flex min-h-0 flex-1 flex-col overflow-y-auto"
              style={{ padding: 8, gap: 4 }}
            >
              {groups.map((indices) =>
                indices.map((exIdx) => {
                  const ex = exercises[exIdx]!;
                  const active = exIdx === activeExercise;
                  const chained = indices.length > 1;
                  return (
                    <div
                      key={ex.name}
                      role="button"
                      tabIndex={0}
                      onClick={() => selectExercise(exIdx)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") selectExercise(exIdx);
                      }}
                      className="flex cursor-pointer items-center text-left"
                      style={{
                        gap: 8,
                        padding: "8px 10px",
                        borderRadius: 6,
                        backgroundColor: active ? "#F1F5F9" : "transparent",
                      }}
                    >
                      <GripVertical size={14} color="#CBD5E1" />
                      <span
                        className="font-mono text-[11px] font-bold"
                        style={{ color: chained ? "#6366F1" : "#94A3B8" }}
                      >
                        {blockLabels[exIdx]}
                      </span>

                      <span
                        className="flex-1 truncate text-[13px]"
                        style={{ color: "#0F172A", fontWeight: active ? 600 : 400 }}
                      >
                        {ex.name}
                      </span>
                      <span className="text-[11px]" style={{ color: "#94A3B8" }}>
                        {ex.sets}
                      </span>
                      <button
                        type="button"
                        aria-label={`Eliminar ${ex.name}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          removeExercise(exIdx);
                        }}
                        className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#EF4444]"
                      >
                        <Trash2 size={15} />
                      </button>
                      <ChevronRight size={14} color={active ? "#111827" : "#CBD5E1"} />
                    </div>
                  );
                }),
              )}

              {/* CIRCUITOS (incluye Finisher) */}
              {customCircuits.map((c, i) => {
                const timer = circuitTimerLabel(c);
                return (
                  <button
                    key={`nav-${c.name}-${i}`}
                    type="button"
                    onClick={() =>
                      circuitRefs.current[i]?.scrollIntoView({ behavior: "smooth", block: "start" })
                    }
                    className="flex cursor-pointer items-center text-left"
                    style={{ gap: 8, padding: "8px 10px", borderRadius: 6 }}
                  >
                    <GripVertical size={14} color="#CBD5E1" />
                    <span
                      className="font-mono text-[11px] font-bold"
                      style={{ color: "#D97706" }}
                    >
                      C{i + 1}
                    </span>
                    <span
                      className="flex-1 truncate text-[13px]"
                      style={{ color: "#0F172A" }}
                    >
                      {c.name}
                    </span>
                    <span className="text-[11px]" style={{ color: "#94A3B8" }}>
                      {timer || c.type.toUpperCase()}
                    </span>
                  </button>
                );
              })}



            </div>

            <div
              className="flex flex-col"
              style={{ padding: 12, borderTop: "1px solid #E2E8F0", gap: 8 }}
            >
              {["Agregar ejercicio", "Agregar circuito"].map((label) => (
                <button
                  key={label}
                  type="button"
                  onClick={() =>
                    label === "Agregar ejercicio"
                        ? openPickerFor(null)
                        : (setEditingCircuit(null), setCircuitOpen(true))
                  }
                  className="inline-flex w-full items-center justify-center gap-1.5 text-[13px] transition-colors hover:bg-[#F8FAFC]"
                  style={{
                    border: "1px dashed #CBD5E1",
                    backgroundColor: "transparent",
                    color: "#64748B",
                    borderRadius: 6,
                    padding: 8,
                  }}
                >
                  <Plus size={14} />
                  {label}
                </button>
              ))}
            </div>

            {/* MINI CALENDAR + DAY PREVIEW CARD */}
            <div className="shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
              {templateMode ? (
                <div style={{ padding: 12 }}>
                  <h2 className="text-[12px] font-semibold" style={{ color: "#0F172A" }}>
                    {labMode || teamMode ? "Semanas" : "Calendario del programa"}
                  </h2>
                  <div
                    className="grid"
                    style={{
                      gridTemplateColumns: "30px repeat(7, 1fr)",
                      gap: 3,
                      marginTop: 10,
                      alignItems: "center",
                    }}
                  >
                    <span />
                    {programDayLabels.map((d) => (
                      <span
                        key={d}
                        className="text-center text-[9px] font-semibold"
                        style={{ color: "#94A3B8" }}
                      >
                        {d}
                      </span>
                    ))}
                    {programWeeks.map((w) => (
                      <Fragment key={`sem-${w}`}>
                        <span className="text-[10px] font-semibold" style={{ color: "#64748B" }}>
                          S{w}
                        </span>
                        {programDayLabels.map((_, di) => {
                          const day = di + 1;
                          const has = programSessionDays.includes(day);
                          const current = w === ctxWeek && day === ctxDay;
                          return (
                            <span
                              key={`sem-${w}-d-${day}`}
                              aria-label={`Semana ${w} día ${day}`}
                              style={{
                                height: 20,
                                borderRadius: 5,
                                backgroundColor: current
                                  ? "#111827"
                                  : has
                                    ? "#F1F5F9"
                                    : "transparent",
                                border: current
                                  ? "1px solid #111827"
                                  : has
                                    ? "1px solid #E2E8F0"
                                    : "1px dashed #E2E8F0",
                              }}
                            />
                          );
                        })}
                      </Fragment>
                    ))}
                  </div>
                  <p className="text-[11px]" style={{ color: "#94A3B8", marginTop: 8 }}>
                    Sem {ctxWeek} · {programDayLabels[ctxDay - 1]} — {ctxName}
                  </p>
                </div>
              ) : (
                <div style={{ padding: 12 }}>
                  <h2 className="text-[12px] font-semibold" style={{ color: "#0F172A" }}>
                    Semana
                  </h2>
                  <div className="grid grid-cols-7" style={{ gap: 4, marginTop: 10 }}>
                    {weekDays.map((d) => (
                      <div key={d.label} className="flex flex-col items-center" style={{ gap: 4 }}>
                        <span className="text-[9px] font-semibold" style={{ color: "#94A3B8" }}>
                          {d.label}
                        </span>
                        <span className="text-[11px]" style={{ color: "#64748B" }}>
                          {d.date}
                        </span>
                        <span
                          role="button"
                          tabIndex={0}
                          onClick={() => setPreviewDay(d.date)}
                          aria-label={`${dayNames[d.date]} ${d.date}`}
                          className="w-full cursor-pointer transition-opacity"
                          style={{
                            height: 34,
                            borderRadius: 6,
                            outline: previewDay === d.date ? "2px solid #111827" : "none",
                            outlineOffset: -1,
                            ...dayStyles[d.status],
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* DAY PREVIEW CARD */}
              <div
                data-session-exercises={totalExercises}
                data-session-minutes={estimatedMinutes}
                style={{
                  margin: 8,
                  marginTop: 0,
                  backgroundColor: "#FFFFFF",
                  border: "1px solid #E2E8F0",
                  borderRadius: 8,
                  padding: 10,
                  height: 160,
                  overflowY: "auto",
                  boxSizing: "border-box",
                }}
              >
                <div style={{ marginBottom: 6 }}>
                  <div className="text-[11px] font-semibold" style={{ color: "#0F172A" }}>
                    {templateMode
                      ? `Sem ${ctxWeek} · ${programDayLabels[ctxDay - 1]} — ${ctxName}`
                      : `${dayNames[previewDay]} ${previewDay} — ${preview.title}`}
                  </div>
                </div>
                {previewRows ? (
                  <>
                    {previewRows.map((r, ri) => (
                      <div
                        key={`${r.block}-${r.name}-${ri}`}
                        className="flex items-center"
                        style={{ gap: 6, padding: "2px 0" }}
                      >
                        <span
                          className="font-mono text-[10px] font-bold"
                          style={{ color: r.amber ? "#D97706" : "#94A3B8", width: 20 }}
                        >
                          {r.block}
                        </span>
                        <span className="flex-1 text-[11px]" style={{ color: "#0F172A" }}>
                          {r.name}
                        </span>
                        <span className="text-[11px]" style={{ color: "#94A3B8" }}>
                          {r.sets}
                        </span>
                      </div>
                    ))}
                    {previewOverflow > 0 && (
                      <div className="text-[11px]" style={{ color: "#94A3B8", marginTop: 4 }}>
                        +{previewOverflow} más
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-[11px]" style={{ color: "#94A3B8" }}>
                    Sin sesión
                  </div>
                )}

              </div>
            </div>
          </aside>

          {/* CENTER PANEL */}
          <main
            className="min-h-0 min-w-0"
            style={{
              backgroundColor: "#F8FAFC",
              overflowY: "scroll",
              height: "100%",
              boxSizing: "border-box",
              padding: 24,
            }}
          >
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {groups.map((indices, gi) => {
                const groupActive = indices.includes(activeExercise);
                const canChain = gi < groups.length - 1;
                if (indices.length === 1) {
                  const exIdx = indices[0]!;
                  const ex = exercises[exIdx]!;
                  return (
                    <Fragment key={ex.name}>
                      <section
                        ref={(el) => {
                          sectionRefs.current[exIdx] = el;
                        }}
                        style={{
                          scrollMarginTop: 8,
                          backgroundColor: "#FFFFFF",
                          border: "1px solid #E2E8F0",
                          borderRadius: 8,
                          padding: "10px 14px",
                          boxShadow: groupActive ? "0 0 0 2px #111827 inset" : undefined,
                        }}
                      >
                        {renderExerciseContent(exIdx, blockLabels[exIdx]!, false, true)}
                      </section>
                      {canChain && <ChainConnector onClick={() => chainGroups(gi)} />}
                    </Fragment>
                  );
                }
                // chained unified card
                return (
                  <Fragment key={`chained-${gi}`}>
                    <section
                      style={{
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #DDD6FE",
                        borderLeft: "3px solid #6366F1",
                        borderRadius: 8,
                        overflow: "hidden",
                        boxShadow: groupActive ? "0 0 0 2px #6366F1 inset" : undefined,
                      }}
                    >
                      {indices.map((exIdx, pos) => {
                        const ex = exercises[exIdx]!;
                        const st = exStates[exIdx]!;
                        const last = pos === indices.length - 1;
                        return (
                          <div key={ex.name}>
                            <div
                              ref={(el) => {
                                sectionRefs.current[exIdx] = el;
                              }}
                              style={{ scrollMarginTop: 8, padding: "10px 14px" }}
                            >
                              {renderExerciseContent(exIdx, blockLabels[exIdx]!, true, last)}
                            </div>
                            {/* DIVIDER + MICRO-REST CONNECTOR */}
                            {!last && (
                              <div style={{ position: "relative", height: 1, backgroundColor: "#EEF2FF" }}>
                                <div
                                  style={{
                                    position: "absolute",
                                    left: "50%",
                                    top: "50%",
                                    transform: "translate(-50%, -50%)",
                                  }}
                                >
                                  <div
                                    className="flex items-center gap-2"
                                    style={{ backgroundColor: "#FFFFFF", padding: "0 6px" }}
                                  >
                                    {st.microRest === null ? (
                                      <button
                                        type="button"
                                        aria-label="Agregar micro descanso"
                                        onClick={() => setExField(exIdx, "microRest", "15s")}
                                        className="flex cursor-pointer items-center justify-center"
                                      >
                                        <Plus size={14} color="#6366F1" />
                                      </button>
                                    ) : (
                                      <div className="flex items-center gap-1">
                                        {microRestOptions.map((opt) => {
                                          const selected = opt === st.microRest;
                                          return (
                                            <button
                                              key={opt}
                                              type="button"
                                              onClick={() => setExField(exIdx, "microRest", opt)}
                                              className="rounded-full text-[10px]"
                                              style={{
                                                padding: "2px 7px",
                                                backgroundColor: selected ? "#111827" : "#FFFFFF",
                                                color: selected ? "#FFFFFF" : "#64748B",
                                                border: "1px solid #DDD6FE",
                                              }}
                                            >
                                              {opt}
                                            </button>
                                          );
                                        })}
                                        <button
                                          type="button"
                                          aria-label="Quitar micro descanso"
                                          onClick={() => setExField(exIdx, "microRest", null)}
                                          className="text-[#CBD5E1] transition-colors hover:text-[#EF4444]"
                                        >
                                          <X size={12} />
                                        </button>
                                      </div>
                                    )}
                                    <button
                                      type="button"
                                      aria-label="Desencadenar ejercicios"
                                      onClick={() => unchainGroup(gi)}
                                      className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#EF4444]"
                                    >
                                      <Unlink size={14} />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </section>
                    {canChain && <ChainConnector onClick={() => chainGroups(gi)} />}
                  </Fragment>
                );
              })}



              {/* CUSTOM CIRCUITS */}
              {customCircuits.map((c, i) => {
                const timer = circuitTimerLabel(c);
                const prefix =
                  c.type === "EMOM" ? "M" : c.type === "TABATA" && c.tabataAlternate ? "S" : "E";
                const colHeadStyle: React.CSSProperties = {
                  fontSize: 10,
                  fontWeight: 600,
                  color: "#D97706",
                  textTransform: "uppercase",
                  letterSpacing: "0.4px",
                  textAlign: "center",
                  width: 64,
                };
                return (
                  <section
                    key={`${c.name}-${i}`}
                    ref={(el) => {
                      circuitRefs.current[i] = el;
                    }}
                    style={{
                      backgroundColor: "#FFFFFF",
                      border: "1px solid #E2E8F0",
                      borderLeft: "3px solid #D97706",
                      borderRadius: 14,
                      overflow: "hidden",
                    }}
                  >
                    {/* HEADER */}
                    <div
                      className="flex items-center"
                      style={{
                        padding: "12px 16px",
                        gap: 8,
                        borderBottom: "1px solid #F1F5F9",
                      }}
                    >
                      <input
                        value={c.name}
                        aria-label={`Nombre del circuito ${i + 1}`}
                        onChange={(e) => renameCircuit(i, e.target.value)}
                        className="circuit-name-input text-[14px] font-semibold"
                        style={{
                          color: "#111827",
                          background: "transparent",
                          border: "1px solid transparent",
                          borderRadius: 6,
                          padding: "2px 6px",
                          outline: "none",
                          minWidth: 0,
                          width: `${Math.max(8, (c.name || "Circuito").length + 1)}ch`,
                        }}
                      />
                      <span
                        className="flex-1 truncate text-[12px]"
                        style={{ color: "#94A3B8", whiteSpace: "nowrap" }}
                      >
                        {c.type.toUpperCase()}
                        {timer ? ` · ${timer}` : ""}
                      </span>
                      <button
                        type="button"
                        aria-label={`Editar circuito ${c.name}`}
                        onClick={() => {
                          setEditingCircuit(i);
                          setCircuitOpen(true);
                        }}
                        className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#111827]"
                      >
                        <Settings2 size={16} />
                      </button>
                      <div style={{ position: "relative" }}>
                        <button
                          type="button"
                          aria-label={`Eliminar circuito ${c.name}`}
                          onClick={() => setConfirmDeleteCircuit(i)}
                          className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#111827]"
                        >
                          <Trash2 size={16} />
                        </button>
                        {confirmDeleteCircuit === i && (
                          <div
                            style={{
                              position: "absolute",
                              top: 26,
                              right: 0,
                              zIndex: 20,
                              backgroundColor: "#FFFFFF",
                              border: "1px solid #E2E8F0",
                              borderRadius: 10,
                              padding: 12,
                              width: 200,
                              boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
                            }}
                          >
                            <p
                              className="text-[13px] font-medium"
                              style={{ color: "#111827", marginBottom: 10 }}
                            >
                              ¿Eliminar circuito?
                            </p>
                            <div className="flex items-center justify-end" style={{ gap: 8 }}>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteCircuit(null)}
                                className="cursor-pointer text-[12px]"
                                style={{
                                  border: "1px solid #E2E8F0",
                                  borderRadius: 8,
                                  padding: "5px 12px",
                                  color: "#374151",
                                  backgroundColor: "#FFFFFF",
                                }}
                              >
                                Cancelar
                              </button>
                              <button
                                type="button"
                                onClick={() => removeCircuit(i)}
                                className="cursor-pointer text-[12px]"
                                style={{
                                  border: "none",
                                  borderRadius: 8,
                                  padding: "5px 12px",
                                  color: "#FFFFFF",
                                  backgroundColor: "#EF4444",
                                }}
                              >
                                Eliminar
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* COLUMN HEADERS */}
                    <div
                      className="flex items-center"
                      style={{
                        backgroundColor: "#FEFCE8",
                        borderBottom: "1px solid #FDE68A",
                        padding: "4px 16px",
                      }}
                    >
                      <span style={{ flex: 1 }} />
                      <span style={colHeadStyle}>Reps</span>
                      <span style={colHeadStyle}>Kg</span>
                      <span style={{ width: 32 }} />
                    </div>

                    {/* EXERCISES */}
                    <div>
                      {c.exercises.map((ex, xi) => (
                        <div
                          key={`${ex.name}-${xi}`}
                          className="flex items-center"
                          style={{
                            padding: "10px 16px",
                            borderBottom: "1px solid #F8FAFC",
                          }}
                        >
                          <span
                            className="font-mono text-[11px] font-bold"
                            style={{ color: "#D97706", width: 24 }}
                          >
                            {prefix}
                            {xi + 1}
                          </span>
                          <span
                            className="flex-1 truncate text-[13px] font-medium"
                            style={{ color: "#111827" }}
                          >
                            {ex.name}
                          </span>
                          <span
                            className="text-[13px] text-center"
                            style={{ width: 64, color: "#374151" }}
                          >
                            {ex.reps || "—"}
                          </span>
                          <span
                            className="text-[13px] text-center"
                            style={{ width: 64, color: "#374151" }}
                          >
                            {ex.weight ? `${ex.weight} ${ex.unit}` : "—"}
                          </span>
                          <div style={{ width: 32, display: "flex", justifyContent: "center" }}>
                            <button
                              type="button"
                              aria-label={`Eliminar ${ex.name}`}
                              onClick={() => removeCircuitExercise(i, xi)}
                              className="cursor-pointer text-[#CBD5E1] transition-colors hover:text-[#EF4444]"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* DESCRIPTION (clickable → editable) */}
                    {editingDesc === i ? (
                      <textarea
                        autoFocus
                        value={c.description}
                        onChange={(e) => setCircuitDescription(i, e.target.value)}
                        onBlur={() => setEditingDesc(null)}
                        aria-label={`Descripción del circuito ${c.name}`}
                        placeholder="Instrucciones para el atleta..."
                        className="text-[12px] italic"
                        style={{
                          width: "100%",
                          minHeight: 60,
                          border: "none",
                          borderTop: "1px solid #F8FAFC",
                          padding: "10px 16px",
                          color: "#94A3B8",
                          outline: "none",
                          resize: "vertical",
                          fontFamily: "inherit",
                          backgroundColor: "#FFFFFF",
                        }}
                      />
                    ) : (
                      <p
                        onClick={() => setEditingDesc(i)}
                        className="text-[12px] italic cursor-text"
                        style={{
                          color: "#94A3B8",
                          padding: "10px 16px",
                          borderTop: "1px solid #F8FAFC",
                          minHeight: 40,
                        }}
                      >
                        {c.description || "Agregar instrucciones para el atleta..."}
                      </p>
                    )}

                    {/* FOOTER */}
                    <div
                      className="flex items-center"
                      style={{ padding: "10px 16px", borderTop: "1px solid #F1F5F9", gap: 8 }}
                    >
                      <button
                        type="button"
                        onClick={() => openPickerFor(`custom-${i}`)}
                        className="inline-flex cursor-pointer items-center text-[12px] transition-colors hover:text-[#111827]"
                        style={{ color: "#94A3B8", gap: 4 }}
                      >
                        <Plus size={12} />
                        Agregar ejercicio
                      </button>
                    </div>
                  </section>
                );
              })}


              {/* ADD BUTTONS */}
              <div className="flex flex-col" style={{ gap: 8 }}>
                {["Agregar ejercicio", "Agregar circuito"].map((label) => (
                  <button
                    key={label}
                    type="button"
                    onClick={() =>
                      label === "Agregar ejercicio"
                        ? openPickerFor(null)
                        : (setEditingCircuit(null), setCircuitOpen(true))
                    }
                    className="inline-flex w-full items-center justify-center gap-1.5 text-[13px] transition-colors hover:bg-[#F1F5F9]"
                    style={{
                      border: "1px dashed #CBD5E1",
                      backgroundColor: "transparent",
                      color: "#64748B",
                      borderRadius: 6,
                      padding: 10,
                    }}
                  >
                    <Plus size={14} />
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </main>

          {/* RIGHT PANEL */}
          <aside
            className="min-h-0 overflow-y-auto bg-surface"
            style={{ borderLeft: "1px solid #E2E8F0", padding: 16 }}
          >
            <section style={{ marginBottom: 20, display: templateMode ? "none" : undefined }}>
              <h2
                className="text-[12px] font-semibold"
                style={{ color: "#0F172A", marginBottom: 10 }}
              >
                Historial en este ejercicio
              </h2>

              <div
                className="flex items-center justify-between"
                style={{ padding: "6px 0", borderBottom: "1px solid #F8FAFC" }}
              >
                <span className="text-[12px]" style={{ color: "#64748B" }}>
                  Últ. sesión
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="text-[12px] font-semibold" style={{ color: "#0F172A" }}>
                    80kg × 8
                  </span>
                  <span className="text-[11px]" style={{ color: "#94A3B8" }}>
                    hace 5 días
                  </span>
                </span>
              </div>

              <div
                className="flex items-center justify-between"
                style={{ padding: "6px 0", borderBottom: "1px solid #F8FAFC" }}
              >
                <span className="text-[12px]" style={{ color: "#64748B" }}>
                  Récord (PR)
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="text-[12px] font-semibold" style={{ color: "#0F172A" }}>
                    85kg × 5
                  </span>
                  <Trophy size={12} color="#D97706" />
                </span>
              </div>
            </section>

            {templateMode ? null : (
              <section style={{ marginBottom: 20 }}>
                <div className="flex items-center gap-1.5" style={{ marginBottom: 8 }}>
                  <Sparkles size={12} color="#6366F1" />
                  <h2 className="text-[12px] font-semibold" style={{ color: "#6366F1" }}>
                    Sugerencia IA
                  </h2>
                </div>
                <div
                  className="text-[12px]"
                  style={{
                    backgroundColor: "#F5F3FF",
                    border: "1px solid #DDD6FE",
                    borderRadius: 8,
                    padding: "10px 12px",
                    color: "#4C1D95",
                    lineHeight: 1.5,
                  }}
                >
                  Basado en su progreso, esta semana podría intentar 82.5kg × 8 para mantener
                  sobrecarga progresiva.
                </div>
              </section>
            )}

            <section>
              <h2
                className="text-[12px] font-semibold"
                style={{ color: "#0F172A", marginBottom: 8 }}
              >
                ¿No tiene el equipo?
              </h2>
              <button
                type="button"
                className="inline-flex w-full items-center justify-center gap-1.5 text-[12px]"
                style={{
                  border: "1px solid #E2E8F0",
                  color: "#64748B",
                  borderRadius: 6,
                  padding: 7,
                }}
              >
                <RefreshCw size={12} />
                Sugerir alternativas
              </button>
            </section>
          </aside>
        </div>
      </div>

      <ExercisePickerPanel
        open={pickerOpen}
        onClose={() => {
          setPickerOpen(false);
          setActiveBlockId(null);
        }}
        onAdd={addExerciseFromLibrary}
      />
      <CircuitModal
        open={circuitOpen}
        mode={editingCircuit === null ? "create" : "edit"}
        initial={editingCircuit === null ? null : (customCircuits[editingCircuit] ?? null)}
        onClose={() => {
          setCircuitOpen(false);
          setEditingCircuit(null);
        }}
        onSubmit={submitCircuit}
      />
    </div>
  );
}
