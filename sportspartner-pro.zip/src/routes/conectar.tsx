import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { BrandLogo } from "@/components/togo/BrandLogo";
import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Compass, Dumbbell, Trophy, User } from "lucide-react";
import { setUserContext, type UserType } from "@/lib/user-context";

type Invite = "gym" | "coach" | "club";

export const Route = createFileRoute("/conectar")({
  validateSearch: (s: Record<string, unknown>): { invite?: Invite } => {
    const v = s['invite'];
    return v === "gym" || v === "coach" || v === "club" ? { invite: v } : {};
  },
  head: () => ({
    meta: [
      { title: "Conectá tu cuenta — TOGO" },
      { name: "description", content: "Elegí cómo vas a usar TOGO: con tu entrenador, tu gimnasio o tu club." },
      { property: "og:title", content: "Conectá tu cuenta — TOGO" },
      { property: "og:description", content: "Conectate con tu entrenador, gimnasio o club deportivo en TOGO." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ConectarPage,
});

const OPTIONS: { type: UserType; Icon: typeof User; title: string; text: string; ask: string; placeholder: string }[] = [
  { type: "coached_athlete", Icon: User, title: "Tengo un coach", text: "Mi entrenador me asignó sesiones y quiero ver mi plan.", ask: "Código de invitación o email de tu entrenador", placeholder: "Ej. PABLO-4821 o pablo@mail.com" },
  { type: "gym_member", Icon: Dumbbell, title: "Soy socio de un gym", text: "Quiero reservar clases y gestionar mis entrenamientos.", ask: "Código del gimnasio o buscalo por nombre", placeholder: "Ej. CrossFit Palermo" },
  { type: "club_athlete", Icon: Trophy, title: "Pertenezco a un club", text: "Mi club o categoría tiene sesiones asignadas.", ask: "Código del club o email de tu entrenador", placeholder: "Ej. CAP-2026" },
  { type: "explorer", Icon: Compass, title: "Explorar", text: "No tengo coach ni gym todavía. Quiero conocer TOGO.", ask: "", placeholder: "" },
];
const INVITE_TYPE: Record<Invite, UserType> = { gym: "gym_member", coach: "coached_athlete", club: "club_athlete" };
const GYMS = ["CrossFit Palermo", "Palermo Fitness Center", "Box Núñez", "Megatlon Belgrano"];

function ConectarPage() {
  const { invite } = Route.useSearch();
  const navigate = useNavigate();
  const [sel, setSel] = useState<UserType | null>(null);
  const [pick, setPick] = useState<UserType | null>(null);
  const [code, setCode] = useState("");
  const [alsoCoached, setAlsoCoached] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [link, setLink] = useState("");

  const finish = (type: UserType, also = false) => {
    setUserContext({ type, alsoCoached: type === "gym_member" && also });
    navigate({ to: type === "explorer" ? "/explorar" : "/hoy" });
  };

  // Invitation link: skip the selector
  useEffect(() => { if (invite) finish(INVITE_TYPE[invite]); }, [invite]); // eslint-disable-line react-hooks/exhaustive-deps

  const opt = OPTIONS.find((o) => o.type === sel);
  const gymMatches = sel === "gym_member" && code.length > 1 ? GYMS.filter((g) => g.toLowerCase().includes(code.toLowerCase())) : [];
  const openLink = () => {
    const m = link.match(/(gym|coach|club)/i);
    if (m) finish(INVITE_TYPE[m[1]!.toLowerCase() as Invite]);
  };

  return (
    <div className="flex min-h-screen items-center justify-center" style={{ backgroundColor: "#F1F5F9", padding: 24 }}>
      <div className="relative flex flex-col" style={{ width: 375, height: 812, backgroundColor: "#F8FAFC", borderRadius: 40, boxShadow: "0 20px 60px rgba(0,0,0,0.15)", overflow: "hidden" }}>
        <div className="flex-1 overflow-y-auto" style={{ padding: "56px 20px 24px" }}>
          {invite ? (
            <div style={{ fontSize: 14, color: "#94A3B8", textAlign: "center", marginTop: 200 }}>Abriendo tu invitación…</div>
          ) : !opt ? (
            <>
              <div className="flex items-center justify-center gap-3 text-2xl font-bold text-foreground"><BrandLogo className="h-12 w-12" />TOGO</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: "#111827", textAlign: "center", marginTop: 24 }}>¿Cómo vas a usar TOGO?</div>
              <div style={{ fontSize: 13, color: "#94A3B8", textAlign: "center", margin: "6px 24px 28px" }}>Elegí tu contexto para que la app se adapte a vos.</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {OPTIONS.map(({ type, Icon, title, text }) => {
                  const on = pick === type;
                  return (
                    <button key={type} onClick={() => setPick(type)} className="hover:!border-[#CBD5E1]" style={{ textAlign: "left", background: on ? "#F8FAFC" : "#FFF", border: `1.5px solid ${on ? "#111827" : "#E2E8F0"}`, borderRadius: 14, padding: 16, display: "flex", alignItems: "center", gap: 14, cursor: "pointer" }}>
                      <span style={{ width: 44, height: 44, borderRadius: 12, background: "#F1F5F9", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Icon size={20} color="#374151" /></span>
                      <span style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                        <span style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>{title}</span>
                        <span style={{ fontSize: 11, color: "#94A3B8", lineHeight: 1.4 }}>{text}</span>
                      </span>
                      <ChevronRight size={14} color={on ? "#111827" : "#CBD5E1"} style={{ marginLeft: "auto", flexShrink: 0 }} />
                    </button>
                  );
                })}
              </div>
              <button onClick={() => setLinkOpen(!linkOpen)} style={{ display: "block", margin: "20px auto 0", fontSize: 12, color: "#3B82F6" }}>¿Te invitaron con un link?</button>
              {linkOpen && (
                <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                  <input value={link} onChange={(e) => setLink(e.target.value)} placeholder="Pegá el link de invitación" style={{ flex: 1, height: 42, border: "1px solid #E2E8F0", borderRadius: 10, padding: "0 12px", fontSize: 13, background: "#FFF" }} />
                  <button onClick={openLink} style={{ background: "#111827", color: "#FFF", borderRadius: 10, padding: "0 14px", fontSize: 13, fontWeight: 600 }}>Abrir</button>
                </div>
              )}
              <button disabled={!pick} onClick={() => { if (pick === "explorer") finish("explorer"); else { setSel(pick); setCode(""); } }} style={{ marginTop: 20, width: "100%", height: 52, borderRadius: 14, background: pick ? "#111827" : "#CBD5E1", color: "#FFF", fontSize: 15, fontWeight: 700 }}>Continuar</button>
            </>
          ) : (
            <>
              <button onClick={() => setSel(null)} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, color: "#94A3B8", marginBottom: 12 }}><ChevronLeft size={14} />Volver</button>
              <div style={{ fontSize: 22, fontWeight: 800, color: "#111827" }}>{opt.title}</div>
              <label style={{ display: "block", fontSize: 12, color: "#374151", margin: "20px 0 6px" }}>{opt.ask}</label>
              <input value={code} onChange={(e) => setCode(e.target.value)} placeholder={opt.placeholder} style={{ width: "100%", height: 44, border: "1px solid #E2E8F0", borderRadius: 10, padding: "0 12px", fontSize: 13, background: "#FFF" }} />
              {gymMatches.length > 0 && (
                <div style={{ background: "#FFF", border: "1px solid #E2E8F0", borderRadius: 10, marginTop: 6 }}>
                  {gymMatches.map((g) => <button key={g} onClick={() => setCode(g)} style={{ display: "block", width: "100%", textAlign: "left", padding: "10px 12px", fontSize: 13, color: "#374151" }}>{g}</button>)}
                </div>
              )}
              {sel === "gym_member" && (
                <label style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 16, fontSize: 13, color: "#374151" }}>
                  <input type="checkbox" checked={alsoCoached} onChange={(e) => setAlsoCoached(e.target.checked)} />
                  También tengo un entrenador personal
                </label>
              )}
              <button disabled={!code.trim()} onClick={() => finish(opt.type, alsoCoached)} style={{ marginTop: 24, width: "100%", height: 50, borderRadius: 14, background: code.trim() ? "#111827" : "#CBD5E1", color: "#FFF", fontSize: 15, fontWeight: 700 }}>Continuar</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
