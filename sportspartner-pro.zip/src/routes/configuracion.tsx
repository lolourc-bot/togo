import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  Building2,
  Camera,
  CheckCircle,
  ChevronLeft,
  ChevronRight,
  Eye,
  EyeOff,
  Instagram,
  Linkedin,
  Lock,
  Music2,
  Plus,
  Star,
  X,
} from "lucide-react";
import { Sidebar } from "@/components/togo/Sidebar";

export const Route = createFileRoute("/configuracion")({
  head: () => ({
    meta: [
      { title: "Configuración del coach — TOGO" },
      {
        name: "description",
        content:
          "Gestioná tu perfil público, cuenta, cobros, notificaciones y suscripción de coach en TOGO.",
      },
      { property: "og:title", content: "Configuración del coach — TOGO" },
      {
        property: "og:description",
        content: "Perfil, cuenta, pagos, notificaciones y plan en un solo lugar.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ConfiguracionPage,
});

const TABS = ["Mi perfil", "Cuenta", "Pagos", "Notificaciones", "Suscripción"] as const;
type Tab = (typeof TABS)[number];

const ESPECIALIDADES = [
  "Fuerza e hipertrofia",
  "Running y resistencia",
  "Preparación física deportiva",
  "Funcional y acondicionamiento",
  "Rehabilitación y movilidad",
  "Pérdida de grasa",
];
const EXPERIENCIA = ["Menos de 1 año", "1 a 3 años", "3 a 5 años", "5 a 10 años", "Más de 10 años"];
const TIPOS_CUENTA = ["Coach independiente", "Marca o emprendimiento", "Club o institución"];

const LABEL_STYLE: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 600,
  color: "#94A3B8",
  textTransform: "uppercase",
  letterSpacing: "0.5px",
  marginBottom: 12,
};

const INPUT_STYLE: React.CSSProperties = {
  width: "100%",
  height: 42,
  borderRadius: 10,
  border: "1px solid #E2E8F0",
  background: "#FFFFFF",
  padding: "0 14px",
  fontSize: 13,
  color: "#111827",
  outline: "none",
};

const FIELD_LABEL: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 500,
  color: "#374151",
  marginBottom: 6,
  display: "block",
};

const PRIMARY_BUTTON: React.CSSProperties = {
  background: "#111827",
  color: "#FFFFFF",
  borderRadius: 10,
  height: 40,
  padding: "0 24px",
  fontSize: 13,
  fontWeight: 600,
};

const SMALL_BUTTON: React.CSSProperties = {
  border: "1px solid #E2E8F0",
  borderRadius: 8,
  padding: "6px 14px",
  fontSize: 12,
  color: "#374151",
  background: "#FFFFFF",
};

function Divider() {
  return <div style={{ height: 1, background: "#E2E8F0", margin: "4px 0" }} />;
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      style={{
        width: 36,
        height: 20,
        borderRadius: 999,
        background: on ? "#111827" : "#E2E8F0",
        display: "flex",
        alignItems: "center",
        padding: 2,
        transition: "background 0.2s",
      }}
      aria-pressed={on}
    >
      <span
        style={{
          width: 16,
          height: 16,
          borderRadius: 999,
          background: "#FFFFFF",
          transform: on ? "translateX(16px)" : "translateX(0)",
          transition: "transform 0.2s",
        }}
      />
    </button>
  );
}

function ConfiguracionPage() {
  const [tab, setTab] = useState<Tab>("Mi perfil");

  return (
    <div className="flex min-h-screen" style={{ background: "#F8FAFC" }}>
      <Sidebar active="Configuración" />
      <main style={{ flex: 1, padding: 32, overflowY: "auto" }}>
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "#111827", marginBottom: 4 }}>
            Configuración
          </h1>
          <p style={{ fontSize: 13, color: "#94A3B8", marginBottom: 16 }}>
            Gestioná tu cuenta, perfil y preferencias.
          </p>

          <div
            style={{
              display: "flex",
              borderBottom: "1px solid #E2E8F0",
              marginBottom: 32,
            }}
          >
            {TABS.map((t) => {
              const active = t === tab;
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTab(t)}
                  style={{
                    padding: "10px 20px",
                    fontSize: 13,
                    fontWeight: 500,
                    color: active ? "#111827" : "#94A3B8",
                    borderBottom: `2px solid ${active ? "#111827" : "transparent"}`,
                    marginBottom: -1,
                  }}
                >
                  {t}
                </button>
              );
            })}
          </div>

          {tab === "Mi perfil" ? <PerfilTab /> : null}
          {tab === "Cuenta" ? <CuentaTab /> : null}
          {tab === "Pagos" ? <PagosTab /> : null}
          {tab === "Notificaciones" ? <NotificacionesTab /> : null}
          {tab === "Suscripción" ? <SuscripcionTab /> : null}
        </div>
      </main>
    </div>
  );
}

/* ---------------- TAB 1 — MI PERFIL ---------------- */

function PerfilTab() {
  const [nombre, setNombre] = useState("Pablo Rodríguez");
  const [slogan, setSlogan] = useState("");
  const [especialidad, setEspecialidad] = useState(ESPECIALIDADES[0]);
  const [experiencia, setExperiencia] = useState(EXPERIENCIA[3]);
  const [bio, setBio] = useState("");
  const [tipo, setTipo] = useState(TIPOS_CUENTA[0]);
  const [guardado, setGuardado] = useState(false);

  return (
    <div style={{ display: "flex", gap: 32, alignItems: "flex-start" }}>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 20, minWidth: 0 }}>
        <div>
          <p style={LABEL_STYLE}>Información pública</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div>
              <label style={FIELD_LABEL}>Nombre del perfil</label>
              <input
                style={INPUT_STYLE}
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
              />
            </div>
            <div>
              <label style={FIELD_LABEL}>Slogan</label>
              <input
                style={INPUT_STYLE}
                maxLength={80}
                placeholder="Tu propuesta de valor en una frase"
                value={slogan}
                onChange={(e) => setSlogan(e.target.value)}
              />
              <p style={{ fontSize: 11, color: "#CBD5E1", textAlign: "right", marginTop: 4 }}>
                {slogan.length}/80
              </p>
            </div>
            <div>
              <label style={FIELD_LABEL}>Especialidad principal</label>
              <select
                style={INPUT_STYLE}
                value={especialidad}
                onChange={(e) => setEspecialidad(e.target.value)}
              >
                {ESPECIALIDADES.map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
            </div>
            <div>
              <label style={FIELD_LABEL}>Años de experiencia</label>
              <select
                style={INPUT_STYLE}
                value={experiencia}
                onChange={(e) => setExperiencia(e.target.value)}
              >
                {EXPERIENCIA.map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
            </div>
            <div>
              <label style={FIELD_LABEL}>Bio</label>
              <textarea
                style={{ ...INPUT_STYLE, height: 100, padding: "10px 14px", resize: "none" }}
                maxLength={300}
                placeholder="Contá quién sos y a quién ayudás."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
              />
              <p style={{ fontSize: 11, color: "#CBD5E1", textAlign: "right", marginTop: 4 }}>
                {bio.length}/300
              </p>
            </div>
          </div>
        </div>

        <Divider />

        <div>
          <p style={LABEL_STYLE}>Redes sociales</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
            <SocialInput icon={<Instagram size={14} color="#CBD5E1" />} placeholder="@tuusuario" />
            <SocialInput icon={<Music2 size={14} color="#CBD5E1" />} placeholder="@tuusuario" />
            <SocialInput
              icon={<Linkedin size={14} color="#CBD5E1" />}
              placeholder="linkedin.com/in/tu-perfil"
            />
          </div>
        </div>

        <Divider />

        <div>
          <p style={LABEL_STYLE}>Tipo de cuenta</p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {TIPOS_CUENTA.map((t) => {
              const sel = t === tipo;
              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTipo(t)}
                  style={{
                    background: sel ? "#111827" : "#F1F5F9",
                    color: sel ? "#FFFFFF" : "#94A3B8",
                    borderRadius: 8,
                    padding: "8px 14px",
                    fontSize: 13,
                    fontWeight: 500,
                  }}
                >
                  {t}
                </button>
              );
            })}
          </div>
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "center",
            gap: 12,
            marginTop: 8,
          }}
        >
          {guardado ? (
            <span style={{ fontSize: 12, color: "#16A34A" }}>Cambios guardados</span>
          ) : null}
          <button
            type="button"
            style={PRIMARY_BUTTON}
            onClick={() => {
              setGuardado(true);
              window.setTimeout(() => setGuardado(false), 2000);
            }}
          >
            Guardar cambios
          </button>
        </div>
      </div>

      <div style={{ width: 240, flexShrink: 0 }}>
        <div
          style={{
            background: "#FFFFFF",
            borderRadius: 14,
            border: "1px solid #E2E8F0",
            padding: 20,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 12,
          }}
        >
          <div style={{ position: "relative" }}>
            <div
              style={{
                width: 88,
                height: 88,
                borderRadius: 999,
                background: "#F1F5F9",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 22,
                fontWeight: 600,
                color: "#94A3B8",
              }}
            >
              PR
            </div>
            <span
              style={{
                position: "absolute",
                right: 0,
                bottom: 0,
                width: 24,
                height: 24,
                borderRadius: 999,
                background: "#111827",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Camera size={12} color="#FFFFFF" />
            </span>
          </div>
          <p style={{ fontSize: 12, fontWeight: 500, color: "#374151", textAlign: "center" }}>
            Foto de perfil
          </p>
          <button type="button" style={SMALL_BUTTON}>
            Subir imagen
          </button>
          <p style={{ fontSize: 10, color: "#CBD5E1" }}>JPG, PNG · Máx. 5MB</p>
        </div>

        <div
          style={{
            background: "#FFFFFF",
            borderRadius: 14,
            border: "1px solid #E2E8F0",
            padding: 16,
            marginTop: 16,
          }}
        >
          <p style={{ fontSize: 11, color: "#94A3B8", fontWeight: 500, marginBottom: 12 }}>
            Vista previa en marketplace
          </p>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div
              style={{
                width: 40,
                height: 40,
                borderRadius: 999,
                background: "#F1F5F9",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 12,
                fontWeight: 600,
                color: "#94A3B8",
              }}
            >
              PR
            </div>
            <div style={{ minWidth: 0, flex: 1 }}>
              <p style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>{nombre}</p>
              <p style={{ fontSize: 11, color: "#64748B" }}>{especialidad}</p>
              <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 2 }}>
                <Star size={10} color="#D97706" />
                <span style={{ fontSize: 11, color: "#374151" }}>4.9</span>
              </div>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 12 }}>
            <span
              style={{
                border: "1px solid #E2E8F0",
                borderRadius: 6,
                padding: "4px 10px",
                fontSize: 11,
                color: "#374151",
              }}
            >
              Ver perfil
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function SocialInput({ icon, placeholder }: { icon: React.ReactNode; placeholder: string }) {
  return (
    <div style={{ position: "relative" }}>
      <span style={{ position: "absolute", left: 12, top: 14 }}>{icon}</span>
      <input style={{ ...INPUT_STYLE, paddingLeft: 32, fontSize: 12 }} placeholder={placeholder} />
    </div>
  );
}

/* ---------------- TAB 2 — CUENTA ---------------- */

function CuentaTab() {
  const [changing, setChanging] = useState(false);
  const [showCurrent, setShowCurrent] = useState(false);
  const [nueva, setNueva] = useState("");
  const [moneda, setMoneda] = useState("ARS $");
  const [zona, setZona] = useState("América/Buenos Aires (UTC-3)");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const strength = Math.min(4, Math.floor(nueva.length / 3));

  return (
    <div style={{ maxWidth: 520, display: "flex", flexDirection: "column", gap: 24 }}>
      <div>
        <p style={LABEL_STYLE}>Información de acceso</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <label style={FIELD_LABEL}>Email</label>
            <div style={{ position: "relative" }}>
              <input
                readOnly
                value="pablo@gmail.com"
                style={{ ...INPUT_STYLE, background: "#F8FAFC", color: "#94A3B8" }}
              />
              <Lock
                size={14}
                color="#CBD5E1"
                style={{ position: "absolute", right: 14, top: 14 }}
              />
            </div>
            <p style={{ fontSize: 11, color: "#CBD5E1", marginTop: 6 }}>
              Contactá a soporte para cambiar tu email.
            </p>
          </div>

          <div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "14px 16px",
                background: "#FFFFFF",
                borderRadius: 10,
                border: "1px solid #E2E8F0",
              }}
            >
              <div>
                <p style={{ fontSize: 13, fontWeight: 500, color: "#374151" }}>Contraseña</p>
                <p style={{ fontSize: 11, color: "#94A3B8" }}>Última actualización: hace 3 meses</p>
              </div>
              <button type="button" style={SMALL_BUTTON} onClick={() => setChanging((v) => !v)}>
                {changing ? "Cerrar" : "Cambiar"}
              </button>
            </div>

            <div
              style={{
                maxHeight: changing ? 320 : 0,
                overflow: "hidden",
                transition: "max-height 0.25s ease",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: 12,
                  padding: "16px 2px 0",
                }}
              >
                <div>
                  <label style={FIELD_LABEL}>Contraseña actual</label>
                  <div style={{ position: "relative" }}>
                    <input type={showCurrent ? "text" : "password"} style={INPUT_STYLE} />
                    <button
                      type="button"
                      onClick={() => setShowCurrent((v) => !v)}
                      style={{ position: "absolute", right: 12, top: 13 }}
                    >
                      {showCurrent ? (
                        <EyeOff size={15} color="#CBD5E1" />
                      ) : (
                        <Eye size={15} color="#CBD5E1" />
                      )}
                    </button>
                  </div>
                </div>
                <div>
                  <label style={FIELD_LABEL}>Nueva contraseña</label>
                  <input
                    type="password"
                    style={INPUT_STYLE}
                    value={nueva}
                    onChange={(e) => setNueva(e.target.value)}
                  />
                  <div style={{ display: "flex", gap: 4, marginTop: 6 }}>
                    {[0, 1, 2, 3].map((i) => (
                      <span
                        key={i}
                        style={{
                          flex: 1,
                          height: 4,
                          borderRadius: 2,
                          background: i < strength ? "#111827" : "#E2E8F0",
                        }}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <label style={FIELD_LABEL}>Confirmar nueva contraseña</label>
                  <input type="password" style={INPUT_STYLE} />
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <button type="button" style={PRIMARY_BUTTON} onClick={() => setChanging(false)}>
                    Guardar contraseña
                  </button>
                  <button
                    type="button"
                    style={{ fontSize: 12, color: "#94A3B8" }}
                    onClick={() => setChanging(false)}
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Divider />

      <div>
        <p style={LABEL_STYLE}>Preferencias regionales</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <label style={FIELD_LABEL}>Moneda de cobro</label>
            <div style={{ display: "flex", gap: 8 }}>
              {["ARS $", "USD $"].map((m) => {
                const sel = m === moneda;
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMoneda(m)}
                    style={{
                      background: sel ? "#111827" : "#F1F5F9",
                      color: sel ? "#FFFFFF" : "#94A3B8",
                      borderRadius: 8,
                      padding: "8px 14px",
                      fontSize: 13,
                      fontWeight: 500,
                    }}
                  >
                    {m}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <label style={FIELD_LABEL}>Zona horaria</label>
            <select style={INPUT_STYLE} value={zona} onChange={(e) => setZona(e.target.value)}>
              <option>América/Buenos Aires (UTC-3)</option>
              <option>América/Santiago (UTC-4)</option>
              <option>América/Montevideo (UTC-3)</option>
              <option>América/Bogotá (UTC-5)</option>
              <option>Europa/Madrid (UTC+2)</option>
            </select>
          </div>
        </div>
      </div>

      <Divider />

      <div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "14px 16px",
              borderRadius: 10,
              border: "1px solid #E2E8F0",
              background: "#FFFFFF",
            }}
          >
            <span style={{ fontSize: 13, color: "#374151" }}>Cerrar sesión en este dispositivo</span>
            <button type="button" style={SMALL_BUTTON}>
              Cerrar sesión
            </button>
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "14px 16px",
              borderRadius: 10,
              border: "1px solid #FEE2E2",
              background: "#FFF5F5",
            }}
          >
            <span style={{ fontSize: 13, color: "#EF4444" }}>
              Eliminar mi cuenta permanentemente
            </span>
            <button
              type="button"
              onClick={() => setConfirmDelete(true)}
              style={{
                border: "1px solid #FECACA",
                borderRadius: 8,
                padding: "6px 14px",
                fontSize: 12,
                color: "#EF4444",
                background: "#FFFFFF",
              }}
            >
              Eliminar cuenta
            </button>
          </div>
        </div>
      </div>

      {confirmDelete ? (
        <Modal onClose={() => setConfirmDelete(false)}>
          <p style={{ fontSize: 14, fontWeight: 600, color: "#111827", marginBottom: 8 }}>
            Eliminar cuenta
          </p>
          <p style={{ fontSize: 13, color: "#64748B", marginBottom: 20 }}>
            Esta acción no se puede deshacer. ¿Estás seguro?
          </p>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
            <button type="button" style={SMALL_BUTTON} onClick={() => setConfirmDelete(false)}>
              Cancelar
            </button>
            <button
              type="button"
              onClick={() => setConfirmDelete(false)}
              style={{
                background: "#EF4444",
                color: "#FFFFFF",
                borderRadius: 8,
                padding: "6px 14px",
                fontSize: 12,
                fontWeight: 600,
              }}
            >
              Sí, eliminar
            </button>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}

function Modal({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.35)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 50,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "#FFFFFF",
          borderRadius: 14,
          border: "1px solid #E2E8F0",
          padding: 24,
          width: 380,
          boxShadow: "0 12px 32px rgba(0,0,0,0.15)",
        }}
      >
        {children}
      </div>
    </div>
  );
}

/* ---------------- TAB 3 — PAGOS ---------------- */

const RETIROS = [
  { fecha: "12 sep 2026", monto: "$1.200" },
  { fecha: "28 ago 2026", monto: "$980" },
  { fecha: "14 ago 2026", monto: "$1.500" },
  { fecha: "30 jul 2026", monto: "$620" },
  { fecha: "15 jul 2026", monto: "$840" },
];

function PagosTab() {
  return (
    <div style={{ maxWidth: 560, display: "flex", flexDirection: "column", gap: 24 }}>
      <div>
        <p style={LABEL_STYLE}>Cuenta bancaria</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div
            style={{
              background: "#FFFFFF",
              borderRadius: 12,
              border: "1px solid #E2E8F0",
              padding: "16px 20px",
              display: "flex",
              alignItems: "center",
              gap: 14,
            }}
          >
            <Building2 size={20} color="#94A3B8" />
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: 13, fontWeight: 600, color: "#111827" }}>Banco Galicia</p>
              <p style={{ fontSize: 12, color: "#94A3B8" }}>
                Cuenta ···· 4242 · CBU terminado en 1234
              </p>
            </div>
            <button
              type="button"
              style={{ fontSize: 12, color: "#94A3B8", display: "flex", alignItems: "center", gap: 4 }}
            >
              Cambiar
              <ChevronRight size={14} color="#CBD5E1" />
            </button>
          </div>
          <button
            type="button"
            style={{
              border: "1.5px dashed #E2E8F0",
              borderRadius: 12,
              width: "100%",
              height: 44,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
            }}
          >
            <Plus size={14} color="#94A3B8" />
            <span style={{ fontSize: 13, color: "#94A3B8" }}>Agregar cuenta bancaria</span>
          </button>
        </div>
      </div>

      <Divider />

      <div>
        <p style={LABEL_STYLE}>Historial de retiros</p>
        <div>
          <div
            style={{
              background: "#F8FAFC",
              borderRadius: "8px 8px 0 0",
              padding: "8px 16px",
              display: "flex",
              fontSize: 12,
              fontWeight: 500,
              color: "#94A3B8",
            }}
          >
            <span style={{ flex: 1 }}>Fecha</span>
            <span style={{ width: 100 }}>Monto</span>
            <span style={{ width: 100 }}>Estado</span>
            <span style={{ width: 140 }}>Destino</span>
          </div>
          {RETIROS.map((r) => (
            <div
              key={r.fecha}
              style={{
                display: "flex",
                alignItems: "center",
                background: "#FFFFFF",
                borderBottom: "1px solid #F1F5F9",
                padding: "12px 16px",
                fontSize: 12,
                color: "#374151",
              }}
            >
              <span style={{ flex: 1 }}>{r.fecha}</span>
              <span style={{ width: 100 }}>{r.monto}</span>
              <span
                style={{
                  width: 100,
                  display: "flex",
                  alignItems: "center",
                  gap: 4,
                  color: "#10B981",
                }}
              >
                <CheckCircle size={12} color="#10B981" />
                Acreditado
              </span>
              <span style={{ width: 140 }}>Galicia ···· 4242</span>
            </div>
          ))}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-end",
              gap: 8,
              marginTop: 12,
            }}
          >
            <span style={{ fontSize: 12, color: "#94A3B8" }}>1 de 3 páginas</span>
            <ChevronLeft size={14} color="#CBD5E1" />
            <ChevronRight size={14} color="#CBD5E1" />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- TAB 4 — NOTIFICACIONES ---------------- */

const EMAIL_ROWS = [
  ["Nuevo atleta", "Cuando alguien se une a uno de tus programas.", true],
  ["Mensaje recibido", "Cuando un atleta te envía un mensaje.", true],
  ["Pago recibido", "Confirmación de cada cobro acreditado.", true],
  ["Retiro procesado", "Cuando un retiro es acreditado en tu cuenta.", true],
  ["Novedades de TOGO", "Tips, nuevas funciones y actualizaciones.", false],
] as const;

const PUSH_ROWS = [
  ["Semana sin planificar", "Avisá cuando un atleta está por empezar una semana nueva y no tiene ninguna sesión asignada.", true],
  ["Actividad de atletas", "Cuando un atleta completa una sesión.", false],
  ["Mensajes", "Nuevos mensajes de tus atletas.", true],
] as const;

function NotificacionesTab() {
  const [state, setState] = useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {};
    [...EMAIL_ROWS, ...PUSH_ROWS].forEach(([label, , on]) => {
      initial[label as string] = on as boolean;
    });
    return initial;
  });

  const rows = (list: typeof EMAIL_ROWS | typeof PUSH_ROWS) => (
    <div style={{ display: "flex", flexDirection: "column" }}>
      {list.map(([label, desc]) => (
        <div
          key={label}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "16px 0",
            borderBottom: "1px solid #F8FAFC",
          }}
        >
          <div>
            <p style={{ fontSize: 13, fontWeight: 500, color: "#111827" }}>{label}</p>
            <p style={{ fontSize: 12, color: "#94A3B8", marginTop: 2 }}>{desc}</p>
          </div>
          <Toggle
            on={state[label] ?? false}
            onChange={(v) => setState((s) => ({ ...s, [label]: v }))}
          />
        </div>
      ))}
    </div>
  );

  return (
    <div style={{ maxWidth: 520 }}>
      <p style={LABEL_STYLE}>Por email</p>
      {rows(EMAIL_ROWS)}
      <div style={{ height: 1, background: "#E2E8F0", margin: "20px 0" }} />
      <p style={LABEL_STYLE}>Push (app móvil)</p>
      {rows(PUSH_ROWS)}
      <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 24 }}>
        <button type="button" style={PRIMARY_BUTTON}>
          Guardar preferencias
        </button>
      </div>
    </div>
  );
}

/* ---------------- TAB 5 — SUSCRIPCIÓN ---------------- */

function SuscripcionTab() {
  const [cancel, setCancel] = useState(false);

  return (
    <div style={{ maxWidth: 560 }}>
      <div
        style={{
          background: "#FFFFFF",
          borderRadius: 16,
          border: "2px solid #111827",
          padding: 24,
          marginBottom: 24,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 16, fontWeight: 700, color: "#111827" }}>Plan Pro</span>
          <span
            style={{
              background: "#DCFCE7",
              color: "#16A34A",
              fontSize: 10,
              fontWeight: 700,
              borderRadius: 4,
              padding: "2px 8px",
            }}
          >
            ACTIVO
          </span>
        </div>
        <p style={{ fontSize: 28, fontWeight: 800, color: "#111827", marginTop: 8 }}>
          $29 USD / mes
        </p>
        <p style={{ fontSize: 12, color: "#94A3B8", marginTop: 2 }}>
          · próxima renovación: 11 oct 2026
        </p>
        <div style={{ display: "flex", gap: 8, marginTop: 16, flexWrap: "wrap" }}>
          {["Atletas ilimitados", "Marketplace activo", "Mensajería", "Analíticas avanzadas"].map(
            (f) => (
              <span
                key={f}
                style={{
                  background: "#F1F5F9",
                  borderRadius: 20,
                  padding: "5px 12px",
                  fontSize: 12,
                  color: "#374151",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                }}
              >
                <CheckCircle size={11} color="#111827" />
                {f}
              </span>
            ),
          )}
        </div>
        <a
          href="https://billing.stripe.com/p/login/test"
          target="_blank"
          rel="noreferrer"
          style={{
            display: "inline-block",
            fontSize: 13,
            color: "#94A3B8",
            marginTop: 16,
            textDecoration: "none",
          }}
          className="hover:underline"
        >
          Administrar suscripción
        </a>
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
        <PlanCard
          title="Gratis"
          price="$0"
          highlight={false}
          features={[
            { text: "Hasta 5 atletas", ok: true },
            { text: "1 programa publicado", ok: true },
            { text: "Sin marketplace", ok: false },
            { text: "Sin analíticas", ok: false },
          ]}
          footer={
            <span
              style={{
                display: "block",
                background: "#F1F5F9",
                borderRadius: 6,
                padding: "4px 10px",
                fontSize: 11,
                color: "#94A3B8",
                textAlign: "center",
              }}
            >
              Tu plan anterior
            </span>
          }
        />
        <PlanCard
          title="Pro"
          note="Tu plan actual"
          price="$29 USD"
          suffix="/mes"
          highlight
          features={[
            { text: "Atletas ilimitados", ok: true, dark: true },
            { text: "Programas ilimitados", ok: true, dark: true },
            { text: "Marketplace activo", ok: true, dark: true },
            { text: "Analíticas avanzadas", ok: true, dark: true },
          ]}
          footer={
            <span
              style={{
                display: "block",
                background: "#111827",
                color: "#FFFFFF",
                borderRadius: 6,
                padding: "4px 10px",
                fontSize: 11,
                fontWeight: 500,
                textAlign: "center",
              }}
            >
              Plan actual
            </span>
          }
        />
        <PlanCard
          title="Elite"
          note="Próximamente"
          price="$?"
          priceMuted
          highlight={false}
          features={[
            { text: "Todo lo de Pro", ok: true },
            { text: "Dashboard institución", ok: true },
            { text: "Gestión de equipos", ok: true },
            { text: "Soporte prioritario", ok: true },
          ]}
          footer={
            <button
              type="button"
              style={{
                border: "1px solid #E2E8F0",
                borderRadius: 8,
                padding: "6px 14px",
                fontSize: 12,
                color: "#94A3B8",
                width: "100%",
              }}
            >
              Anotarme
            </button>
          }
        />
      </div>

      <div style={{ textAlign: "center", marginTop: 8 }}>
        <button
          type="button"
          onClick={() => setCancel(true)}
          style={{ fontSize: 12, color: "#94A3B8" }}
        >
          Cancelar suscripción
        </button>
      </div>

      {cancel ? (
        <Modal onClose={() => setCancel(false)}>
          <p style={{ fontSize: 14, fontWeight: 600, color: "#111827", marginBottom: 8 }}>
            Cancelar suscripción
          </p>
          <p style={{ fontSize: 13, color: "#64748B", marginBottom: 20 }}>
            ¿Querés cancelar tu plan Pro? Seguirás teniendo acceso hasta el 11 oct 2026.
          </p>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
            <button type="button" style={SMALL_BUTTON} onClick={() => setCancel(false)}>
              Mantener plan
            </button>
            <button
              type="button"
              onClick={() => setCancel(false)}
              style={{
                background: "#EF4444",
                color: "#FFFFFF",
                borderRadius: 8,
                padding: "6px 14px",
                fontSize: 12,
                fontWeight: 600,
              }}
            >
              Sí, cancelar
            </button>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}

function PlanCard({
  title,
  note,
  price,
  suffix,
  priceMuted,
  highlight,
  features,
  footer,
}: {
  title: string;
  note?: string;
  price: string;
  suffix?: string;
  priceMuted?: boolean;
  highlight: boolean;
  features: { text: string; ok: boolean; dark?: boolean }[];
  footer: React.ReactNode;
}) {
  return (
    <div
      style={{
        background: "#FFFFFF",
        borderRadius: 14,
        border: highlight ? "2px solid #111827" : "1px solid #E2E8F0",
        padding: 20,
        flex: 1,
        minWidth: 0,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>{title}</span>
        {note ? <span style={{ fontSize: 10, color: "#94A3B8" }}>{note}</span> : null}
      </div>
      <p style={{ marginTop: 6 }}>
        <span
          style={{ fontSize: 24, fontWeight: 800, color: priceMuted ? "#94A3B8" : "#111827" }}
        >
          {price}
        </span>
        {suffix ? <span style={{ fontSize: 13, color: "#94A3B8" }}>{suffix}</span> : null}
      </p>
      <div style={{ display: "flex", flexDirection: "column", gap: 6, margin: "12px 0" }}>
        {features.map((f) => (
          <span
            key={f.text}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              fontSize: 12,
              color: "#374151",
            }}
          >
            {f.ok ? (
              <CheckCircle size={12} color={f.dark ? "#111827" : "#94A3B8"} />
            ) : (
              <X size={12} color="#CBD5E1" />
            )}
            {f.text}
          </span>
        ))}
      </div>
      {footer}
    </div>
  );
}
