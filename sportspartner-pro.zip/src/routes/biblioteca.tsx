import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  CheckCircle,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Grid3x3,
  List,
  MoreHorizontal,
  Play,
  PlayCircle,
  Plus,
  Search,
} from "lucide-react";
import { Sidebar } from "@/components/togo/Sidebar";
import { NewExerciseModal } from "@/components/togo/NewExerciseModal";
import {
  EQUIPMENT_OPTIONS,
  LATERALITY_OPTIONS,
  LIBRARY_EXERCISES,
  MOVEMENT_PATTERNS,
  sourceLabel,
  type LibraryExercise,
} from "@/lib/exercise-data";


export const Route = createFileRoute("/biblioteca")({
  head: () => ({
    meta: [
      { title: "Biblioteca de ejercicios · TOGO" },
      {
        name: "description",
        content:
          "Explorá, filtrá y administrá la biblioteca de ejercicios de tus atletas en TOGO.",
      },
      { property: "og:title", content: "Biblioteca de ejercicios · TOGO" },
      {
        property: "og:description",
        content: "Buscá ejercicios por patrón de movimiento, equipamiento y lateralidad en TOGO.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LibraryScreen,
});

const TABS = ["Todos", "Mis ejercicios", "TOGO"] as const;

function FilterSelect({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: string[];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div
      className="relative flex items-center"
      style={{
        height: 40,
        border: "1px solid #E2E8F0",
        borderRadius: 10,
        padding: "0 12px",
        backgroundColor: "#FFFFFF",
        gap: 8,
      }}
    >
      <span style={{ fontSize: 13, color: "#374151", whiteSpace: "nowrap" }}>
        {value === options[0] ? label : value}
      </span>
      <ChevronDown size={13} color="#CBD5E1" />
      <select
        aria-label={label}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{
          position: "absolute",
          inset: 0,
          opacity: 0,
          cursor: "pointer",
          width: "100%",
        }}
      >
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </div>
  );
}

function SourceBadge({ source }: { source: LibraryExercise["source"] }) {
  return (
    <span
      style={{
        display: "inline-block",
        fontSize: source === "TOGO" ? 9 : 11,
        fontWeight: source === "TOGO" ? 700 : 500,
        padding: source === "TOGO" ? "2px 7px" : 0,
        borderRadius: 6,
        textAlign: "center",
        whiteSpace: "nowrap",
        backgroundColor: source === "TOGO" ? "#111827" : "transparent",
        color: source === "TOGO" ? "#FFFFFF" : "#64748B",
      }}
    >
      {sourceLabel(source)}
    </span>
  );
}

function ExerciseCard({ exercise }: { exercise: LibraryExercise }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div
      className="togo-ex-card"
      style={{
        backgroundColor: "#FFFFFF",
        borderRadius: 14,
        border: "1px solid #E2E8F0",
        overflow: "hidden",
        cursor: "pointer",
        transition: "border-color 120ms ease, transform 120ms ease",
      }}
    >
      {/* THUMBNAIL */}
      <div
        className="relative flex items-center justify-center"
        style={{ height: 140, backgroundColor: "#F1F5F9" }}
      >
        <PlayCircle size={32} color="#94A3B8" />
        <span
          style={{
            position: "absolute",
            top: 0,
            right: 0,
            fontSize: 9,
            fontWeight: 600,
            padding: "3px 7px",
            borderRadius: "0 0 0 8px",
            whiteSpace: "nowrap",
            backgroundColor: exercise.source === "TOGO" ? "#111827" : "#F1F5F9",
            color: exercise.source === "TOGO" ? "#FFFFFF" : "#64748B",
          }}
        >
          {sourceLabel(exercise.source)}
        </span>
      </div>

      {/* BODY */}
      <div style={{ padding: 12 }}>
        <div
          style={{
            fontSize: 13,
            fontWeight: 600,
            color: "#111827",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {exercise.name}
        </div>
        <div className="flex" style={{ gap: 6, marginTop: 4 }}>
          <span
            style={{
              fontSize: 10,
              color: "#64748B",
              backgroundColor: "#F1F5F9",
              borderRadius: 6,
              padding: "2px 7px",
            }}
          >
            {exercise.pattern}
          </span>
          <span
            style={{
              fontSize: 10,
              color: "#64748B",
              backgroundColor: "#F1F5F9",
              borderRadius: 6,
              padding: "2px 7px",
            }}
          >
            {exercise.laterality}
          </span>
        </div>
        <div className="flex items-center" style={{ gap: 4, marginTop: 6 }}>
          <span style={{ fontSize: 11, color: "#94A3B8" }}>{exercise.equipment}</span>
        </div>
      </div>

      {/* FOOTER */}
      <div
        className="flex items-center"
        style={{ padding: "8px 12px", borderTop: "1px solid #F8FAFC" }}
      >
        <div className="relative flex items-center" style={{ gap: 6, marginLeft: "auto" }}>
          <button
            type="button"
            className="togo-ex-action"
            title="Agregar a sesión"
            aria-label="Agregar a sesión"
          >
            <Plus size={20} />
          </button>
          <button
            type="button"
            className="togo-ex-action"
            aria-label="Más opciones"
            onClick={() => setMenuOpen((v) => !v)}
          >
            <MoreHorizontal size={20} />
          </button>
          {menuOpen && (
            <div
              style={{
                position: "absolute",
                right: 0,
                top: 26,
                zIndex: 20,
                backgroundColor: "#FFFFFF",
                border: "1px solid #E2E8F0",
                borderRadius: 10,
                boxShadow: "0 4px 16px rgba(0,0,0,0.08)",
                overflow: "hidden",
                minWidth: 120,
              }}
            >
              {["Editar", "Duplicar", "Eliminar"].map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => setMenuOpen(false)}
                  style={{
                    display: "block",
                    width: "100%",
                    textAlign: "left",
                    padding: "8px 12px",
                    fontSize: 12,
                    color: opt === "Eliminar" ? "#EF4444" : "#374151",
                    backgroundColor: "transparent",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  {opt}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ExerciseTable({ exercises }: { exercises: LibraryExercise[] }) {
  return (
    <div
      style={{
        backgroundColor: "#FFFFFF",
        border: "1px solid #E2E8F0",
        borderRadius: 12,
        overflow: "hidden",
      }}
    >
      {/* HEADER */}
      <div
        className="flex items-center"
        style={{
          height: 40,
          padding: "0 16px",
          backgroundColor: "#F8FAFC",
          borderBottom: "1px solid #E2E8F0",
          fontSize: 11,
          fontWeight: 500,
          color: "#94A3B8",
          textTransform: "uppercase",
          letterSpacing: "0.4px",
        }}
      >
        <span style={{ width: 48, marginRight: 16 }} />
        <span style={{ flex: 1 }}>Ejercicio</span>
        <span style={{ width: 180 }}>Patrón de movimiento</span>
        <span style={{ width: 160 }}>Equipamiento</span>
        <span style={{ width: 80, textAlign: "center" }}>Fuente</span>
        <span style={{ width: 64 }} />
      </div>

      {exercises.map((e) => (
        <div
          key={e.name}
          className="flex items-center"
          style={{
            height: 52,
            padding: "0 16px",
            backgroundColor: "#FFFFFF",
            borderBottom: "1px solid #F8FAFC",
          }}
        >
          <span
            className="flex items-center justify-center"
            style={{
              width: 48,
              height: 36,
              backgroundColor: "#F1F5F9",
              borderRadius: 6,
              marginRight: 16,
              flexShrink: 0,
            }}
          >
            <Play size={14} color="#CBD5E1" />
          </span>
          <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: "#111827" }}>
            {e.name}
          </span>
          <span style={{ width: 180, fontSize: 12, color: "#64748B" }}>{e.pattern}</span>
          <span style={{ width: 160, fontSize: 12, color: "#94A3B8" }}>{e.equipment}</span>
          <span style={{ width: 80, textAlign: "center" }}>
            <SourceBadge source={e.source} />
          </span>
          <span
            className="flex items-center"
            style={{ width: 64, gap: 8, justifyContent: "flex-end" }}
          >
            <button
              type="button"
              className="togo-ex-action"
              aria-label="Agregar a sesión"
              style={{ color: "#CBD5E1" }}
            >
              <Plus size={18} />
            </button>
            <button
              type="button"
              className="togo-ex-action"
              aria-label="Más opciones"
              style={{ color: "#CBD5E1" }}
            >
              <MoreHorizontal size={18} />
            </button>
          </span>
        </div>
      ))}
    </div>
  );
}

function LibraryScreen() {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Todos");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [query, setQuery] = useState("");
  const [pattern, setPattern] = useState("Todos");
  const [equipment, setEquipment] = useState("Todo");
  const [laterality, setLaterality] = useState("Todos");
  const [modalOpen, setModalOpen] = useState(false);
  const [toast, setToast] = useState(false);
  const [custom, setCustom] = useState<LibraryExercise[]>([]);

  const results = [...custom, ...LIBRARY_EXERCISES].filter((e) => {

    if (tab === "Mis ejercicios" && e.source !== "Coach") return false;
    if (tab === "TOGO" && e.source !== "TOGO") return false;
    if (query.trim() && !e.name.toLowerCase().includes(query.trim().toLowerCase()))
      return false;
    if (pattern !== "Todos" && e.pattern !== pattern) return false;
    if (equipment !== "Todo" && e.equipment !== equipment) return false;
    if (laterality !== "Todos" && e.laterality !== laterality) return false;
    return true;
  });

  return (
    <div className="flex" style={{ backgroundColor: "#F8FAFC", minHeight: "100vh" }}>
      <Sidebar active="Biblioteca" />

      <main style={{ flex: 1, padding: "32px 40px", maxWidth: 1440 }}>
        {/* HEADER */}
        <div className="flex items-center justify-between" style={{ marginBottom: 24 }}>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "#111827" }}>
            Biblioteca de ejercicios
          </h1>
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            className="flex items-center"
            style={{
              gap: 8,
              backgroundColor: "#111827",
              color: "#FFFFFF",
              fontSize: 13,
              fontWeight: 500,
              borderRadius: 10,
              padding: "8px 16px",
              border: "none",
              cursor: "pointer",
            }}
          >
            <Plus size={14} color="#FFFFFF" />
            Nuevo ejercicio
          </button>
        </div>


        {/* SEARCH + FILTERS */}
        <div className="flex items-center" style={{ gap: 12, marginBottom: 20 }}>
          <div
            className="flex items-center"
            style={{
              flex: 1,
              height: 40,
              border: "1px solid #E2E8F0",
              borderRadius: 10,
              padding: "0 14px",
              backgroundColor: "#FFFFFF",
              gap: 8,
            }}
          >
            <Search size={15} color="#CBD5E1" />
            <input
              type="search"
              className="togo-search"
              placeholder="Buscar ejercicio..."
              aria-label="Buscar ejercicio"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{
                flex: 1,
                border: "none",
                outline: "none",
                fontSize: 13,
                color: "#111827",
                backgroundColor: "transparent",
              }}
            />
          </div>

          <FilterSelect
            label="Patrón de movimiento"
            options={MOVEMENT_PATTERNS}
            value={pattern}
            onChange={setPattern}
          />
          <FilterSelect
            label="Equipamiento"
            options={EQUIPMENT_OPTIONS}
            value={equipment}
            onChange={setEquipment}
          />
          <FilterSelect
            label="Lateralidad"
            options={LATERALITY_OPTIONS}
            value={laterality}
            onChange={setLaterality}
          />

          <div className="flex items-center" style={{ gap: 8 }}>
            {([
              { id: "grid" as const, Icon: Grid3x3, label: "Vista de grilla" },
              { id: "list" as const, Icon: List, label: "Vista de lista" },
            ]).map(({ id, Icon, label }) => (
              <button
                key={id}
                type="button"
                aria-label={label}
                onClick={() => setView(id)}
                className="flex items-center justify-center"
                style={{
                  width: 36,
                  height: 36,
                  border: `1px solid ${view === id ? "#111827" : "#E2E8F0"}`,
                  borderRadius: 8,
                  backgroundColor: view === id ? "#111827" : "#FFFFFF",
                  cursor: "pointer",
                }}
              >
                <Icon size={16} color={view === id ? "#FFFFFF" : "#94A3B8"} />
              </button>
            ))}
          </div>
        </div>

        {/* TABS */}
        <div style={{ marginBottom: 20, borderBottom: "1px solid #E2E8F0" }}>
          <div className="flex" style={{ gap: 24 }}>
            {TABS.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTab(t)}
                style={{
                  fontSize: 13,
                  fontWeight: 500,
                  paddingBottom: 10,
                  border: "none",
                  background: "none",
                  cursor: "pointer",
                  color: tab === t ? "#111827" : "#94A3B8",
                  borderBottom: `2px solid ${tab === t ? "#111827" : "transparent"}`,
                  marginBottom: -1,
                }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* RESULTS */}
        {view === "grid" ? (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
              gap: 16,
            }}
          >
            {results.map((e) => (
              <ExerciseCard key={e.name} exercise={e} />
            ))}
          </div>
        ) : (
          <ExerciseTable exercises={results} />
        )}

        {results.length === 0 && (
          <p style={{ fontSize: 13, color: "#94A3B8", marginTop: 12 }}>
            No hay ejercicios con estos filtros.
          </p>
        )}

        {/* PAGINATION */}
        <div className="flex items-center justify-between" style={{ marginTop: 24 }}>
          <span style={{ fontSize: 12, color: "#94A3B8" }}>
            Mostrando {results.length} de 148 ejercicios
          </span>
          <div className="flex items-center" style={{ gap: 4 }}>
            <button
              type="button"
              aria-label="Página anterior"
              disabled
              className="togo-page"
              style={{ color: "#CBD5E1", cursor: "not-allowed" }}
            >
              <ChevronLeft size={16} />
            </button>
            {["1", "2", "3", "...", "13"].map((p, i) => (
              <button
                key={`${p}-${i}`}
                type="button"
                className="togo-page"
                style={{
                  fontSize: 13,
                  fontWeight: p === "1" ? 600 : 400,
                  backgroundColor: p === "1" ? "#111827" : "transparent",
                  color: p === "1" ? "#FFFFFF" : "#64748B",
                }}
              >
                {p}
              </button>
            ))}
            <button
              type="button"
              aria-label="Página siguiente"
              className="togo-page"
              style={{ color: "#94A3B8" }}
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </main>

      <NewExerciseModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onSave={(ex) => {
          setCustom((prev) => [ex, ...prev]);
          setTab("Mis ejercicios");
          setToast(true);
          setTimeout(() => setToast(false), 2600);
        }}
      />

      {toast && (
        <div
          className="flex items-center"
          role="status"
          style={{
            position: "fixed",
            top: 24,
            right: 24,
            gap: 8,
            backgroundColor: "#FFFFFF",
            border: "1px solid #E2E8F0",
            borderRadius: 10,
            padding: "10px 14px",
            boxShadow: "0 4px 16px rgba(0,0,0,0.08)",
            zIndex: 80,
          }}
        >
          <CheckCircle size={14} color="#10B981" />
          <span style={{ fontSize: 13, color: "#374151" }}>Ejercicio guardado</span>
        </div>
      )}
    </div>
  );
}

